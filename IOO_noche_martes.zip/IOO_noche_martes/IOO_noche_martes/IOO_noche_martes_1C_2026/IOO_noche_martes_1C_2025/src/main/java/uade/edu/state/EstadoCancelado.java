package uade.edu.state;

public class EstadoCancelado extends EstadoPedido {
    public void avanzar(Pedido pedido) {
        System.out.println("El pedido está cancelado.");
    }

    public void cancelar(Pedido pedido) {
        System.out.println("El pedido ya estaba cancelado.");
    }
}