package uade.pattern.state;

public class Main {

    public static void main(String[] args) {

    Smartphone phone = new Smartphone();
    phone.pressButton();
    phone.pressButton();
    phone.setState(new LowBatteryState());
    phone.pressButton();
    }
}