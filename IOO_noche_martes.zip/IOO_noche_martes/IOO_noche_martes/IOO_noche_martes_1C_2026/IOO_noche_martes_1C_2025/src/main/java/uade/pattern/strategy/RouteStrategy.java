package uade.pattern.strategy;

public interface RouteStrategy {
    void buildRoute(int a, int b);
}
