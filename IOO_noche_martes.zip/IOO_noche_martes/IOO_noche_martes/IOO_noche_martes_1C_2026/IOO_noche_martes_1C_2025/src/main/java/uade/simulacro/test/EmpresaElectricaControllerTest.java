package uade.simulacro.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uade.simulacro.controller.EmpresaElectricaController;
import uade.simulacro.dto.UsuarioIndustrialDTO;
import uade.simulacro.model.Usuario;

import static org.junit.jupiter.api.Assertions.*;

public class EmpresaElectricaControllerTest {

    private EmpresaElectricaController controller;

    @BeforeEach
    public void setUp() {
        controller = EmpresaElectricaController.getInstances();
    }

    @Test
    public void testCrearUsuarioResidencial_Success() {
        int result = controller.crearUsuarioResidencial("Juan Perez", 12345678, "Mitre", 123, 1, "A", 1000, "CABA", "Buenos Aires");
        assertTrue(result > 0, "El número de usuario debe ser mayor a cero");
    }

    @Test
    public void testCrearUsuarioResidencial_Duplicate() {
        controller.crearUsuarioResidencial("Ana Gomez", 87654321, "Sarmiento", 321, 2, "B", 2000, "CABA", "Buenos Aires");
        int result = controller.crearUsuarioResidencial("Ana Gomez", 87654321, "Sarmiento", 321, 2, "B", 2000, "CABA", "Buenos Aires");
        assertEquals(0, result, "Debe retornar 0 por duplicado de DNI");
    }

    @Test
    public void testCrearUsuarioIndustrial_Success() {
        UsuarioIndustrialDTO dto = new UsuarioIndustrialDTO();
        dto.setCalle("Corrientes");
        dto.setAltura(456);
        dto.setPiso(3);
        dto.setDpto("C");
        dto.setCodigoPostal(1407);
        dto.setLocalidad("CABA");
        dto.setProvincia("Buenos Aires");
        dto.setCuit("305112");

        int result = controller.crearUsuarioInduntrial(dto);
        assertTrue(result > 0, "El número de usuario debe ser mayor a cero");
    }

    @Test
    public void testCrearUsuarioIndustrial_Duplicate() {
        UsuarioIndustrialDTO dto = new UsuarioIndustrialDTO();
        dto.setCalle("Santa Fe");
        dto.setAltura(789);
        dto.setPiso(5);
        dto.setDpto("D");
        dto.setCodigoPostal(1100);
        dto.setLocalidad("CABA");
        dto.setProvincia("Buenos Aires");
        dto.setCuit("3055566");

        controller.crearUsuarioInduntrial(dto);
        int result = controller.crearUsuarioInduntrial(dto);
        assertEquals(0, result, "Debe retornar 0 por duplicado de CUIT");
    }

    @Test
    public void testBuscarUsuario_Existente() {
        int nroUsuario = controller.crearUsuarioResidencial("Pedro Picapiedra", 10203040, "San Martin", 999, 0, "Z", 1234, "Bedrock", "Piedralandia");
        Usuario usuario = controller.buscarUsuario(nroUsuario);
        assertNotNull(usuario, "Debe encontrar al usuario existente");
    }

    @Test
    public void testBuscarUsuario_Inexistente() {
        Usuario usuario = controller.buscarUsuario(99999);
        assertNull(usuario, "No debe encontrar usuario con número inexistente");
    }

    @Test
    public void testConsultaConsumo_UsuarioExistente() {
        Usuario usuario = controller.buscarUsuario(1);
        if (usuario != null) {
            float consumo = controller.consultaConsumo(1, 2015, 11);
            assertTrue(consumo >= 0, "El consumo debe ser mayor o igual a 0");
        }
    }

    @Test
    public void testConsultaConsumo_UsuarioInexistente() {
        float consumo = controller.consultaConsumo(99999, 2022, 1);
        assertEquals(0, consumo, "El consumo debe ser cero para usuario inexistente");
    }

    @Test
    public void testBuscarUsuarioPorDni() {
        int dni = 99887766;
        controller.crearUsuarioResidencial("Marta", dni, "Belgrano", 200, 4, "H", 1400, "CABA", "Buenos Aires");
        Usuario usuario = controller.buscarUsuarioPorDni(dni);
        assertNotNull(usuario, "Debe encontrar usuario por DNI");
    }

    @Test
    public void testBuscarUsuarioPorCuit() {
        UsuarioIndustrialDTO dto = new UsuarioIndustrialDTO();
        dto.setCalle("Pueyrredón");
        dto.setAltura(123);
        dto.setPiso(1);
        dto.setDpto("A");
        dto.setCodigoPostal(1425);
        dto.setLocalidad("CABA");
        dto.setProvincia("Buenos Aires");
        dto.setCuit("30667888");

        controller.crearUsuarioInduntrial(dto);
        Usuario usuario = controller.buscarUsuarioPorCuit("30667888");
        assertNotNull(usuario, "Debe encontrar usuario por CUIT");
    }
}
