package uade.edu.state;

public class EstadoPagado extends EstadoPedido {

    public void avanzar(Pedido pedido) {
        System.out.println("Pedido enviado.");
        pedido.setEstado(new EstadoEnviado());
    }

    public void cancelar(Pedido pedido) {
        System.out.println("No se puede cancelar un pedido pagado.");
    }
}
