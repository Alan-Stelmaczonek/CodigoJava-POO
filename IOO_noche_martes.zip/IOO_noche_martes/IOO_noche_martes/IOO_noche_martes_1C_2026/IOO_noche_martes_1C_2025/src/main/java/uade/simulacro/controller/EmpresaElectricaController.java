package uade.simulacro.controller;



import uade.simulacro.dto.UsuarioIndustrialDTO;
import uade.simulacro.model.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class EmpresaElectricaController
{
	private List<Usuario> usuarios;
	private List<Tarifa> tarifas;
	private List<Factura> facturas;
	private int numeroUsuario;

	private static EmpresaElectricaController INSTANCES = null;

	/* constructor*/
	private EmpresaElectricaController(){
		usuarios 	= new ArrayList<>();
		tarifas		= new ArrayList<>();
		facturas	= new ArrayList<>();
		
		cargaInicial();
	}

	public static synchronized EmpresaElectricaController getInstances(){
		if(INSTANCES == null){
			INSTANCES = new EmpresaElectricaController();
		}
		return INSTANCES;
	}

	/* getters && setters */
	public int getNumeroUsuario() {
		return numeroUsuario;
	}

	public void setNumeroUsuario(int numeroUsuario) {
		this.numeroUsuario = numeroUsuario;
	}
	
	/* metodos */
	private void cargaInicial(){
		UsuarioIndustrial usI = new UsuarioIndustrial("La Pampa",1234,0,"0",
				1345,"CABA","CABA","Mi Empresa SA","331119","33456898769","IVA Inscripto");
		Medidor musI = new Medidor();
		usI.setMedidor(musI);
		Medicion m1 = new Medicion(Calendar.getInstance().getTime(),2015,10,1234);
		Medicion m2 = new Medicion(Calendar.getInstance().getTime(),2015,11,1534);
		musI.agregar(m1);
		musI.agregar(m2);
		TarifaIndustrial ti = new TarifaIndustrial(10,0.21,0.03);
		usI.setTarifa(ti);
		
		
		usuarios.add(usI);
	}
	
	/* alta usuarios */
	public int crearUsuarioResidencial(String nom, int dni, String calle, int altura, int piso, String dpto, int cp, String loca, String pcia){
		if(!existeUSuarioResidencia(dni)){
			UsuarioResidencial usuarioResidencial = new UsuarioResidencial(calle, altura, piso, dpto, cp, loca, pcia, nom, dni);
			usuarios.add(usuarioResidencial);
			
			//genera nuevo numero de usuario
			this.setNumeroUsuario(this.getNumeroUsuario() + 1);
			
			//asigna el nuevo numero al usuario
			usuarioResidencial.setNroUsuario(this.getNumeroUsuario());
			
			return usuarioResidencial.getNroUsuario();
		}else{
			return 0;
		}
	}
	
	public int crearUsuarioInduntrial(UsuarioIndustrialDTO usuarioIndustrialDTO){
		if(!existeUsuarioIndustrial(usuarioIndustrialDTO.getCuit())){
			UsuarioIndustrial usuarioIndustrial = toModel(usuarioIndustrialDTO);
			usuarios.add(usuarioIndustrial);
			
			//genera nuevo numero de usuario
			this.setNumeroUsuario(this.getNumeroUsuario() + 1);
			
			//asigna el nuevo numero al usuario
			usuarioIndustrial.setNroUsuario(this.getNumeroUsuario());
			
			return usuarioIndustrial.getNroUsuario();
		}else{
			return 0;
		}
	}
	
	public Usuario buscarUsuario(int nroUsuario){
		for(int i= 0;i < usuarios.size();i++){
			if(usuarios.get(i).sosUsuario(nroUsuario)){
				return usuarios.get(i);
			}
		}
		return null;
	}
	
	
	public float consultaConsumo(int nroUsuario,int anio, int bimestre){
		Usuario usuario = buscarUsuario(nroUsuario);
		if(usuario != null){
			return usuario.obtenerUltimoConsumo(anio, bimestre);
		}else{
			return 0;
		}
	}
	
	public boolean existeUsuarioIndustrial(String cuit){
		Usuario usuario = buscarUsuarioPorCuit(cuit);
		if(usuario!= null){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean existeUSuarioResidencia(int dni){
		Usuario usuario = buscarUsuarioPorDni(dni);
		if(usuario!= null){
			return true;
		}else{
			return false;
		}
	}
	
	public Usuario buscarUsuarioPorDni(int dni){
		for(int i= 0;i < usuarios.size();i++){
			if(usuarios.get(i).sosUsuarioPorDato(dni)){
				return usuarios.get(i);
			}
		}
		return null;
	}
	
	public Usuario buscarUsuarioPorCuit(String cuit){
		for(int i= 0;i < usuarios.size();i++){
			if(usuarios.get(i).sosUsuarioPorDato(Integer.parseInt(cuit))){
				return usuarios.get(i);
			}
		}
		return null;
	}

	private static UsuarioIndustrial toModel(UsuarioIndustrialDTO dto){
		return new UsuarioIndustrial(dto.getCalle(),dto.getAltura(), dto.getPiso(), dto.getDpto(), dto.getCodigoPostal(), dto.getLocalidad(), dto.getProvincia(), null, dto.getCuit(), null, null);
	}

}
