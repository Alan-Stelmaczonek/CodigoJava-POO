package uade.ReservasDeHotel.mvc.dto;

public class HabitacionInDTO {
    private String codigoIn;
    private String tipoIn;
    private String precioIn;

    public HabitacionInDTO(String codigoIn, String tipoIn, String precioIn) {
        this.codigoIn = codigoIn;
        this.tipoIn = tipoIn;
        this.precioIn = precioIn;
    }

    public String getCodigoIn() {
        return codigoIn;
    }

    public void setCodigoIn(String codigoIn) {
        this.codigoIn = codigoIn;
    }

    public String getTipoIn() {
        return tipoIn;
    }

    public void setTipoIn(String tipoIn) {
        this.tipoIn = tipoIn;
    }

    public String getPrecioIn() {
        return precioIn;
    }

    public void setPrecioIn(String precioIn) {
        this.precioIn = precioIn;
    }
}
