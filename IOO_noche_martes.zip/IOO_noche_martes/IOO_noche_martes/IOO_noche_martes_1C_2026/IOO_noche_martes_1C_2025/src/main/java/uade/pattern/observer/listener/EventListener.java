package uade.pattern.observer.listener;

public interface EventListener {
    void update(String filename);

}
