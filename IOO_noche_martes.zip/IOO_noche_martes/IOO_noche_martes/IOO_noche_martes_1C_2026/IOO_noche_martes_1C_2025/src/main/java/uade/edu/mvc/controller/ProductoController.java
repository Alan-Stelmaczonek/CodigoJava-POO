package uade.edu.mvc.controller;

import uade.edu.mvc.dto.ProductoDto;
import uade.edu.mvc.model.Producto;

import java.util.ArrayList;
import java.util.List;

public class ProductoController {

    private static ProductoController INSTANCE =null;
    private List<Producto> productos = null;

    private ProductoController(){
        this.productos = new ArrayList<>();
    }

    public static synchronized ProductoController getInstance(){

        if(INSTANCE == null){
            INSTANCE = new ProductoController();
        }
        return INSTANCE;
    }

    /**
     * Da de alta un nuevo producto en el sistema.
     *
     * @param codigoProducto   Código único del producto.
     * @param descripcion      Descripción del producto.
     * @param precioUnitario   Precio unitario del producto.
     */
    public void altaDeProducto(ProductoDto productoDto){

        Producto producto = toModel(productoDto);
        Producto auxProducto = existeProducto(producto.getCodigoProducto());
        if (auxProducto != null){
            System.err.println("Existe producto con el codigo " +
                    producto.getCodigoProducto());
            return;
        }
        productos.add(producto);
    }

    /**
     * Busca un producto por su código en la lista de productos.
     *
     * @param codigoProducto Código del producto a buscar.
     * @return El producto si existe, o null si no se encuentra.
     */
    public Producto existeProducto(int codigoProducto){
        for(int i = 0;i<productos.size();i++){
            if(productos.get(i).getCodigoProducto() == codigoProducto){
                return productos.get(i);
            }
        }
        return null;
    }

    private Producto toModel(ProductoDto dto){
        int codigoProducto = Integer.valueOf(dto.getCodigoProductoInput());
        float precioUnitario = Float.valueOf(dto.getPrecioUnitarioInput());
        Producto producto = new Producto(dto.getDescripcionInput(),codigoProducto,precioUnitario);
        return producto;
    }

    private ProductoDto toDto(Producto producto){
        String codigoProductoInput =String.valueOf(producto.getCodigoProducto());
        String precioUnitarioInput = String.valueOf(producto.getPrecioUnitario());

        ProductoDto dto = new ProductoDto(producto.getDescripcion(),
                codigoProductoInput,precioUnitarioInput);
        return dto;
    }

}
