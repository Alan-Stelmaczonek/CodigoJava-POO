package uade.pattern.strategy;

public class PublicTransportStrategy implements RouteStrategy {
    @Override
    public void buildRoute(int a, int b) {
        System.out.println("Calculando ruta en transporte público desde " + a + " hasta " + b + ".");
    }
}
