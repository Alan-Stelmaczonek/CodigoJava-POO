package uade.SistemaVehiculos;

public abstract class Vehiculo {
    protected Fabricante fabricante;
    protected String color;
    protected String modelo;
    protected String patente;
    protected boolean tieneSeguros;

    public Vehiculo(Fabricante fabricante, String color, String modelo, String patente, boolean tieneSeguros) {
        this.fabricante = fabricante;
        this.color = color;
        this.modelo = modelo;
        this.patente = patente;
        this.tieneSeguros = tieneSeguros;
    }

    public Fabricante getFabricante() {
        return fabricante;
    }
    public void setFabricante(Fabricante fabricante) {
        this.fabricante = fabricante;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public String getPatente() {
        return patente;
    }
    public void setPatente(String patente) {
        this.patente = patente;
    }
    public boolean isTieneSeguros() {
        return tieneSeguros;
    }
    public void setTieneSeguros(boolean tieneSeguros) {
        this.tieneSeguros = tieneSeguros;
    }

    @Override
    public String toString() {
        return "Vehiculo{" +
                "fabricante=" + fabricante +
                ", color='" + color + '\'' +
                ", modelo='" + modelo + '\'' +
                ", patente='" + patente + '\'' +
                ", tieneSeguros=" + tieneSeguros +
                '}';
    }

    public abstract String obtenerDescripcion();
}
