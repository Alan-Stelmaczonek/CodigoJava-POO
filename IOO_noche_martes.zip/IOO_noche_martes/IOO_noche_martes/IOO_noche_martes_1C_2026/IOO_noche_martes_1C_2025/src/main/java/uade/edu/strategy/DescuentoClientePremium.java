package uade.edu.strategy;

public class DescuentoClientePremium extends EstrategiaDescuento {
    public double calcularDescuento(double importe) {
        return importe * 0.15;
    }
}
