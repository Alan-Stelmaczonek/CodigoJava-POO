package uade.edu.state;

public class MainState {

    public static void main(String[] args) {
        Pedido pedido = new Pedido();

        pedido.avanzar();
        pedido.avanzar();
        pedido.cancelar();
    }
}
