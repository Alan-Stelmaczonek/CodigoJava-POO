package uade.edu.mvc.excepcion;

public class ClienteException extends Exception{
}
