package uade.edu.state;

public class Pedido  {

    private EstadoPedido estado;

    public Pedido() {
        this.estado = new EstadoPendiente();
    }

    public void setEstado(EstadoPedido estado) {
        this.estado = estado;
    }

    public void avanzar() {
        estado.avanzar(this);
    }

    public void cancelar() {
        estado.cancelar(this);
    }
}