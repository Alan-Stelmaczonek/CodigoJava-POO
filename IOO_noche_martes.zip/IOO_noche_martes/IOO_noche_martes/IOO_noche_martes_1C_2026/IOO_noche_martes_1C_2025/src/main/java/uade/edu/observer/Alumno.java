package uade.edu.observer;

public class Alumno extends Observador {
    private String nombre;

    public Alumno(String nombre) {
        this.nombre = nombre;
    }

    public void actualizar(String mensaje) {
        System.out.println(nombre + " recibió notificación: " + mensaje);
    }
}
