package uade.pattern.state;

public class LowBatteryState implements PhoneState {
    @Override
    public void pressButton(Smartphone phone) {
        System.out.println("Batería baja. Mostrando pantalla de carga.");
    }
}