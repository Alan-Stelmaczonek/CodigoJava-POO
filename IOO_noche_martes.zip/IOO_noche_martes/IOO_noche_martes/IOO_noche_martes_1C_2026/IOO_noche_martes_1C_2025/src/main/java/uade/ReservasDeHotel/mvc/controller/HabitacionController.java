package uade.ReservasDeHotel.mvc.controller;

import uade.ReservasDeHotel.mvc.dto.HabitacionInDTO;
import uade.ReservasDeHotel.mvc.model.Habitacion;

import java.util.ArrayList;
import java.util.List;

public class HabitacionController {

    private static HabitacionController INSTANCE = null;
    private List<Habitacion> habitacions = null;

    private HabitacionController() {
        habitacions = new ArrayList<>();
    }

    public static synchronized HabitacionController getInstance() {

        if (INSTANCE == null) {
            INSTANCE = new HabitacionController();
        }
        return INSTANCE;
    }

    public void altaHabitacion(HabitacionInDTO dto) {
        Habitacion habitacion = toModel(dto);
        Habitacion auxHabitacion = existeHabitacion(habitacion.getCodigo());
        if (auxHabitacion != null) {
            System.err.println("Existe habitacion con el codigo " + habitacion.getCodigo());

        return;
        }
        habitacions.add(habitacion);
    }

    public Habitacion existeHabitacion(String codigo) {
        for(int i = 0; i<habitacions.size();i++) {
            if(habitacions.get(i).getCodigo().equals(codigo)) {
                return habitacions.get(i);
            }
        }
        return null;
    }

    private Habitacion toModel(HabitacionInDTO dto) {
        float precioPorNoche = Float.valueOf(dto.getPrecioIn());
        Habitacion habitacion = new Habitacion(dto.getCodigoIn(), dto.getTipoIn(), precioPorNoche);
        return habitacion;
    }

    private HabitacionInDTO toDTO(Habitacion habitacion) {
        String CodigoIn = String.valueOf(habitacion.getCodigo());
        String TipoIn = String.valueOf(habitacion.getTipo());
        String PrecioIn = String.valueOf(habitacion.getPrecioPorNoche());

        HabitacionInDTO dto = new HabitacionInDTO(CodigoIn,TipoIn,PrecioIn);
        return dto;
    }




}
