package uade.edu.strategy;

public class MainStrategy {
    public static void main(String[] args) {
        Carrito carrito = new Carrito(new DescuentoSinPromocion());

        System.out.println("Total sin promoción: " + carrito.calcularTotal(10000));

        carrito.setEstrategiaDescuento(new DescuentoClientePremium());
        System.out.println("Total cliente premium: " + carrito.calcularTotal(10000));

        carrito.setEstrategiaDescuento(new DescuentoCyberMonday());
        System.out.println("Total Cyber Monday: " + carrito.calcularTotal(10000));
    }
}
