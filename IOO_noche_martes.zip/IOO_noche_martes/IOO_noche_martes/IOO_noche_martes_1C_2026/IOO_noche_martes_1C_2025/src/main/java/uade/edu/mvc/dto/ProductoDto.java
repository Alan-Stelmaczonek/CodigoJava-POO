package uade.edu.mvc.dto;

public class ProductoDto {

    private String descripcionInput;

    private String codigoProductoInput;

    private String precioUnitarioInput;

    public ProductoDto(String descripcionInput, String codigoProductoInput,
                       String precioUnitarioInput) {
        this.descripcionInput = descripcionInput;
        this.codigoProductoInput = codigoProductoInput;
        this.precioUnitarioInput = precioUnitarioInput;
    }

    public String getDescripcionInput() {
        return descripcionInput;
    }

    public void setDescripcionInput(String descripcionInput) {
        this.descripcionInput = descripcionInput;
    }

    public String getCodigoProductoInput() {
        return codigoProductoInput;
    }

    public void setCodigoProductoInput(String codigoProductoInput) {
        this.codigoProductoInput = codigoProductoInput;
    }

    public String getPrecioUnitarioInput() {
        return precioUnitarioInput;
    }

    public void setPrecioUnitarioInput(String precioUnitarioInput) {
        this.precioUnitarioInput = precioUnitarioInput;
    }
}
