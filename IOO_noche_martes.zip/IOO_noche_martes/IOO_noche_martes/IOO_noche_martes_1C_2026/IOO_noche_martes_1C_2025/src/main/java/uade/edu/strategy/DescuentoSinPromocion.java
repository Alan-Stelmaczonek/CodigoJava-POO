package uade.edu.strategy;

public class DescuentoSinPromocion extends EstrategiaDescuento {
    public double calcularDescuento(double importe) {
        return 0;
    }
}
