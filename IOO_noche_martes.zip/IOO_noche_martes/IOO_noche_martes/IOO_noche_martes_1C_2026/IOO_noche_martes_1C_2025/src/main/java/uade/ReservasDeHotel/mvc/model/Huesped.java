package uade.ReservasDeHotel.mvc.model;

public class Huesped extends Persona {
    private int nroHabitacion;

    public Huesped(String nombre, String apellido, int dni, int nroHabitacion) {
        super(nombre, apellido, dni);
        this.nroHabitacion = nroHabitacion;
    }

    public int getNroHabitacion() {
        return nroHabitacion;
    }

    public void setNroHabitacion(int nroHabitacion) {
        this.nroHabitacion = nroHabitacion;
    }
}
