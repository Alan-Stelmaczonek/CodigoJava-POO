package uade.edu.strategy;

public class Carrito {
    private EstrategiaDescuento estrategiaDescuento;

    public Carrito(EstrategiaDescuento estrategiaDescuento) {
        this.estrategiaDescuento = estrategiaDescuento;
    }

    public void setEstrategiaDescuento(EstrategiaDescuento estrategiaDescuento) {
        this.estrategiaDescuento = estrategiaDescuento;
    }

    public double calcularTotal(double importe) {
        double descuento = estrategiaDescuento.calcularDescuento(importe);
        return importe - descuento;
    }
}
