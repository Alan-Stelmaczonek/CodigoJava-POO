package uade.pattern.state;

public interface PhoneState {
    void pressButton(Smartphone phone);
}
