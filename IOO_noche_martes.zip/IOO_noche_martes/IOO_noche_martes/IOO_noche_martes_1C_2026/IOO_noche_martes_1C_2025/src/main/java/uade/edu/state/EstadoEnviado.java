package uade.edu.state;

public class EstadoEnviado extends EstadoPedido {
    public void avanzar(Pedido pedido) {
        System.out.println("El pedido ya fue enviado.");
    }

    public void cancelar(Pedido pedido) {
        System.out.println("No se puede cancelar un pedido enviado.");
    }
}
