package uade.pattern.observer;

import java.io.File;

public class Editor {
    private File file;
    public EventManager events;

    public Editor() {
        this.events = new EventManager();
    }

    public void openFile(String path) {
        this.file = new File(path);
        events.notify("open", file.getName());
    }

    public void saveFile() {
        if (file != null) {
            try {
                // Simulando una escritura
                System.out.println("Saving file: " + file.getName());
                events.notify("save", file.getName());
            } catch (Exception e) {
                System.out.println("Error saving file.");
            }
        }
    }
}