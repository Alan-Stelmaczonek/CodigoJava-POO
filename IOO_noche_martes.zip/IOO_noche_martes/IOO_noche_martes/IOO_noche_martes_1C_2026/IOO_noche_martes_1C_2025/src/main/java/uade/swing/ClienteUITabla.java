package uade.swing;


import uade.swing.dto.ClienteDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ClienteUITabla extends JFrame {

    private JTable tablaClientes;
    private DefaultTableModel modeloTabla;

    public ClienteUITabla(ClienteDTO[] clientes) {
        super("Información de Clientes");
        setLayout(new BorderLayout());

        // Crear el modelo de tabla
        modeloTabla = new DefaultTableModel();
        modeloTabla.setColumnIdentifiers(new String[] {"DNI", "Nombre", "Apellido", "Calle", "Número", "Barrio"});

        // Agregar los datos de los clientes al modelo de tabla
        for (ClienteDTO cliente : clientes) {
            Object[] fila = new Object[] {cliente.getDni(), cliente.getNombre(), cliente.getApellido(), cliente.getCalle(), cliente.getNumero(), cliente.getBarrio()};
            modeloTabla.addRow(fila);
        }

        // Crear la tabla y asociarla con el modelo
        tablaClientes = new JTable(modeloTabla);
        tablaClientes.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // Agregar la tabla al panel
        JScrollPane scrollPane = new JScrollPane(tablaClientes);
        add(scrollPane, BorderLayout.CENTER);

        // Establecer propiedades del panel
        setSize(600, 400);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public static void main(String[] args) {
        ClienteDTO[] clientes = new ClienteDTO[] {
                new ClienteDTO("12345678", "Juan", "Pérez", "Av. Corrientes", "1234", "Flores"),
                new ClienteDTO("87654321", "María", "Gómez", "Calle Libertad", "567", "Recoleta"),
                // Agregar más clientes...
        };
        ClienteUITabla uiTabla = new ClienteUITabla(clientes);
        uiTabla.setVisible(true);
    }
}