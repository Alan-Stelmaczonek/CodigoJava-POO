package uade.swing.example;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EjemploTexto extends JFrame {

    private JTextField txtNombre;
    private JButton btnSaludar;
    private JLabel lblResultado;

    public EjemploTexto() {

        setTitle("Ejemplo Nombre");
        setSize(500,300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);


        JLabel lblNombre = new JLabel("Nombres:");
        lblNombre.setBounds(20,20,80,25);

        txtNombre = new JTextField();
        txtNombre.setBounds(100,20,150,25);

        btnSaludar = new JButton("Saludar");
        btnSaludar.setBounds(80,70,120,30);

        lblResultado = new JLabel("");
        lblResultado.setBounds(50,120,200,25);

        btnSaludar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lblResultado.setText("Hola " + txtNombre.getText());
            }
        });

        add(lblNombre);
        add(txtNombre);
        add(btnSaludar);
        add(lblResultado);

        setVisible(true);
    }

    public static void main(String[] args) {
        new EjemploTexto();
    }
}
