package uade.pattern.strategy;

public class Application {
    public static void main(String[] args) {
        Navigation navigation = new Navigation();

        navigation.setStrategy(new CarStrategy());
        navigation.executeStrategy(1, 10);

        navigation.setStrategy(new PublicTransportStrategy());
        navigation.executeStrategy(1, 10);

        navigation.setStrategy(new WalkingStrategy());
        navigation.executeStrategy(1, 10);
    }
}
