package uade.SistemaVehiculos;

public class Main {
    public static void main(String[] args) {

        // 1. Crear fabricantes
        Fabricante toyota = new Fabricante("Toyota", "Japón");
        Fabricante honda = new Fabricante("Honda", "Japón");

        // 2. Crear un Auto
        Auto auto = new Auto(toyota, "Rojo", "Corolla", "ABC123", true);

        // 3. Crear dos Motos — una con cilindrada > 500, otra < 500
        Moto moto1 = new Moto(honda, "Negro", "CBR600", "XYZ789", true, 600);
        Moto moto2 = new Moto(honda, "Blanco", "Wave110", "QQQ111", false, 110);

        // 4. Imprimir descripciones
        System.out.println(auto.obtenerDescripcion());
        System.out.println(moto1.obtenerDescripcion());
        System.out.println(moto2.obtenerDescripcion());

        // 5. Probar hacerCaballito en ambas motos
        moto1.hacerCaballito();  // cilindrada > 500 → debería funcionar
        moto2.hacerCaballito();  // cilindrada < 500 → debería fallar
    }
}