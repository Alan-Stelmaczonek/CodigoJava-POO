package uade.edu.observer;

import java.util.ArrayList;
import java.util.List;

public class Curso {

    private String nombre;
    private List<Observador> observadores;

    public Curso(String nombre) {
        this.nombre = nombre;
        this.observadores = new ArrayList<>();
    }

    public void agregarObservador(Observador observador) {
        observadores.add(observador);
    }

    public void quitarObservador(Observador observador) {
        observadores.remove(observador);
    }

    public void publicarMensaje(String mensaje) {
        System.out.println("Curso " + nombre + " publicó: " + mensaje);
        notificar(mensaje);
    }

    private void notificar(String mensaje) {
        for (Observador observador : observadores) {
            observador.actualizar(mensaje);
        }
    }
}
