package uade.edu.mvc.view;

import uade.edu.mvc.controller.ProductoController;
import uade.edu.mvc.dto.ProductoDto;

public class AltaProductoView {

    private String labelDescripcion;

    private String labelCodigoProducto;

    private String labelPrecioUnitario;

    private String txtDescripcion;

    private String txtCodigoProducto;

    private String txtPrecioUnitario;

    ProductoController controller ;
    public  AltaProductoView(){
        this.controller = ProductoController.getInstance();
        this.labelCodigoProducto ="Codigo de Producto: ";
        this.labelDescripcion =  "Descripción: ";
        this.labelPrecioUnitario = "Precio del producto: ";
        this.txtCodigoProducto = "";
        this.txtDescripcion = "";
        this.txtPrecioUnitario = "";

    }

    public void buttonAceptar(){

        ProductoDto dto = new ProductoDto(txtDescripcion,
                txtCodigoProducto,txtPrecioUnitario);
        controller.altaDeProducto(dto);

    }

    public void buttonCancelar(){

    }

    public String getLabelDescripcion() {
        return labelDescripcion;
    }

    public void setLabelDescripcion(String labelDescripcion) {
        this.labelDescripcion = labelDescripcion;
    }

    public String getLabelCodigoProducto() {
        return labelCodigoProducto;
    }

    public void setLabelCodigoProducto(String labelCodigoProducto) {
        this.labelCodigoProducto = labelCodigoProducto;
    }

    public String getLabelPrecioUnitario() {
        return labelPrecioUnitario;
    }

    public void setLabelPrecioUnitario(String labelPrecioUnitario) {
        this.labelPrecioUnitario = labelPrecioUnitario;
    }

    public String getTxtDescripcion() {
        return txtDescripcion;
    }

    public void setTxtDescripcion(String txtDescripcion) {
        this.txtDescripcion = txtDescripcion;
    }

    public String getTxtCodigoProducto() {
        return txtCodigoProducto;
    }

    public void setTxtCodigoProducto(String txtCodigoProducto) {
        this.txtCodigoProducto = txtCodigoProducto;
    }

    public String getTxtPrecioUnitario() {
        return txtPrecioUnitario;
    }

    public void setTxtPrecioUnitario(String txtPrecioUnitario) {
        this.txtPrecioUnitario = txtPrecioUnitario;
    }
}
