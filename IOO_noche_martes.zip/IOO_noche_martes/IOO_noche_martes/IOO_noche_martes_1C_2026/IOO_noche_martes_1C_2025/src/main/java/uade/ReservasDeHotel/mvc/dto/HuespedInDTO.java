package uade.ReservasDeHotel.mvc.dto;

public class HuespedInDTO {
    private String nombreIn;
    private String apellidoIn;
    private String dniIn;
    private String nroHabitacion;

    public HuespedInDTO(String nombreIn, String apellidoIn, String dniIn, String nroHabitacion) {
        this.nombreIn = nombreIn;
        this.apellidoIn = apellidoIn;
        this.dniIn = dniIn;
        this.nroHabitacion = nroHabitacion;
    }

    public String getNombreIn() {
        return nombreIn;
    }

    public void setNombreIn(String nombreIn) {
        this.nombreIn = nombreIn;
    }

    public String getApellidoIn() {
        return apellidoIn;
    }

    public void setApellidoIn(String apellidoIn) {
        this.apellidoIn = apellidoIn;
    }

    public String getDniIn() {
        return dniIn;
    }

    public void setDniIn(String dniIn) {
        this.dniIn = dniIn;
    }

    public String getNroHabitacion() {
        return nroHabitacion;
    }

    public void setNroHabitacion(String nroHabitacion) {
        this.nroHabitacion = nroHabitacion;
    }
}
