package uade.reloj;

import java.util.Date;

public abstract class Reloj {

  protected   Marca marca;

    protected    String color;

    protected  String modelo;

    protected String numeroSerie;

    protected  boolean resistenciaAgua;

    public Reloj(Marca marca, String color, String modelo,
                 String numeroSerie, boolean resistenciaAgua) {
        this.marca = marca;
        this.color = color;
        this.modelo = modelo;
        this.numeroSerie = numeroSerie;
        this.resistenciaAgua = resistenciaAgua;
    }

    public Marca getMarca() {
        return marca;
    }

    public void setMarca(Marca marca) {
        this.marca = marca;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public void setNumeroSerie(String numeroSerie) {
        this.numeroSerie = numeroSerie;
    }

    public boolean isResistenciaAgua() {
        return resistenciaAgua;
    }

    public void setResistenciaAgua(boolean resistenciaAgua) {
        this.resistenciaAgua = resistenciaAgua;
    }

    @Override
    public String toString() {
        return "Reloj{" +
                "marca=" + marca +
                ", color='" + color + '\'' +
                ", modelo='" + modelo + '\'' +
                ", numeroSerie='" + numeroSerie + '\'' +
                ", resistenciaAgua=" + resistenciaAgua +
                '}';
    }

    public abstract String mostrarHora();
}
