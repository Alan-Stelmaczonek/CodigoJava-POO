package uade.SistemaVehiculos;

public class Moto extends Vehiculo {
    private int cilindrada;

    public Moto(Fabricante fabricante, String color, String modelo, String patente, boolean tieneSeguros, int cilindrada) {
        super(fabricante, color, modelo, patente, tieneSeguros);
        this.cilindrada = cilindrada;
    }

    public void hacerCaballito() {
        if(cilindrada > 500){
            System.out.println("Haciendo caballito");
        }else {
            System.out.println("Cilindrada insuficiente");
        }
    }

    @Override
    public String obtenerDescripcion() {
        return "Moto: " + modelo + " - " + color + " - " + patente + " - " + cilindrada;
    }
}
