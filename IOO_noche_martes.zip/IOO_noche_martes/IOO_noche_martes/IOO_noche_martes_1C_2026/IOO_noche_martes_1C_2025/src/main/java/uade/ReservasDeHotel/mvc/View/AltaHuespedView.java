package uade.ReservasDeHotel.mvc.View;

import uade.ReservasDeHotel.mvc.controller.HuespedController;
import uade.ReservasDeHotel.mvc.dto.HuespedInDTO;

import javax.swing.*;
import java.awt.*;

public class AltaHuespedView extends JFrame {

    private JLabel labelNombre;
    private JLabel labelApellido;
    private JLabel labelDni;
    private JLabel labelNroHabitacion;

    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtDni;
    private JTextField txtNroHabitacion;

    private JButton btnAceptar;
    private JButton btnCancelar;

    HuespedController controller;

    public AltaHuespedView() {
        this.controller = HuespedController.getInstance();

        setTitle("Alta Huesped");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLayout(new GridLayout(5, 2));

        labelNombre = new JLabel("Nombre: ");
        add(labelNombre);
        txtNombre = new JTextField();
        add(txtNombre);

        labelApellido = new JLabel("Apellido: ");
        add(labelApellido);
        txtApellido = new JTextField();
        add(txtApellido);

        labelDni = new JLabel("DNI: ");
        add(labelDni);
        txtDni = new JTextField();
        add(txtDni);

        labelNroHabitacion = new JLabel("Nro Habitacion: ");
        add(labelNroHabitacion);
        txtNroHabitacion = new JTextField();
        add(txtNroHabitacion);

        btnAceptar = new JButton("Aceptar");
        btnAceptar.addActionListener(e -> buttonAceptar());
        add(btnAceptar);

        btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> buttonCancelar());
        add(btnCancelar);

        setVisible(true);
    }

    public void buttonAceptar() {
        HuespedInDTO dto = new HuespedInDTO(
                txtNombre.getText(),
                txtApellido.getText(),
                txtDni.getText(),
                txtNroHabitacion.getText()
        );
        try {
            controller.altaHuesped(dto);
            JOptionPane.showMessageDialog(this, "Huesped dado de alta correctamente.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void buttonCancelar() {
        int opcion = JOptionPane.showConfirmDialog(this,
                "¿Está seguro que desea salir?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            dispose();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AltaHuespedView::new);
    }

}
