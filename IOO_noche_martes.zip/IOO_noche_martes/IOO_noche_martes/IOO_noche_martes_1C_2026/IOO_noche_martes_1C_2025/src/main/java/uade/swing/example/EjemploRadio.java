package uade.swing.example;

import javax.swing.*;

public class EjemploRadio extends JFrame {

    public EjemploRadio(){

        setSize(300,200);
        setLayout(null);

        JRadioButton rbEfectivo =
                new JRadioButton("Efectivo");

        JRadioButton rbTarjeta =
                new JRadioButton("Tarjeta");

        rbEfectivo.setBounds(50,30,100,30);
        rbTarjeta.setBounds(50,70,100,30);

        ButtonGroup grupo = new ButtonGroup();

        grupo.add(rbEfectivo);
        grupo.add(rbTarjeta);

        add(rbEfectivo);
        add(rbTarjeta);

        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new EjemploRadio();
    }

}