package uade.swing;


import uade.swing.dto.ClienteDTO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuPrincipalCliente extends JFrame implements ActionListener {

    private JMenuBar menuBar;
    private JMenu menuClientes;
    private JMenuItem menuItemNuevoCliente, menuItemVerCliente;
    private JPanel panelPrincipal, panelNuevoCliente, panelVerCliente;

    public MenuPrincipalCliente() {
        super("Menú Principal");

        // Crear componentes
        menuBar = new JMenuBar();
        menuClientes = new JMenu("Clientes");
        menuItemNuevoCliente = new JMenuItem("Nuevo Cliente");
        menuItemNuevoCliente.addActionListener(this);
        menuItemVerCliente = new JMenuItem("Ver Cliente");
        menuItemVerCliente.addActionListener(this);
        menuClientes.add(menuItemNuevoCliente);
        menuClientes.add(menuItemVerCliente);
        menuBar.add(menuClientes);
        setJMenuBar(menuBar);

        // Crear paneles
        panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new CardLayout());
        panelNuevoCliente = crearPanelNuevoCliente();
        panelVerCliente = crearPanelVerCliente();
        panelPrincipal.add(panelNuevoCliente, "nuevoCliente");
        panelPrincipal.add(panelVerCliente, "verCliente");

        // Mostrar panel principal
        mostrarPanel("nuevoCliente");

        // Establecer propiedades del frame
        setSize(600, 400);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private JPanel crearPanelNuevoCliente() {
        // Crear y organizar componentes del panel Nuevo Cliente (similar al código anterior)
        JPanel panel = new JPanel();
        // ... (código para crear y organizar componentes para ingresar datos de cliente)
        return panel;
    }

    private JPanel crearPanelVerCliente() {
        // Crear y organizar componentes del panel Ver Cliente (similar al código anterior para mostrar información)
        JPanel panel = new JPanel();
        // ... (código para crear y organizar componentes para mostrar la información de un cliente)
        return panel;
    }

    private void mostrarPanel(String nombrePanel) {
        CardLayout layout = (CardLayout) panelPrincipal.getLayout();
        layout.show(panelPrincipal, nombrePanel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == menuItemNuevoCliente) {
            //mostrarPanel("nuevoCliente");
             new ClienteUI();
        } else if (e.getSource() == menuItemVerCliente) {
            ClienteDTO[] clientes = new ClienteDTO[] {
                    new ClienteDTO("12345678", "Juan", "Pérez", "Av. Corrientes", "1234", "Flores"),
                    new ClienteDTO("87654321", "María", "Gómez", "Calle Libertad", "567", "Recoleta"),
                    // Agregar más clientes...
            };
            ClienteUITabla uiTabla = new ClienteUITabla(clientes);
            uiTabla.setVisible(true);
        }
    }

    public static void main(String[] args) {
        new MenuPrincipalCliente();
    }
}
