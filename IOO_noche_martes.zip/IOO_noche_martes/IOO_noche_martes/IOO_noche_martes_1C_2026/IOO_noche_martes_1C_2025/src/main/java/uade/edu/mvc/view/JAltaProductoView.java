package uade.edu.mvc.view;

import javax.swing.*;
import java.awt.*;

public class JAltaProductoView extends JFrame {

    private JLabel lblDescripcion;
    private JLabel lblCodigoProducto;
    private JLabel lblPrecioUnitario;

    private JTextField txtDescripcion;
    private JTextField txtCodigoProducto;

    private JTextField txtPrecioUnitario;

    private JButton btnAceptar;
    private JButton btnCancelar;


    public  JAltaProductoView(){
        this.setTitle("Alta Producto");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2));

        lblCodigoProducto = new JLabel("Codigo Producto: ");
        add(lblCodigoProducto);
        txtCodigoProducto = new JTextField();
        add(txtCodigoProducto);

        lblDescripcion = new JLabel("Descripcion: ");
        add(lblDescripcion);
        txtDescripcion = new JTextField();
        add(txtDescripcion);

        lblPrecioUnitario = new JLabel("Precio unitario: ");
        add(lblPrecioUnitario);
        txtPrecioUnitario = new JTextField();
        add(txtPrecioUnitario);

         btnAceptar = new JButton("Aceptar");
         btnCancelar = new JButton("Cancelar");

         add(btnAceptar);
         add(btnCancelar);


        setVisible(true);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(JAltaProductoView::new);
    }



}
