package uade.swing;

import javax.swing.*;

public class ClienteView {
    private JPanel panelCliente;
    private JLabel lblNombre;
    private JTextField textNombre;
    private JButton btnAceptar;
}
