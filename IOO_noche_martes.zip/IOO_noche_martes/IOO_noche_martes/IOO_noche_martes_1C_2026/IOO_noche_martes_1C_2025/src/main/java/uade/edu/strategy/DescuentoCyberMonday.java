package uade.edu.strategy;

public class DescuentoCyberMonday extends EstrategiaDescuento {
    public double calcularDescuento(double importe) {
        return importe * 0.30;
    }
}
