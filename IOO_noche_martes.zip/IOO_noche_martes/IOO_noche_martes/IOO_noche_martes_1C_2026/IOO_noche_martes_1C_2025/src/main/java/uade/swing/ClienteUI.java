package uade.swing;

import uade.swing.dto.ClienteDTO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ClienteUI extends JFrame implements ActionListener {

    private JLabel lblDNI, lblNombre, lblApellido, lblCalle, lblNumero, lblBarrio;
    private JTextField txtDNI, txtNombre, txtApellido, txtCalle, txtNumero, txtBarrio;
    private JButton btnGuardar, btnCancelar, btnLimpiar;

    public ClienteUI() {
        super("Registro de Cliente");
        setLayout(new GridBagLayout());

        // Etiquetas
        lblDNI = new JLabel("DNI:");
        lblNombre = new JLabel("Nombre:");
        lblApellido = new JLabel("Apellido:");
        lblCalle = new JLabel("Calle:");
        lblNumero = new JLabel("Número:");
        lblBarrio = new JLabel("Barrio:");

        // Campos de texto
        txtDNI = new JTextField(10);
        txtNombre = new JTextField(20);
        txtApellido = new JTextField(20);
        txtCalle = new JTextField(20);
        txtNumero = new JTextField(10);
        txtBarrio = new JTextField(20);

        // Botones
        btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(this);
        btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(this);
        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.addActionListener(this);

        // Agregar componentes al panel
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.weightx = 0.5;
        gbc.weighty = 0.5;

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(lblDNI, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        add(txtDNI, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(lblNombre, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        add(txtNombre, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(lblApellido, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        add(txtApellido, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(lblCalle, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        add(txtCalle, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(lblNumero, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        add(txtNumero, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(lblBarrio, gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        add(txtBarrio, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        add(btnGuardar, gbc);

        gbc.gridx = 1;
        gbc.gridy = 6;
        add(btnCancelar, gbc);

        gbc.gridx = 2;
        gbc.gridy = 6;
        add(btnLimpiar, gbc);

        // Establecer propiedades del panel
        setSize(400, 350);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnGuardar) {
            // Guardar los datos ingresados
            String dni = txtDNI.getText();
            String nombre = txtNombre.getText();
            String apellido = txtApellido.getText();
            String calle = txtCalle.getText();
            String numero = txtNumero.getText();
            String barrio = txtBarrio.getText();

            ClienteDTO cliente = new ClienteDTO(dni, nombre, apellido, calle, numero, barrio);
            JOptionPane.showMessageDialog(null, "Cliente registrado con éxito");
            System.out.println(cliente.toString());
        } else if (e.getSource() == btnCancelar) {
            dispose();
        }else if (e.getSource() == btnLimpiar) {
            // Limpiar los campos de texto
            txtDNI.setText("");
            txtNombre.setText("");
            txtApellido.setText("");
            txtCalle.setText("");
            txtNumero.setText("");
            txtBarrio.setText("");
        }

    }

    public static void main(String[] args) {
        new ClienteUI();
    }
}