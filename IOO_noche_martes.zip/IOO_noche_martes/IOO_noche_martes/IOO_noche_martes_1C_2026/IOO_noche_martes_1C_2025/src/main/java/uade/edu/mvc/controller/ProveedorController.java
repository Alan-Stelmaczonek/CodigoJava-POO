package uade.edu.mvc.controller;

import uade.edu.mvc.model.Proveedor;

import java.util.ArrayList;
import java.util.List;

public class ProveedorController {

    private static ProveedorController INSTANCE = null;

    private List<Proveedor> proveedores = new ArrayList<>();

    private ProveedorController(){

    }

    /**
     * Permite gestionar el control de la incialización de clase.
     * Patron singleton
     * @return instancia de proveedor controller
     */
    public static synchronized ProveedorController getInstance(){
        if(INSTANCE == null){
            INSTANCE = new ProveedorController();
        }
        return INSTANCE;
    }


    /**
     * Busca un proveedor por su DNI en la lista de proveedores.
     *
     * @param dniProveedor DNI del proveedor a buscar.
     * @return El proveedor si existe, o null si no se encuentra.
     */
    public Proveedor existeProveedor(int dniProveedor){
        for(int i = 0;i<proveedores.size();i++){
            if(proveedores.get(i).getDni() == dniProveedor){
                return proveedores.get(i);
            }
        }
        return null;
    }
}
