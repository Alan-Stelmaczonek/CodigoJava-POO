package uade.reloj;

import java.util.Date;

public class RelojAnalogico extends Reloj{


    public RelojAnalogico(Marca marca, String color,
                          String modelo, String numeroSerie, boolean resistenciaAgua) {
        super(marca, color, modelo, numeroSerie, resistenciaAgua);
    }

    @Override
    public String mostrarHora() {
        return "Soy Analogico " + new Date().toString();
    }
}
