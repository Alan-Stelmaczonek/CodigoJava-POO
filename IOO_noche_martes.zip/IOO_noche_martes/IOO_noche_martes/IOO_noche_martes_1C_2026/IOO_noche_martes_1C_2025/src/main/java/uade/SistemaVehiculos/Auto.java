package uade.SistemaVehiculos;

public class Auto extends Vehiculo {

    public Auto(Fabricante fabricante, String color, String modelo, String patente, boolean tieneSeguros) {
        super(fabricante,color,modelo,patente,tieneSeguros);
    }

    @Override
    public String obtenerDescripcion() {
        return  "Auto: " + modelo + " - " + color + " - " + patente;
    }
}
