package uade.ReservasDeHotel.mvc.exception;

public class HuespedException extends RuntimeException {
    public HuespedException(String message) {
        super(message);
    }
}
