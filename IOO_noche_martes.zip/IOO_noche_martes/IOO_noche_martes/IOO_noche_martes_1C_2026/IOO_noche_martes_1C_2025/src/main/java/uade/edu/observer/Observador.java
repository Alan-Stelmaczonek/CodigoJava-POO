package uade.edu.observer;

public abstract class Observador {
    public abstract void actualizar(String mensaje);
}
