package uade.swing.example;

import javax.swing.*;

public class EjemploCombo extends JFrame{

    public EjemploCombo(){

        setSize(300,200);
        setLayout(null);

        String materias[]={
                "POO",
                "Base Datos",
                "Arquitectura"
        };

        JComboBox combo=
                new JComboBox(materias);

        combo.setBounds(70,50,150,30);

        JButton btn=
                new JButton("Mostrar");

        btn.setBounds(80,100,120,30);

        btn.addActionListener(e -> {

            JOptionPane.showMessageDialog(null,
                    combo.getSelectedItem());

        });

        add(combo);
        add(btn);

        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {

        new EjemploCombo();

    }

}