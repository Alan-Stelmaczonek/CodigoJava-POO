package uade.pattern.strategy;

public class CarStrategy implements RouteStrategy {
    @Override
    public void buildRoute(int a, int b) {
        System.out.println("Calculando ruta en auto desde " + a + " hasta " + b + ".");
    }
}