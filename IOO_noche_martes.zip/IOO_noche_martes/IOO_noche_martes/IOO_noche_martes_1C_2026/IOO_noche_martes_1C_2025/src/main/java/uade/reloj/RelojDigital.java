package uade.reloj;

import java.util.Date;

public class RelojDigital extends Reloj {
    /**
     * Atributos
     */
    int carga;

    public RelojDigital(Marca marca, String color, String modelo,
                        String numeroSerie, boolean resistenciaAgua,int bateria) {
        super(marca, color, modelo, numeroSerie, resistenciaAgua);
        this.carga = bateria;
    }


    /**
     * Metodos
     */


    public void cargarBateria(){
        carga = 100;
    }

    public void llamar(){
        if(carga>10){
            carga = carga -10;
            System.out.println("llamada entrante");
        }else{
            System.out.println("Estoy apagado");
        }
    }

    public void mostrarBateria(){
        System.out.println("mostrar bateria : " + carga);
    }

    public int getCarga() {
        return carga;
    }

    public void setCarga(int carga) {
        this.carga = carga;
    }

    @Override
    public String mostrarHora() {
        {
            Date date = new Date();
            if(carga>20){
                carga = carga -20;
            }
            return date.toString();
        }
    }
}
