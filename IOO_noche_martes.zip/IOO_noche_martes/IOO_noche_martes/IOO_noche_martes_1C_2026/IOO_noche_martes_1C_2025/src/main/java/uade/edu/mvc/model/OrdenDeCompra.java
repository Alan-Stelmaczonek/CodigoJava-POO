package uade.edu.mvc.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class OrdenDeCompra {
    private Date fecha;

    private UUID codigoOrden;

    private Proveedor proveedor;

    private List<ProductoXOrdenDeCompra> detalleDeLaOrden;
    public OrdenDeCompra(Date fecha, Producto producto, int cantidad, Proveedor proveedor) {
        this.fecha = fecha;
        this.codigoOrden = UUID.randomUUID();
        this.proveedor = proveedor;
        detalleDeLaOrden = new ArrayList<>();
        detalleDeLaOrden.add(new ProductoXOrdenDeCompra(producto,cantidad));

    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public UUID getCodigoOrden() {
        return codigoOrden;
    }

    public void setCodigoOrden(UUID codigoOrden) {
        this.codigoOrden = codigoOrden;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public List<ProductoXOrdenDeCompra> getDetalleDeLaOrden() {
        return detalleDeLaOrden;
    }

    public void setDetalleDeLaOrden(List<ProductoXOrdenDeCompra> detalleDeLaOrden) {
        this.detalleDeLaOrden = detalleDeLaOrden;
    }

    @Override
    public String toString() {
        return "OrdenDeCompra{" +
                "fecha=" + fecha +
                ", codigoOrden=" + codigoOrden +
                ", proveedor=" + proveedor +
                ", detalleDeLaOrden=" + detalleDeLaOrden +
                '}';
    }
}
