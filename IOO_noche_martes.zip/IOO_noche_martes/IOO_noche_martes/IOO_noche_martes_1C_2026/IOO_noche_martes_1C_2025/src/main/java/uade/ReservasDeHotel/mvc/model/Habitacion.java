package uade.ReservasDeHotel.mvc.model;

public class Habitacion {
    private String codigo;
    private String tipo;
    private float precioPorNoche;

    public Habitacion(String codigo, String tipo, float precioPorNoche) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.precioPorNoche = precioPorNoche;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getPrecioPorNoche() {
        return precioPorNoche;
    }

    public void setPrecioPorNoche(float precioPorNoche) {
        this.precioPorNoche = precioPorNoche;
    }

    @Override
    public String toString() {
        return "Habitacion{" +
                "codigo='" + codigo + '\'' +
                ", tipo='" + tipo + '\'' +
                ", precioPorNoche=" + precioPorNoche +
                '}';
    }
}
