package uade.pattern.observer;

import uade.pattern.observer.listener.EmailAlertsListener;
import uade.pattern.observer.listener.LoggingListener;

public class Application {
    public void config() {
        Editor editor = new Editor();

        LoggingListener logger = new LoggingListener(
                "log.txt",
                "Someone has opened the file: %s"
        );
        editor.events.subscribe("open", logger);

        EmailAlertsListener emailAlerts = new EmailAlertsListener(
                "admin@example.com",
                "Someone has changed the file: %s"
        );
        editor.events.subscribe("save", emailAlerts);

        // Simulación de uso
        editor.openFile("test_document.txt");
        editor.saveFile();
    }

    public static void main(String[] args) {
        new Application().config();
    }
}