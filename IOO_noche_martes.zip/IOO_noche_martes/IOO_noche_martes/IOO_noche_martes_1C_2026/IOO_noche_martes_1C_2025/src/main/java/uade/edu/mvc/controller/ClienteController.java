package uade.edu.mvc.controller;

import uade.edu.mvc.dto.ClienteInDTO;
import uade.edu.mvc.model.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ClienteController {

    private List<Cliente> clientes;

    private static ClienteController INSTANCE;

    private ClienteController(){
        clientes = new ArrayList<>();
        clientes.add(new Cliente("Marcos", "Solis"));
        clientes.add(new Cliente("Marco", "Polo"));
    }

    public static synchronized ClienteController getInstance(){
        if(INSTANCE == null) {
            INSTANCE = new ClienteController();
        }
        return INSTANCE;
    }

    public String altaCliente(ClienteInDTO dto) throws Exception {


        if(dto == null){
            throw  new Exception("Error cliente es nulo.");
        }
        for(int i = 0; i < clientes.size(); i++){
            System.out.println("Cliente buscado : " + clientes.get(i).toString());
            if(clientes.get(i).getNombre().equals(dto.getNameIn()) &&
                clientes.get(i).getApellido().equals(dto.getLastNameIn())){
                throw  new Exception("Error el cliente nombre :" + dto.getNameIn() + " ya existe.");
            }
        }
        Cliente cliente = new Cliente(dto.getNameIn(),dto.getLastNameIn());
        clientes.add(cliente);
        System.out.println("Se creo el cliente: " + cliente.toString());
        return cliente.getNombre();
    }

}
