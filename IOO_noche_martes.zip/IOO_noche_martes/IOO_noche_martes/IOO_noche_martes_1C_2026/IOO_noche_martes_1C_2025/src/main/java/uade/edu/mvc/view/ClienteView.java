package uade.edu.mvc.view;

import javax.swing.*;
import java.awt.*;


public class ClienteView extends JFrame {

    private JTextField dniField, apellidoField, nombreField, calleField, numeroField, barrioField;

    public ClienteView() {
        setTitle("Formulario de Cliente");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(8, 2)); // 6 campos + 2 botones

        add(new JLabel("DNI:"));
        dniField = new JTextField();
        add(dniField);

        add(new JLabel("Apellido:"));
        apellidoField = new JTextField();
        add(apellidoField);

        add(new JLabel("Nombre:"));
        nombreField = new JTextField();
        add(nombreField);

        add(new JLabel("Calle:"));
        calleField = new JTextField();
        add(calleField);

        add(new JLabel("Número:"));
        numeroField = new JTextField();
        add(numeroField);

        add(new JLabel("Barrio:"));
        barrioField = new JTextField();
        add(barrioField);

        JButton enviarBtn = new JButton("Enviar");
        JButton cancelarBtn = new JButton("Cancelar");

        add(enviarBtn);
        add(cancelarBtn);

        enviarBtn.addActionListener(e -> validarFormulario());

        cancelarBtn.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(this,
                    "¿Está seguro que desea salir?",
                    "Confirmar salida",
                    JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                dispose();
            }
        });

        setVisible(true);
    }

    private void validarFormulario() {
        if (dniField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "El campo DNI no puede estar vacío.");
            return;
        }

        try {
            Integer.parseInt(dniField.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                    "El campo DNI debe contener solo números.");
            return;
        }

        if (apellidoField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "El campo Apellido no puede estar vacío.");
            return;
        }

        if (nombreField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "El campo Nombre no puede estar vacío.");
            return;
        }

        if (calleField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "El campo Calle no puede estar vacío.");
            return;
        }

        if (numeroField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "El campo Número no puede estar vacío.");
            return;
        }

        if (barrioField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "El campo Barrio no puede estar vacío.");
            return;
        }

        JOptionPane.showMessageDialog(this,
                "Formulario enviado correctamente.");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ClienteView::new);
    }
}
