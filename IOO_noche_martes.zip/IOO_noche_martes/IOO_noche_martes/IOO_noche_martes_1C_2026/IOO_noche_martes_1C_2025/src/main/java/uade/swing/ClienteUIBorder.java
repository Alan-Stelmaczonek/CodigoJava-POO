package uade.swing;


import uade.swing.dto.ClienteDTO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ClienteUIBorder extends JFrame implements ActionListener {

    private JLabel lblDNI, lblNombre, lblApellido, lblCalle, lblNumero, lblBarrio;
    private JTextField txtDNI, txtNombre, txtApellido, txtCalle, txtNumero, txtBarrio;
    private JButton btnGuardar, btnCancelar, btnLimpiar;

    public ClienteUIBorder() {
        super("Registro de Cliente");
        setLayout(new BorderLayout());

        // Panel para los campos de texto
        JPanel panelCampos = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.weightx = 0.5;
        gbc.weighty = 0.5;

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCampos.add(lblDNI = new JLabel("DNI:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        panelCampos.add(txtDNI = new JTextField(10), gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelCampos.add(lblNombre = new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        panelCampos.add(txtNombre = new JTextField(20), gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panelCampos.add(lblApellido = new JLabel("Apellido:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        panelCampos.add(txtApellido = new JTextField(20), gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panelCampos.add(lblCalle = new JLabel("Calle:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        panelCampos.add(txtCalle = new JTextField(20), gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panelCampos.add(lblNumero = new JLabel("Número:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        panelCampos.add(txtNumero = new JTextField(10), gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        panelCampos.add(lblBarrio = new JLabel("Barrio:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        panelCampos.add(txtBarrio = new JTextField(20), gbc);

        // Panel para los botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelBotones.add(btnGuardar = new JButton("Guardar"));
        btnGuardar.addActionListener(this);
        panelBotones.add(btnCancelar = new JButton("Cancelar"));
        btnCancelar.addActionListener(this);
        panelBotones.add(btnLimpiar = new JButton("Limpiar"));
        btnLimpiar.addActionListener(this);

        // Agregar paneles al BorderLayout
        add(panelCampos, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        // Establecer propiedades del panel
        setSize(400, 350);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnGuardar) {
            // Guardar los datos ingresados
            String dni = txtDNI.getText();
            String nombre = txtNombre.getText();
            String apellido = txtApellido.getText();
            String calle = txtCalle.getText();
            String numero = txtNumero.getText();
            String barrio = txtBarrio.getText();

            ClienteDTO cliente = new ClienteDTO(dni, nombre, apellido, calle, numero, barrio);
            JOptionPane.showMessageDialog(null, "Cliente registrado con éxito");
            System.out.println(cliente.toString());
        } else if (e.getSource() == btnCancelar) {
            dispose();
        }else if (e.getSource() == btnLimpiar) {
            // Limpiar los campos de texto
            txtDNI.setText("");
            txtNombre.setText("");
            txtApellido.setText("");
            txtCalle.setText("");
            txtNumero.setText("");
            txtBarrio.setText("");
        }

    }

    public static void main(String[] args) {
        new ClienteUIBorder();
    }
}
