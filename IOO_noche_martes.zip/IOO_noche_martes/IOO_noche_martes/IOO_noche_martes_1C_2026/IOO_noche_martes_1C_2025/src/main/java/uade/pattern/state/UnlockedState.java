package uade.pattern.state;

public class UnlockedState implements PhoneState {
    @Override
    public void pressButton(Smartphone phone) {
        System.out.println("Ejecutando funciones: abrir app, tomar foto, etc.");
    }
}