package uade.edu.mvc.model;

public class Proveedor extends Persona {

    private String telefonoDeContacto;

    public Proveedor(String nombre, String apellido, int dni, String telefonoDeContacto) {
        super(nombre, apellido, dni);
        this.telefonoDeContacto = telefonoDeContacto;
    }

    public String getTelefonoDeContacto() {
        return telefonoDeContacto;
    }

    public void setTelefonoDeContacto(String telefonoDeContacto) {
        this.telefonoDeContacto = telefonoDeContacto;
    }

    @Override
    public String toString() {
        return "Proveedor{" +
                "telefonoDeContacto='" + telefonoDeContacto + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", dni=" + dni +
                '}';
    }
}
