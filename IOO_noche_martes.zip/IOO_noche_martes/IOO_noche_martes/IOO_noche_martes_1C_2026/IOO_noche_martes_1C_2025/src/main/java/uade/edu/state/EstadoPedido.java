package uade.edu.state;

public abstract class EstadoPedido {
    public abstract void avanzar(Pedido pedido);
    public abstract void cancelar(Pedido pedido);
}
