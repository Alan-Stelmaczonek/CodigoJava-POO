package uade.edu.mvc.dto;

public class ClienteInDTO {

    private String nameIn;

    private String lastNameIn;

    public ClienteInDTO(String nameIn, String lastNameIn) {
        this.nameIn = nameIn;
        this.lastNameIn = lastNameIn;
    }

    public String getNameIn() {
        return nameIn;
    }

    public void setNameIn(String nameIn) {
        this.nameIn = nameIn;
    }

    public String getLastNameIn() {
        return lastNameIn;
    }

    public void setLastNameIn(String lastNameIn) {
        this.lastNameIn = lastNameIn;
    }
}
