package uade.ReservasDeHotel.mvc.controller;

import uade.ReservasDeHotel.mvc.dto.HuespedInDTO;
import uade.ReservasDeHotel.mvc.model.Huesped;

import java.util.ArrayList;
import java.util.List;

public class HuespedController {

    private List<Huesped> huespedes;
    private static HuespedController INSTANCE = null;

    private HuespedController() {
        this.huespedes = new ArrayList<>();
    }

    public static synchronized HuespedController getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new HuespedController();
        }
        return INSTANCE;
    }


    public void altaHuesped(HuespedInDTO huespedInDTO) throws Exception {
        Huesped huesped = toModel(huespedInDTO);
        Huesped auxHuesped = existeHuesped(huesped.getDni());
        if (auxHuesped != null) {
            throw new Exception("El huésped " + huesped.getNombre() + " ya existe.");
        }
        huespedes.add(huesped);
    }


    public Huesped existeHuesped(int dni) {
        for(int i = 0;i<huespedes.size();i++){
            if(huespedes.get(i).getDni() == dni) {
                return huespedes.get(i);
            }
        }
        return null;
    }

    private Huesped toModel(HuespedInDTO dto) {
        int dni = Integer.valueOf(dto.getDniIn());
        int nroHabitacion = Integer.valueOf(dto.getNroHabitacion());
        Huesped huesped = new Huesped(dto.getNombreIn(), dto.getApellidoIn(), dni, nroHabitacion);
        return huesped;
    }

    private HuespedInDTO toDTO(Huesped huesped) {

        String dniIn = String.valueOf(huesped.getDni());
        String nroHabitacion = String.valueOf(huesped.getNroHabitacion());

        HuespedInDTO dto = new HuespedInDTO(huesped.getNombre(), huesped.getApellido(), dniIn, nroHabitacion);
        return dto;

    }
}
