package uade.edu.strategy;

public abstract class EstrategiaDescuento {
    public abstract double calcularDescuento(double importe);
}
