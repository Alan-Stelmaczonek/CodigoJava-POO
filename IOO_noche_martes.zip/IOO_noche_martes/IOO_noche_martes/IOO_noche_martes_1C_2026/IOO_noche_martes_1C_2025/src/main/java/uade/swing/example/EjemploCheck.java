package uade.swing.example;

import javax.swing.*;

public class EjemploCheck extends JFrame {

    public EjemploCheck(){

        setTitle("CheckBox");
        setSize(300,200);
        setLayout(null);

        JCheckBox cbJava = new JCheckBox("Java");
        cbJava.setBounds(50,30,100,30);

        JCheckBox cbPython = new JCheckBox("Python");
        cbPython.setBounds(50,70,100,30);

        JButton btnMostrar = new JButton("Ver");

        btnMostrar.setBounds(70,120,100,30);

        btnMostrar.addActionListener(e -> {

            String texto="";

            if(cbJava.isSelected())
                texto += "Java ";

            if(cbPython.isSelected())
                texto += "Python";

            JOptionPane.showMessageDialog(null,
                    "Seleccionó: " + texto);

        });

        add(cbJava);
        add(cbPython);
        add(btnMostrar);

        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new EjemploCheck();
    }
}