package uade.swing.example;

import javax.swing.*;

public class EjemploLista extends JFrame {

    public EjemploLista(){

        setSize(300,250);
        setLayout(null);

        String alumnos[]={
                "Juan",
                "Pedro",
                "María",
                "Ana"
        };

        JList lista=
                new JList(alumnos);

        lista.setBounds(80,20,100,100);

        JButton btn=
                new JButton("Ver");

        btn.setBounds(80,140,100,30);

        btn.addActionListener(e -> {

            JOptionPane.showMessageDialog(
                    null,
                    lista.getSelectedValue());

        });

        add(lista);
        add(btn);

        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

    }

    public static void main(String[] args) {
        new EjemploLista();
    }

}