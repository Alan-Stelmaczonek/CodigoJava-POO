package uade.edu.mvc.view;

import uade.edu.mvc.controller.ClienteController;
import uade.edu.mvc.dto.ClienteInDTO;

import javax.swing.*;
import java.awt.*;

public class AltaClienteView extends JFrame {

    private JLabel labelNombre;

    private JLabel labelApellido;

    private JTextField txtNombre;

    private JTextField txtApellido;

    private  JButton btnGuardar;

    private  JButton btnCancelar;

    ClienteController clienteController;

    public AltaClienteView(){
        this.setTitle("Alta Cliente");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLayout(new GridLayout(3, 2));

        clienteController = ClienteController.getInstance();

         labelApellido = new JLabel("Apellido: ");
         add(labelApellido);
         txtApellido = new JTextField();
         add(txtApellido);

         labelNombre = new JLabel("Nombre :");
         add(labelNombre);
         txtNombre = new JTextField();
         add(txtNombre);

         btnGuardar = new JButton("Guardar");
         btnGuardar.addActionListener(e -> guardarCliente());

        add(btnGuardar);
         btnCancelar = new JButton("Cancelar");
        add(btnCancelar);

        btnCancelar.addActionListener(e -> cancelarBoton());
        setVisible(true);
    }

    private void guardarCliente() {
        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        ClienteInDTO dto = new ClienteInDTO(nombre, apellido);
        try {
            clienteController.altaCliente(dto);
            JOptionPane.showMessageDialog(this,
                    "Formulario enviado correctamente.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    e.getMessage());
        }

    }

    private  void cancelarBoton(){
        int opcion = JOptionPane.showConfirmDialog(this,
                "¿Está seguro que desea salir?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            dispose();
        }
    }

    public static void main(String [] args){
        SwingUtilities.invokeLater(AltaClienteView::new);
    }

}
