package uade.pattern.state;

public class Smartphone {
    private PhoneState state;

    public Smartphone() {
        // Estado inicial, por ejemplo: bloqueado
        this.state = new LockedState();
    }

    public void setState(PhoneState state) {
        this.state = state;
    }

    public void pressButton() {
        state.pressButton(this);
    }
}