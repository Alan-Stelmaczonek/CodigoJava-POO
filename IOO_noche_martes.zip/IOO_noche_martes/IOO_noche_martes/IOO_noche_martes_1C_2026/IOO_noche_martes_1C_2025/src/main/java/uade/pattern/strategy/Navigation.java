package uade.pattern.strategy;

public class Navigation {
    private RouteStrategy strategy;

    public void setStrategy(RouteStrategy strategy) {
        this.strategy = strategy;
    }

    public void executeStrategy(int a, int b) {
        if (strategy == null) {
            System.out.println("Por favor, seleccioná una estrategia de ruta.");
            return;
        }
        strategy.buildRoute(a, b);
    }
}