package uade.edu.observer;

public class Docente extends Observador {
    private String nombre;

    public Docente(String nombre) {
        this.nombre = nombre;
    }

    public void actualizar(String mensaje) {
        System.out.println("Docente " + nombre + " recibió aviso: " + mensaje);
    }
}
