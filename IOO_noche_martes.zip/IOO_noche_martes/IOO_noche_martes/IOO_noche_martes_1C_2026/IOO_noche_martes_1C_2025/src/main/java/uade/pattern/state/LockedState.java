package uade.pattern.state;

public class LockedState implements PhoneState {
    @Override
    public void pressButton(Smartphone phone) {
        System.out.println("Pantalla desbloqueada.");
        phone.setState(new UnlockedState());
    }
}