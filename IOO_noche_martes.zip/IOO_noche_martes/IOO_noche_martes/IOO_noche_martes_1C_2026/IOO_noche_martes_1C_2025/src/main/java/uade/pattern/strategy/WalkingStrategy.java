package uade.pattern.strategy;

public class WalkingStrategy implements RouteStrategy {
    @Override
    public void buildRoute(int a, int b) {
        System.out.println("Calculando ruta caminando desde " + a + " hasta " + b + ".");
    }
}