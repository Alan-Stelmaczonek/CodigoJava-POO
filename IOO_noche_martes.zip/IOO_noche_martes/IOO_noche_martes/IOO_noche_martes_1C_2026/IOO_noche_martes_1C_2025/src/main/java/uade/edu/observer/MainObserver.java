package uade.edu.observer;

public class MainObserver {

    public static void main(String[] args) {
        Curso curso = new Curso("Programación Orientada a Objetos");

        Alumno alumno1 = new Alumno("Lucía");
        Alumno alumno2 = new Alumno("Martín");
        Docente docente = new Docente("Alejandro");

        curso.agregarObservador(alumno1);
        curso.agregarObservador(alumno2);
        curso.agregarObservador(docente);

        curso.publicarMensaje("Ya está disponible el nuevo ejercicio de UML.");
    }
}
