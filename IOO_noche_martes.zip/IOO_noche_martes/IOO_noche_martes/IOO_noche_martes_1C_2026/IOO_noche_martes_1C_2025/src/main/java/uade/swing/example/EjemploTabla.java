package uade.swing.example;

import javax.swing.*;

public class EjemploTabla extends JFrame {

    public EjemploTabla(){

        setSize(400,300);

        String columnas[]={
                "Nombre",
                "Edad"
        };

        String datos[][]={
                {"Juan","20"},
                {"Ana","22"},
                {"Pedro","18"}
        };

        JTable tabla=
                new JTable(datos,columnas);

        JScrollPane panel=
                new JScrollPane(tabla);

        add(panel);

        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

    }

    public static void main(String[] args) {

        new EjemploTabla();

    }

}
