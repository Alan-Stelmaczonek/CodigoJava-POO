package uade.edu.mvc.controller;

import uade.edu.mvc.model.OrdenDeCompra;
import uade.edu.mvc.model.Producto;
import uade.edu.mvc.model.Proveedor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrdenDeCompraController {

    private static OrdenDeCompraController INSTANCE;

    private List<OrdenDeCompra> ordenDeCompras;

    private  ProductoController productoController;

    private ProveedorController proveedorController;


    private OrdenDeCompraController(){
        this.ordenDeCompras = new ArrayList<>();
        this.productoController = ProductoController.getInstance();
        this.proveedorController = ProveedorController.getInstance();

    }

    public static  synchronized OrdenDeCompraController getInstance(){

        if(INSTANCE == null){
            INSTANCE = new OrdenDeCompraController();
        }
        return INSTANCE;
    }

    /**
     * Crea y registra una nueva orden de compra.
     *
     * @param fecha           Fecha de la orden de compra.
     * @param codigoProducto  Código del producto a ordenar.
     * @param dniProveedor    DNI del proveedor asociado a la orden.
     * @param cantidad        Cantidad de productos en la orden.
     */
    public void altaOrdenCompra(Date fecha, int codigoProducto, int dniProveedor, int cantidad){

        Producto producto = productoController.existeProducto(codigoProducto);
        if(producto == null){
            System.err.println("No existe el producto");
            return;
        }
        Proveedor proveedor = proveedorController.existeProveedor(dniProveedor);
        if(proveedor == null){
            System.err.println("No existe el producto");
            return;
        }
        OrdenDeCompra ordenDeCompra = new OrdenDeCompra(fecha,producto,cantidad,proveedor);
        this.ordenDeCompras.add(ordenDeCompra);

    }



    /**
     * Consulta las órdenes de compra asociadas a un proveedor específico.
     *
     * @param dniProveedor DNI del proveedor a consultar.
     */
    public void consultarOrdenesDeCompraPorProveedor(int dniProveedor){

        Proveedor proveedor = proveedorController.existeProveedor(dniProveedor);
        if(proveedor == null){
            System.err.println("No existe el producto");
            return;
        }
        int cantidadOrdenes = 0;
        for(int i = 0;i<ordenDeCompras.size();i++){
            if(ordenDeCompras.get(i).getProveedor().getDni() == proveedor.getDni()){
                cantidadOrdenes++;
            }
        }

        System.out.println("Los datos del proveedor son " + proveedor.toString()
                + " la cantidad de ordenes que tiene son: " + cantidadOrdenes);
    }


}
