package uade.simulacro.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import uade.simulacro.controller.EmpresaElectricaController;
import uade.simulacro.dto.UsuarioIndustrialDTO;

public class EmpresaElectricaView extends JFrame {

    private EmpresaElectricaController controller;

    public EmpresaElectricaView() {
        controller = EmpresaElectricaController.getInstances();
        setTitle("Gestión de Usuarios - Empresa Eléctrica");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel residencialPanel = crearPanelResidencial();
        JPanel industrialPanel = crearPanelIndustrial();

        tabbedPane.addTab("Usuario Residencial", residencialPanel);
        tabbedPane.addTab("Usuario Industrial", industrialPanel);

        add(tabbedPane);
        setVisible(true);
    }

    private JPanel crearPanelResidencial() {
        JPanel panel = new JPanel(new GridLayout(10, 2));

        JTextField nombreField = new JTextField();
        JTextField dniField = new JTextField();
        JTextField calleField = new JTextField();
        JTextField alturaField = new JTextField();
        JTextField pisoField = new JTextField();
        JTextField dptoField = new JTextField();
        JTextField cpField = new JTextField();
        JTextField localidadField = new JTextField();
        JTextField provinciaField = new JTextField();

        JButton crearButton = new JButton("Crear Usuario Residencial");

        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("DNI:"));
        panel.add(dniField);
        panel.add(new JLabel("Calle:"));
        panel.add(calleField);
        panel.add(new JLabel("Altura:"));
        panel.add(alturaField);
        panel.add(new JLabel("Piso:"));
        panel.add(pisoField);
        panel.add(new JLabel("Dpto:"));
        panel.add(dptoField);
        panel.add(new JLabel("Código Postal:"));
        panel.add(cpField);
        panel.add(new JLabel("Localidad:"));
        panel.add(localidadField);
        panel.add(new JLabel("Provincia:"));
        panel.add(provinciaField);
        panel.add(crearButton);

        crearButton.addActionListener(e -> {
            int nro = controller.crearUsuarioResidencial(
                    nombreField.getText(),
                    Integer.parseInt(dniField.getText()),
                    calleField.getText(),
                    Integer.parseInt(alturaField.getText()),
                    Integer.parseInt(pisoField.getText()),
                    dptoField.getText(),
                    Integer.parseInt(cpField.getText()),
                    localidadField.getText(),
                    provinciaField.getText());

            JOptionPane.showMessageDialog(this, nro > 0 ? "Usuario creado con éxito: Nro " + nro : "Ya existe un usuario con ese DNI.");
        });

        return panel;
    }

    private JPanel crearPanelIndustrial() {
        JPanel panel = new JPanel(new GridLayout(8, 2));

        JTextField calleField = new JTextField();
        JTextField alturaField = new JTextField();
        JTextField pisoField = new JTextField();
        JTextField dptoField = new JTextField();
        JTextField cpField = new JTextField();
        JTextField localidadField = new JTextField();
        JTextField provinciaField = new JTextField();
        JTextField cuitField = new JTextField();

        JButton crearButton = new JButton("Crear Usuario Industrial");

        panel.add(new JLabel("Calle:"));
        panel.add(calleField);
        panel.add(new JLabel("Altura:"));
        panel.add(alturaField);
        panel.add(new JLabel("Piso:"));
        panel.add(pisoField);
        panel.add(new JLabel("Dpto:"));
        panel.add(dptoField);
        panel.add(new JLabel("Código Postal:"));
        panel.add(cpField);
        panel.add(new JLabel("Localidad:"));
        panel.add(localidadField);
        panel.add(new JLabel("Provincia:"));
        panel.add(provinciaField);
        panel.add(new JLabel("CUIT:"));
        panel.add(cuitField);
        panel.add(crearButton);

        crearButton.addActionListener(e -> {
            UsuarioIndustrialDTO dto = new UsuarioIndustrialDTO();
            dto.setCalle(calleField.getText());
            dto.setAltura(Integer.parseInt(alturaField.getText()));
            dto.setPiso(Integer.parseInt(pisoField.getText()));
            dto.setDpto(dptoField.getText());
            dto.setCodigoPostal(Integer.parseInt(cpField.getText()));
            dto.setLocalidad(localidadField.getText());
            dto.setProvincia(provinciaField.getText());
            dto.setCuit(cuitField.getText());

            int nro = controller.crearUsuarioInduntrial(dto);
            JOptionPane.showMessageDialog(this, nro > 0 ? "Usuario industrial creado: Nro " + nro : "Ya existe un usuario con ese CUIT.");
        });

        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(EmpresaElectricaView::new);
    }
}
