package uade.simulacro.view;

import uade.simulacro.controller.EmpresaElectricaController;
import uade.simulacro.dto.UsuarioIndustrialDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AltaUsuarioIndustrial extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldNombre;
	private JTextField textFieldCalle;
	private JTextField textFieldAlturas;
	private JTextField textFieldPiso;
	private JTextField textFieldDpto;
	private JTextField textFieldCodigo;
	private JTextField textFieldLocalidades;
	private JTextField textFieldProvincias;
	private JTextField textFieldCuit;

	private EmpresaElectricaController empresaElectricaController;

	public AltaUsuarioIndustrial() {
		empresaElectricaController = EmpresaElectricaController.getInstances();
		setTitle("Alta Usuario Industrial");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNombre = new JLabel("Nombre de Empresa:");
		lblNombre.setBounds(10, 10, 150, 20);
		contentPane.add(lblNombre);

		textFieldNombre = new JTextField();
		textFieldNombre.setBounds(170, 10, 300, 20);
		contentPane.add(textFieldNombre);

		JLabel lblCuit = new JLabel("CUIT:");
		lblCuit.setBounds(10, 40, 150, 20);
		contentPane.add(lblCuit);

		textFieldCuit = new JTextField();
		textFieldCuit.setBounds(170, 40, 300, 20);
		contentPane.add(textFieldCuit);

		JLabel lblCalle = new JLabel("Calle:");
		lblCalle.setBounds(10, 70, 150, 20);
		contentPane.add(lblCalle);

		textFieldCalle = new JTextField();
		textFieldCalle.setBounds(170, 70, 300, 20);
		contentPane.add(textFieldCalle);

		JLabel lblAltura = new JLabel("Altura:");
		lblAltura.setBounds(10, 100, 150, 20);
		contentPane.add(lblAltura);

		textFieldAlturas = new JTextField();
		textFieldAlturas.setBounds(170, 100, 80, 20);
		contentPane.add(textFieldAlturas);

		JLabel lblPiso = new JLabel("Piso:");
		lblPiso.setBounds(260, 100, 50, 20);
		contentPane.add(lblPiso);

		textFieldPiso = new JTextField();
		textFieldPiso.setBounds(310, 100, 50, 20);
		contentPane.add(textFieldPiso);

		JLabel lblDpto = new JLabel("Dpto:");
		lblDpto.setBounds(370, 100, 50, 20);
		contentPane.add(lblDpto);

		textFieldDpto = new JTextField();
		textFieldDpto.setBounds(420, 100, 50, 20);
		contentPane.add(textFieldDpto);

		JLabel lblCp = new JLabel("C.P.:");
		lblCp.setBounds(10, 130, 150, 20);
		contentPane.add(lblCp);

		textFieldCodigo = new JTextField();
		textFieldCodigo.setBounds(170, 130, 80, 20);
		contentPane.add(textFieldCodigo);

		JLabel lblLocalidad = new JLabel("Localidad:");
		lblLocalidad.setBounds(10, 160, 150, 20);
		contentPane.add(lblLocalidad);

		textFieldLocalidades = new JTextField();
		textFieldLocalidades.setBounds(170, 160, 300, 20);
		contentPane.add(textFieldLocalidades);

		JLabel lblProvincia = new JLabel("Provincia:");
		lblProvincia.setBounds(10, 190, 150, 20);
		contentPane.add(lblProvincia);

		textFieldProvincias = new JTextField();
		textFieldProvincias.setBounds(170, 190, 300, 20);
		contentPane.add(textFieldProvincias);

		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					UsuarioIndustrialDTO dto = new UsuarioIndustrialDTO();
					dto.setCalle(textFieldCalle.getText());
					dto.setAltura(Integer.parseInt(textFieldAlturas.getText()));
					dto.setPiso(Integer.parseInt(textFieldPiso.getText()));
					dto.setDpto(textFieldDpto.getText());
					dto.setCodigoPostal(Integer.parseInt(textFieldCodigo.getText()));
					dto.setLocalidad(textFieldLocalidades.getText());
					dto.setProvincia(textFieldProvincias.getText());
					dto.setCuit(textFieldCuit.getText());
					int nro = empresaElectricaController.crearUsuarioInduntrial(dto);
					if (nro > 0) {
						JOptionPane.showMessageDialog(null, "Usuario creado con Nro: " + nro);
						limpiar();
					} else {
						JOptionPane.showMessageDialog(null, "El CUIT ya existe", "Error", JOptionPane.ERROR_MESSAGE);
					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Error al procesar los datos. Verifique los campos ingresados.", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnAceptar.setBounds(100, 300, 100, 25);
		contentPane.add(btnAceptar);

		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(e -> dispose());
		btnCancelar.setBounds(280, 300, 100, 25);
		contentPane.add(btnCancelar);
	}

	private void limpiar() {
		textFieldNombre.setText("");
		textFieldCalle.setText("");
		textFieldAlturas.setText("");
		textFieldPiso.setText("");
		textFieldDpto.setText("");
		textFieldCodigo.setText("");
		textFieldLocalidades.setText("");
		textFieldProvincias.setText("");
		textFieldCuit.setText("");
	}
}
