package uade.edu.state;

public class EstadoPendiente extends EstadoPedido {

    public void avanzar(Pedido pedido) {
        System.out.println("Pedido pagado.");
        pedido.setEstado(new EstadoPagado());
    }

    public void cancelar(Pedido pedido) {
        System.out.println("Pedido cancelado.");
        pedido.setEstado(new EstadoCancelado());
    }
}