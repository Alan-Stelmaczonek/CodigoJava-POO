package uade.edu.mvc;

import uade.edu.mvc.controller.OrdenDeCompraController;
import uade.edu.mvc.controller.ProveedorController;
import uade.edu.mvc.model.OrdenDeCompra;
import uade.edu.mvc.model.Producto;
import uade.edu.mvc.model.Proveedor;
import uade.edu.mvc.view.AltaProductoView;

import java.util.*;

public class Main {
    public static void main(String[] args) {

    List<Producto> productos = new ArrayList<>();

    List<OrdenDeCompra> ordenDeCompras = new ArrayList<>();

    //Generar instancias de proveedor
    List<Proveedor> proveedores = new ArrayList<Proveedor>();
    Proveedor proveedor1 = new Proveedor("Juan", "Perez", 12345678,"232312");
    Proveedor proveedor2 = new Proveedor("Maria","Gomez", 87654321,"231235");

    proveedores.add(proveedor1);
    proveedores.add(proveedor2);


        //Alta de productos
    AltaProductoView altaProductoView = new AltaProductoView();
    altaProductoView.setTxtCodigoProducto("101");
    altaProductoView.setTxtDescripcion("Laptop Dell");
    altaProductoView.setTxtPrecioUnitario("1500.0f");
    altaProductoView.buttonAceptar();

    altaProductoView.setTxtCodigoProducto("102");
    altaProductoView.setTxtDescripcion("Mouse Logitech");
    altaProductoView.setTxtPrecioUnitario("50.0f");
    altaProductoView.buttonAceptar();

    altaProductoView.setTxtCodigoProducto("103");
    altaProductoView.setTxtDescripcion("Teclado Logitech");
    altaProductoView.setTxtPrecioUnitario("60.0f");
    altaProductoView.buttonAceptar();



    OrdenDeCompraController ordenDeCompraController = OrdenDeCompraController.getInstance();
    ordenDeCompraController.consultarOrdenesDeCompraPorProveedor(12345678);
    ordenDeCompraController.consultarOrdenesDeCompraPorProveedor(99999999);

    ordenDeCompraController.altaOrdenCompra(new Date(), 101, 12345678, 5);

    ordenDeCompraController.consultarOrdenesDeCompraPorProveedor(12345678);

    ProveedorController proveedorController = ProveedorController.getInstance();
    }
}
