package uade.edu.mvc.model;

public class Producto {

    private String descripcion;

    private int codigoProducto;

    private float precioUnitario;

    public Producto(String descripcion, int codigoProducto, float precioUnitario) {
        this.descripcion = descripcion;
        this.codigoProducto = codigoProducto;
        this.precioUnitario = precioUnitario;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(int codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public float getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(float precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "descripcion='" + descripcion + '\'' +
                ", codigoProducto=" + codigoProducto +
                ", precioUnitario=" + precioUnitario +
                '}';
    }
}
