package uade.edu.mvc.test;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uade.edu.mvc.controller.ProductoController;
import uade.edu.mvc.dto.ProductoDto;
import uade.edu.mvc.model.Producto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


class ProductoControllerTest {

    ProductoController productoController;
    ProductoDto productoDto;

    @BeforeEach
    void setUp() {
        productoController = ProductoController.getInstance();
        productoDto = new ProductoDto("Samsumg","1213","12");
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void altaDeProducto() {

        productoController.altaDeProducto(productoDto);
        Producto producto = productoController.existeProducto(1213);
        assertNotNull(producto);
        assertEquals("Samsumg",producto.getDescripcion());
    }

    @Test
    void existeProducto() {
    }
}