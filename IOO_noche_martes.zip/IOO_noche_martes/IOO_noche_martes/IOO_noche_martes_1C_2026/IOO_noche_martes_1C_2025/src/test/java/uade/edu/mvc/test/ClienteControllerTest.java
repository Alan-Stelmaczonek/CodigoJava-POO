package uade.edu.mvc.test;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uade.edu.mvc.controller.ClienteController;
import uade.edu.mvc.dto.ClienteInDTO;
import uade.edu.mvc.model.Cliente;
import uade.swing.dto.ClienteDTO;

import static org.junit.jupiter.api.Assertions.*;

class ClienteControllerTest {

    ClienteController controller;
    @BeforeEach
    void setUp() {
        controller = ClienteController.getInstance();
    }

    @Test
    void getInstance() {

       controller =  ClienteController.getInstance();
       assertNotNull(controller);

       ClienteController clienteController = ClienteController.getInstance();
       assertEquals(clienteController,controller);
    }

    @Test
    void altaClienteOKTest() throws Exception {

        ClienteInDTO dto = new ClienteInDTO("Ale", "Foglino");
       String nombre =  controller.altaCliente(dto);
       assertNotNull(nombre);
       assertEquals(dto.getNameIn(), nombre );
    }

    @Test
    void altaClienteErrorNuloTest() {

        try {
            String nombre =  controller.altaCliente(null);
        } catch (Exception e) {
            assertEquals("Error cliente es nulo.", e.getMessage());
        }

    }


    @Test
    void altaClienteErrorClienteExietTest() {

        ClienteInDTO dto = new ClienteInDTO("Marcos", "Solis");
        try {
            String nombre =  controller.altaCliente(dto);
        } catch (Exception e) {
            assertEquals("Error el cliente nombre :Marcos ya existe.", e.getMessage());
        }

    }



    @AfterEach
    void tearDown() {
        controller = null;
    }

}