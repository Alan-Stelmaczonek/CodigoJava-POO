package mvc;

import mvc.controller.*;
import mvc.dto.ComplejoDeportivoDTO;
import mvc.dto.EspacioDeportivoDTO;
import mvc.dto.ReservaDTO;
import mvc.model.clases.*;
import mvc.model.enums.*;

import org.junit.jupiter.api.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ReservaSystemTest {

    // Código del complejo creado en setUp, reutilizado en todos los tests
    String codigoComplejo;

    @BeforeEach
    void setUp() {
        // Limpiar todos los Singletons entre tests para garantizar independencia
        ReservaController.getInstancia().limpiar();
        ClienteController.getInstancia().limpiar();
        ComplejoController.getInstancia().limpiar();
        PagoController.getInstancia().limpiar();

        // Cliente base activo sin descuento
        ClienteController.getInstancia().registrarCliente(
                "11111111", "Carlos", "López", "1111-1111", "carlos@test.com");

        // Complejo base con un espacio disponible
        ComplejoDeportivoDTO dto = ComplejoController.getInstancia().registrarComplejo(
                "Complejo Test", "Av. Test 100", "4444-0000", "test@mail.com");
        codigoComplejo = dto.codigo;

        ComplejoController.getInstancia().registrarEspacio(codigoComplejo,
                new EspacioDeportivo("ESP-01", "Cancha Fútbol", 10, 1000.0,
                        EstadoEspacio.DISPONIBLE, TipoEspacio.FUTBOL, "Césped sintético"));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TEST 1: Solicitar reserva con espacio disponible → estado INGRESADA
    //
    // Cubre DS1: verifica que el sistema registra la reserva, asigna estado
    // INGRESADA, genera un código y devuelve un DTO con los datos correctos.
    // ─────────────────────────────────────────────────────────────────────────
    @Test
    @DisplayName("Test 1 — Solicitar reserva con espacio disponible genera estado INGRESADA")
    void testSolicitarReservaEspacioDisponible() {
        LocalDate fecha = LocalDate.now().plusDays(5);

        ReservaDTO resultado = ReservaController.getInstancia().solicitarReserva(
                "11111111", codigoComplejo, "ESP-01",
                fecha,
                LocalTime.of(10, 0), LocalTime.of(12, 0),
                "COMUN", "admin");

        // El DTO debe estar poblado
        assertNotNull(resultado, "El resultado no debe ser null");
        assertNotNull(resultado.codigo, "La reserva debe tener un código generado");
        assertFalse(resultado.codigo.isBlank(), "El código no debe estar vacío");

        // Estado correcto según DS1
        assertEquals("INGRESADA", resultado.estado,
                "El estado inicial de la reserva debe ser INGRESADA");

        // Datos del cliente y espacio correctamente mapeados
        assertEquals("Carlos López", resultado.nombreCliente,
                "El nombre del cliente debe estar en el DTO");
        assertEquals("Cancha Fútbol", resultado.nombreEspacio,
                "El nombre del espacio debe estar en el DTO");
        assertEquals("COMUN", resultado.tipoReserva,
                "El tipo de reserva debe ser COMUN");

        // La reserva fue agregada a la colección del controlador
        assertEquals(1, ReservaController.getInstancia().getReservas().size(),
                "Debe existir exactamente una reserva registrada");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TEST 2: Solicitar reserva con espacio no disponible → excepción, sin reserva creada
    //
    // Cubre DS1 flujo alternativo: el sistema verifica disponibilidad antes de
    // registrar. Si el espacio está ocupado o en mantenimiento, rechaza la solicitud.
    // ─────────────────────────────────────────────────────────────────────────
    @Test
    @DisplayName("Test 2 — Solicitar reserva con espacio no disponible lanza excepción y no crea reserva")
    void testSolicitarReservaEspacioNoDisponible() {
        LocalDate fecha = LocalDate.now().plusDays(3);

        // Espacio en estado NO_DISPONIBLE (no pasa el filtro de estaDisponible)
        ComplejoController.getInstancia().registrarEspacio(codigoComplejo,
                new EspacioDeportivo("ESP-02", "Cancha en Mantenimiento", 10, 1000.0,
                        EstadoEspacio.NO_DISPONIBLE, TipoEspacio.FUTBOL, "Pasto"));

        assertThrows(IllegalStateException.class,
                () -> ReservaController.getInstancia().solicitarReserva(
                        "11111111", codigoComplejo, "ESP-02",
                        fecha,
                        LocalTime.of(10, 0), LocalTime.of(12, 0),
                        "COMUN", "admin"),
                "Debe lanzarse IllegalStateException cuando el espacio no está disponible");

        // No debe haberse creado ninguna reserva
        assertEquals(0, ReservaController.getInstancia().getReservas().size(),
                "No debe haberse registrado ninguna reserva si el espacio no estaba disponible");

        // Segundo escenario: mismo espacio disponible pero con solapamiento horario
        ReservaDTO primera = ReservaController.getInstancia().solicitarReserva(
                "11111111", codigoComplejo, "ESP-01",
                fecha,
                LocalTime.of(10, 0), LocalTime.of(12, 0),
                "COMUN", "admin");
        assertNotNull(primera);

        // Intentar reservar el mismo espacio en el mismo horario → solapamiento
        assertThrows(IllegalStateException.class,
                () -> ReservaController.getInstancia().solicitarReserva(
                        "11111111", codigoComplejo, "ESP-01",
                        fecha,
                        LocalTime.of(11, 0), LocalTime.of(13, 0),
                        "COMUN", "admin"),
                "Debe rechazarse una reserva que solapa un horario ya ocupado");

        // Solo la primera reserva fue creada
        assertEquals(1, ReservaController.getInstancia().getReservas().size(),
                "Solo debe existir la primera reserva; la segunda con solapamiento no debe crearse");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TEST 3: Polimorfismo de recargo — COMUN 0%, TORNEO 20%, CLASE_GRUPAL 10%
    //
    // Cubre herencia y polimorfismo: las tres subclases de Reserva calculan
    // su recargo con reglas distintas sin modificar calcularTotal().
    // Base de prueba: 2 horas × $1000/h = $2000 precio base.
    // ─────────────────────────────────────────────────────────────────────────
    @Test
    @DisplayName("Test 3 — Polimorfismo de recargo: COMUN=0%, TORNEO=20%, CLASE_GRUPAL=10%")
    void testPolimorfismoRecargo() {
        EspacioDeportivo espacio = new EspacioDeportivo(
                "X", "Test", 10, 1000.0,
                EstadoEspacio.DISPONIBLE, TipoEspacio.FUTBOL, "X");
        Cliente cliente = new Cliente("00000000", "Test", "Test", "X", "X");
        ComplejoDeportivo complejo = new ComplejoDeportivo("X", "Test", "X", "X", "X");
        LocalDate hoy = LocalDate.now();
        LocalTime inicio = LocalTime.of(10, 0);
        LocalTime fin   = LocalTime.of(12, 0); // 2 horas → $2000 base

        // ── ReservaComun: recargo 0%, total = precio base ──
        ReservaComun comun = new ReservaComun();
        comun.inicializar(cliente, complejo, espacio, hoy, inicio, fin, "COMUN");

        assertEquals(0.0, comun.calcularRecargo(), 0.01,
                "ReservaComun: el recargo debe ser $0");
        assertEquals(2000.0, comun.calcularTotal(), 0.01,
                "ReservaComun: total = $2000 (sin recargo)");
        assertEquals("COMUN", comun.getTipoReserva(),
                "ReservaComun: getTipoReserva debe retornar 'COMUN'");

        // ── ReservaTorneo: recargo 20%, total = $2400 ──
        ReservaTorneo torneo = new ReservaTorneo(); // porcentajeRecargo default = 20%
        torneo.inicializar(cliente, complejo, espacio, hoy, inicio, fin, "TORNEO");

        assertEquals(400.0, torneo.calcularRecargo(), 0.01,
                "ReservaTorneo: el recargo debe ser 20% de $2000 = $400");
        assertEquals(2400.0, torneo.calcularTotal(), 0.01,
                "ReservaTorneo: total = $2000 + $400 = $2400");
        assertEquals("TORNEO", torneo.getTipoReserva(),
                "ReservaTorneo: getTipoReserva debe retornar 'TORNEO'");

        // ── ReservaClaseGrupal: recargo 10%, total = $2200 ──
        ReservaClaseGrupal grupal = new ReservaClaseGrupal(); // porcentajeRecargo default = 10%
        grupal.inicializar(cliente, complejo, espacio, hoy, inicio, fin, "CLASE_GRUPAL");

        assertEquals(200.0, grupal.calcularRecargo(), 0.01,
                "ReservaClaseGrupal: el recargo debe ser 10% de $2000 = $200");
        assertEquals(2200.0, grupal.calcularTotal(), 0.01,
                "ReservaClaseGrupal: total = $2000 + $200 = $2200");
        assertEquals("CLASE_GRUPAL", grupal.getTipoReserva(),
                "ReservaClaseGrupal: getTipoReserva debe retornar 'CLASE_GRUPAL'");

        // ── Recargo parametrizable: torneo con recargo personalizado ──
        ReservaTorneo torneoEspecial = new ReservaTorneo(30.0);
        torneoEspecial.inicializar(cliente, complejo, espacio, hoy, inicio, fin, "TORNEO");
        assertEquals(600.0, torneoEspecial.calcularRecargo(), 0.01,
                "ReservaTorneo con 30%: recargo debe ser $600");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TEST 4: Cancelar reserva — >24h devuelve seña como crédito, ≤24h no devuelve
    //
    // Cubre DS3 y la regla de negocio clave del enunciado:
    // "Si cancela con más de 24 horas de anticipación, la seña queda disponible
    //  como crédito a favor. Si cancela con menos de 24 horas, no se reintegra."
    // ─────────────────────────────────────────────────────────────────────────
    @Test
    @DisplayName("Test 4 — Cancelar reserva: >24h acredita seña / ≤24h no reintegra")
    void testCancelarReservaRegla24Horas() {
        Cliente cliente = ClienteController.getInstancia().buscarClientePorDni("11111111");

        // ── Escenario A: cancelación con MÁS de 24h de anticipación → debe acreditar ──
        LocalDate fechaReservaLejos = LocalDate.now().plusDays(5); // 5 días = 120h > 24h

        ReservaDTO dtoA = ReservaController.getInstancia().solicitarReserva(
                "11111111", codigoComplejo, "ESP-01",
                fechaReservaLejos,
                LocalTime.of(10, 0), LocalTime.of(12, 0), "COMUN", "admin");

        ReservaController.getInstancia().confirmarReservaConSena(
                dtoA.codigo, 500.0, MedioPago.EFECTIVO, "admin");

        double creditoAntes = cliente.getCreditoAFavor();

        // Cancela hoy (5 días antes) → anticipación = 120h > 24h → debe acreditar $500
        ReservaController.getInstancia().cancelarReserva(
                dtoA.codigo, LocalDate.now(), "admin");

        assertEquals(creditoAntes + 500.0, cliente.getCreditoAFavor(), 0.01,
                "Con más de 24h de anticipación debe acreditarse la seña al cliente");

        // ── Escenario B: cancelación con exactamente 24h de anticipación → NO acredita ──
        // calcularHorasAnticipacion usa días × 24 → plusDays(1) = 1 día = 24h (no > 24)
        ComplejoController.getInstancia().registrarEspacio(codigoComplejo,
                new EspacioDeportivo("ESP-03", "Cancha Extra", 10, 1000.0,
                        EstadoEspacio.DISPONIBLE, TipoEspacio.FUTBOL, "X"));

        LocalDate fechaReservaCerca = LocalDate.now().plusDays(1); // 1 día = 24h exactas

        ReservaDTO dtoB = ReservaController.getInstancia().solicitarReserva(
                "11111111", codigoComplejo, "ESP-03",
                fechaReservaCerca,
                LocalTime.of(10, 0), LocalTime.of(12, 0), "COMUN", "admin");

        ReservaController.getInstancia().confirmarReservaConSena(
                dtoB.codigo, 300.0, MedioPago.EFECTIVO, "admin");

        double creditoAntesB = cliente.getCreditoAFavor();

        // Cancela hoy (1 día antes) → 24h, no supera > 24h → NO acredita
        ReservaController.getInstancia().cancelarReserva(
                dtoB.codigo, LocalDate.now(), "admin");

        assertEquals(creditoAntesB, cliente.getCreditoAFavor(), 0.01,
                "Con exactamente 24h de anticipación (no > 24h) NO debe reintegrarse la seña");

        // Verificar que el estado de ambas reservas quedó CANCELADA
        List<Reserva> reservas = ReservaController.getInstancia().getReservas();
        assertTrue(reservas.stream().allMatch(r -> r.getEstado() == EstadoReserva.CANCELADA),
                "Ambas reservas deben quedar en estado CANCELADA");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TEST 5: Consultar espacios disponibles — filtra por tipo de actividad y disponibilidad
    //
    // Cubre DS5 y la query 4 del enunciado:
    // "Espacios deportivos disponibles para una fecha, horario y tipo de actividad."
    // ─────────────────────────────────────────────────────────────────────────
    @Test
    @DisplayName("Test 5 — Consultar espacios disponibles filtra por tipo y estado correctamente")
    void testConsultarEspaciosDisponibles() {
        LocalDate fecha   = LocalDate.now().plusDays(2);
        LocalTime inicio  = LocalTime.of(14, 0);
        LocalTime fin     = LocalTime.of(16, 0);

        // Agregar espacios de tenis: uno disponible, uno en mantenimiento
        ComplejoController.getInstancia().registrarEspacio(codigoComplejo,
                new EspacioDeportivo("TEN-01", "Tenis Disponible", 4, 1500.0,
                        EstadoEspacio.DISPONIBLE, TipoEspacio.TENIS, "Polvo de ladrillo"));
        ComplejoController.getInstancia().registrarEspacio(codigoComplejo,
                new EspacioDeportivo("TEN-02", "Tenis Mantenimiento", 4, 1500.0,
                        EstadoEspacio.MANTENIMIENTO, TipoEspacio.TENIS, "Dura"));

        // Agregar un espacio de pádel disponible (no debe aparecer en búsqueda de tenis)
        ComplejoController.getInstancia().registrarEspacio(codigoComplejo,
                new EspacioDeportivo("PAD-01", "Pádel Disponible", 4, 1800.0,
                        EstadoEspacio.DISPONIBLE, TipoEspacio.PADEL, "Cristal"));

        // ── Consulta por TENIS: solo debe retornar TEN-01 ──
        List<EspacioDeportivoDTO> tenis = ComplejoController.getInstancia()
                .consultarEspaciosDisponibles(codigoComplejo, fecha, inicio, fin, TipoEspacio.TENIS);

        assertEquals(1, tenis.size(),
                "Solo debe retornarse el espacio de tenis en estado DISPONIBLE");
        assertEquals("TEN-01", tenis.get(0).codigo,
                "El espacio retornado debe ser TEN-01");
        assertEquals("DISPONIBLE", tenis.get(0).estado,
                "El espacio retornado debe estar en estado DISPONIBLE");

        // ── Consulta por PADEL: debe retornar PAD-01 ──
        List<EspacioDeportivoDTO> padel = ComplejoController.getInstancia()
                .consultarEspaciosDisponibles(codigoComplejo, fecha, inicio, fin, TipoEspacio.PADEL);

        assertEquals(1, padel.size(),
                "Debe retornarse el espacio de pádel disponible");
        assertEquals("PAD-01", padel.get(0).codigo);

        // ── Consulta por SALON_MULTIUSO: no hay ninguno → lista vacía ──
        List<EspacioDeportivoDTO> salon = ComplejoController.getInstancia()
                .consultarEspaciosDisponibles(codigoComplejo, fecha, inicio, fin, TipoEspacio.SALON_MULTIUSO);

        assertTrue(salon.isEmpty(),
                "No debe retornarse ningún espacio si no hay de ese tipo");

        // ── Espacio de fútbol ya reservado no debe aparecer como disponible ──
        ReservaController.getInstancia().solicitarReserva(
                "11111111", codigoComplejo, "ESP-01",
                fecha, inicio, fin, "COMUN", "admin");

        List<EspacioDeportivoDTO> futbolOcupado = ComplejoController.getInstancia()
                .consultarEspaciosDisponibles(codigoComplejo, fecha, inicio, fin, TipoEspacio.FUTBOL);

        assertTrue(futbolOcupado.isEmpty(),
                "El espacio de fútbol ya reservado no debe aparecer como disponible en ese horario");
    }
}
