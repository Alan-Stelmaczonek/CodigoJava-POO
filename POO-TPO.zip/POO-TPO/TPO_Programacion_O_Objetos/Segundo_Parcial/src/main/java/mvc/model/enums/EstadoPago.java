package mvc.model.enums;
public enum EstadoPago { REGISTRADO, CONFIRMADO, ANULADO }
