package mvc.model.clases;

public class ReservaTorneo extends Reserva {
    private double porcentajeRecargo;

    public ReservaTorneo() {
        super();
        this.porcentajeRecargo = 20.0;
    }

    public ReservaTorneo(double porcentajeRecargo) {
        super();
        this.porcentajeRecargo = porcentajeRecargo;
    }

    @Override
    public double calcularRecargo() {
        return calcularPrecioBase() * (porcentajeRecargo / 100.0);
    }

    @Override
    public String getTipoReserva() {
        return "TORNEO";
    }

    public double getPorcentajeRecargo() { return porcentajeRecargo; }
    public void setPorcentajeRecargo(double p) { this.porcentajeRecargo = p; }
}
