package mvc;

import mvc.controller.ClienteController;
import mvc.controller.ComplejoController;
import mvc.dto.ComplejoDeportivoDTO;
import mvc.model.clases.Cliente;
import mvc.model.clases.Descuento;
import mvc.model.clases.EspacioDeportivo;
import mvc.model.enums.EstadoEspacio;
import mvc.model.enums.TipoEspacio;
import mvc.view.MenuPrincipalView;

import javax.swing.*;
import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {
        cargarDatosDemo();
        SwingUtilities.invokeLater(() -> {
            MenuPrincipalView menu = new MenuPrincipalView();
            menu.setVisible(true);
        });
    }

    private static void cargarDatosDemo() {
        ClienteController cc = ClienteController.getInstancia();

        cc.registrarCliente("12345678", "Juan", "Pérez", "1111-1111", "juan@mail.com");
        cc.registrarCliente("87654321", "María", "García", "2222-2222", "maria@mail.com");

        // María tiene un descuento del 15% vigente
        Cliente maria = cc.buscarClientePorDni("87654321");
        maria.agregarDescuento(new Descuento(15.0,
                LocalDate.now().minusMonths(1),
                LocalDate.now().plusMonths(1)));

        ComplejoController cmc = ComplejoController.getInstancia();

        // Complejo Norte
        ComplejoDeportivoDTO norte = cmc.registrarComplejo("Complejo Norte", "Av. Siempreviva 742", "4444-4444", "norte@mail.com");
        cmc.registrarEspacio(norte.codigo, new EspacioDeportivo(
                "ESP-01", "Cancha Fútbol 5", 10, 2000.0,
                EstadoEspacio.DISPONIBLE, TipoEspacio.FUTBOL, "Césped sintético"));
        cmc.registrarEspacio(norte.codigo, new EspacioDeportivo(
                "ESP-02", "Cancha de Tenis A", 4, 1500.0,
                EstadoEspacio.DISPONIBLE, TipoEspacio.TENIS, "Polvo de ladrillo"));
        cmc.registrarEspacio(norte.codigo, new EspacioDeportivo(
                "ESP-03", "Cancha Pádel 1", 4, 1800.0,
                EstadoEspacio.NO_DISPONIBLE, TipoEspacio.PADEL, "Cristal"));

        // Complejo Sur
        ComplejoDeportivoDTO sur = cmc.registrarComplejo("Complejo Sur", "Calle Falsa 123", "5555-5555", "sur@mail.com");
        cmc.registrarEspacio(sur.codigo, new EspacioDeportivo(
                "ESP-04", "Salón Multiuso A", 30, 3000.0,
                EstadoEspacio.DISPONIBLE, TipoEspacio.SALON_MULTIUSO, "Parquet"));
        cmc.registrarEspacio(sur.codigo, new EspacioDeportivo(
                "ESP-05", "Cancha Fútbol 11", 22, 4000.0,
                EstadoEspacio.DISPONIBLE, TipoEspacio.FUTBOL, "Grass natural"));
    }
}
