package mvc.view;

import javax.swing.*;
import java.awt.*;

public class MenuPrincipalView extends JFrame {

    public MenuPrincipalView() {
        setTitle("Sistema de Reservas Deportivas");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(420, 220);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel titulo = new JLabel("Sistema de Gestión de Reservas", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 16));
        titulo.setBorder(BorderFactory.createEmptyBorder(25, 0, 15, 0));
        add(titulo, BorderLayout.NORTH);

        JPanel panelBotones = new JPanel(new GridLayout(1, 2, 15, 0));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 50, 50, 50));

        JButton btnSolicitar = new JButton("Solicitar Reserva");
        JButton btnConsultar = new JButton("Consultar Espacios");

        btnSolicitar.addActionListener(e -> new SolicitarReservaView().setVisible(true));
        btnConsultar.addActionListener(e -> new ConsultarEspaciosView().setVisible(true));

        panelBotones.add(btnSolicitar);
        panelBotones.add(btnConsultar);
        add(panelBotones, BorderLayout.CENTER);
    }
}
