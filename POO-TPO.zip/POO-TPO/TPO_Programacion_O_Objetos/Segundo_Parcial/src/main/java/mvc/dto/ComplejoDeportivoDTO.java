package mvc.dto;

public class ComplejoDeportivoDTO {
    public String codigo;
    public String nombre;
    public String direccion;
    public String telefono;
    public String email;
    public String estado;

    @Override
    public String toString() {
        return nombre + " (" + direccion + ")";
    }
}
