package mvc.controller;

import mvc.dto.ComplejoDeportivoDTO;
import mvc.dto.EspacioDeportivoDTO;
import mvc.model.clases.ComplejoDeportivo;
import mvc.model.clases.EspacioDeportivo;
import mvc.model.enums.TipoEspacio;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ComplejoController {

    private static ComplejoController instancia;
    private List<ComplejoDeportivo> complejos;

    private ComplejoController() {
        complejos = new ArrayList<>();
    }

    public static ComplejoController getInstancia() {
        if (instancia == null) {
            instancia = new ComplejoController();
        }
        return instancia;
    }

    public ComplejoDeportivoDTO registrarComplejo(String nombre, String direccion,
                                                   String telefono, String email) {
        String codigo = "CMP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        ComplejoDeportivo complejo = new ComplejoDeportivo(codigo, nombre, direccion, telefono, email);
        complejos.add(complejo);
        return mapToDTO(complejo);
    }

    public EspacioDeportivoDTO registrarEspacio(String codigoComplejo, EspacioDeportivo espacio) {
        ComplejoDeportivo complejo = buscarComplejo(codigoComplejo);
        if (complejo == null)
            throw new IllegalArgumentException("Complejo no encontrado: " + codigoComplejo);
        complejo.agregarEspacio(espacio);
        return mapEspacioToDTO(espacio);
    }

    public List<EspacioDeportivoDTO> consultarEspaciosDisponibles(String codigoComplejo, LocalDate fecha,
            LocalTime horaInicio, LocalTime horaFin, TipoEspacio tipoActividad) {
        List<EspacioDeportivoDTO> resultado = new ArrayList<>();
        for (ComplejoDeportivo c : complejos) {
            if (c.coincideCodigo(codigoComplejo)) {
                for (EspacioDeportivo e : c.obtenerEspacios()) {
                    if (e.coincideTipoActividad(tipoActividad) && e.estaDisponible(fecha, horaInicio, horaFin)) {
                        resultado.add(mapEspacioToDTO(e));
                    }
                }
                break;
            }
        }
        return resultado;
    }

    public List<ComplejoDeportivoDTO> getComplejos() {
        List<ComplejoDeportivoDTO> resultado = new ArrayList<>();
        for (ComplejoDeportivo c : complejos) resultado.add(mapToDTO(c));
        return resultado;
    }

    public List<EspacioDeportivoDTO> getEspaciosDeComplejo(String codigoComplejo) {
        ComplejoDeportivo complejo = buscarComplejo(codigoComplejo);
        if (complejo == null) return new ArrayList<>();
        List<EspacioDeportivoDTO> resultado = new ArrayList<>();
        for (var e : complejo.obtenerEspacios()) resultado.add(mapEspacioToDTO(e));
        return resultado;
    }

    public ComplejoDeportivo buscarComplejo(String codigoComplejo) {
        for (ComplejoDeportivo c : complejos) {
            if (c.coincideCodigo(codigoComplejo)) return c;
        }
        return null;
    }

    private ComplejoDeportivoDTO mapToDTO(ComplejoDeportivo c) {
        ComplejoDeportivoDTO dto = new ComplejoDeportivoDTO();
        dto.codigo = c.getCodigo();
        dto.nombre = c.getNombre();
        dto.direccion = c.getDireccion();
        dto.telefono = c.getTelefono();
        dto.email = c.getEmail();
        dto.estado = c.getEstado().name();
        return dto;
    }

    private EspacioDeportivoDTO mapEspacioToDTO(EspacioDeportivo e) {
        EspacioDeportivoDTO dto = new EspacioDeportivoDTO();
        dto.codigo = e.getCodigo();
        dto.nombre = e.getNombre();
        dto.capacidad = e.getCapacidad();
        dto.precioBaseHora = e.getPrecioBaseHora();
        dto.tipoEspacio = e.getTipoEspacio().name();
        dto.superficie = e.getSuperficie();
        dto.estado = e.getEstado().name();
        return dto;
    }

    public void limpiar() {
        complejos.clear();
    }
}
