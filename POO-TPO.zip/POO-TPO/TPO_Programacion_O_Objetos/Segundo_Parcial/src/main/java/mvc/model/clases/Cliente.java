package mvc.model.clases;

import mvc.model.enums.EstadoCliente;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Cliente {
    private String dni;
    private String nombre;
    private String apellido;
    private String telefono;
    private String email;
    private EstadoCliente estado;
    private double creditoAFavor;
    private List<Descuento> descuentos;

    public Cliente(String dni, String nombre, String apellido, String telefono, String email) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.email = email;
        this.estado = EstadoCliente.ACTIVO;
        this.creditoAFavor = 0;
        this.descuentos = new ArrayList<>();
    }

    public boolean coincideDni(String dni) {
        return this.dni.equals(dni);
    }

    public boolean estaActivo() {
        return this.estado == EstadoCliente.ACTIVO;
    }

    public void agregarCredito(double importe) {
        this.creditoAFavor += importe;
    }

    public Descuento obtenerDescuentoVigente(LocalDate fecha) {
        for (Descuento d : descuentos) {
            if (d.estaVigente(fecha)) return d;
        }
        return null;
    }

    public void agregarDescuento(Descuento descuento) {
        descuentos.add(descuento);
    }

    public String getDni() { return dni; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getTelefono() { return telefono; }
    public String getEmail() { return email; }
    public EstadoCliente getEstado() { return estado; }
    public double getCreditoAFavor() { return creditoAFavor; }
    public List<Descuento> getDescuentos() { return new ArrayList<>(descuentos); }
}
