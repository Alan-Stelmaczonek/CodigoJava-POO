package mvc.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class ReservaDTO {
    public String codigo;
    public LocalDate fecha;
    public LocalTime horaInicio;
    public LocalTime horaFin;
    public String estado;
    public String tipoReserva;
    public double importeSena;
    public double saldoPendiente;
    public String nombreCliente;
    public String nombreEspacio;

    @Override
    public String toString() {
        return "Código: " + codigo +
               " | Tipo: " + tipoReserva +
               " | Cliente: " + nombreCliente +
               " | Espacio: " + nombreEspacio +
               " | Fecha: " + fecha + " " + horaInicio + "-" + horaFin +
               " | Estado: " + estado;
    }
}
