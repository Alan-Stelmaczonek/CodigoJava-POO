package mvc.model.enums;
public enum MedioPago { EFECTIVO, TRANSFERENCIA, TARJETA, BILLETERA_VIRTUAL }
