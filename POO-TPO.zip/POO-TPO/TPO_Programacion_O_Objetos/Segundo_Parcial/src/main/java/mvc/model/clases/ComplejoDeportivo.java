package mvc.model.clases;

import mvc.model.enums.EstadoComplejo;
import mvc.model.enums.TipoEspacio;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class ComplejoDeportivo {
    private String codigo;
    private String nombre;
    private String direccion;
    private String telefono;
    private String email;
    private EstadoComplejo estado;
    private List<EspacioDeportivo> espacios;

    public ComplejoDeportivo(String codigo, String nombre, String direccion, String telefono, String email) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.estado = EstadoComplejo.ACTIVO;
        this.espacios = new ArrayList<>();
    }

    public boolean coincideCodigo(String codigo) {
        return this.codigo.equals(codigo);
    }

    public void agregarEspacio(EspacioDeportivo espacio) {
        espacios.add(espacio);
    }

    public EspacioDeportivo buscarEspacio(String codigoEspacio) {
        for (EspacioDeportivo e : espacios) {
            if (e.coincideCodigo(codigoEspacio)) return e;
        }
        return null;
    }

    public List<EspacioDeportivo> obtenerEspacios() {
        return new ArrayList<>(espacios);
    }

    public List<EspacioDeportivo> obtenerEspaciosDisponibles(LocalDate fecha, LocalTime horaInicio,
                                                              LocalTime horaFin, TipoEspacio tipo) {
        List<EspacioDeportivo> disponibles = new ArrayList<>();
        for (EspacioDeportivo e : espacios) {
            if (e.coincideTipoActividad(tipo) && e.estaDisponible(fecha, horaInicio, horaFin)) {
                disponibles.add(e);
            }
        }
        return disponibles;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getDireccion() { return direccion; }
    public String getTelefono() { return telefono; }
    public String getEmail() { return email; }
    public EstadoComplejo getEstado() { return estado; }
}
