package mvc.view;

import mvc.controller.ComplejoController;
import mvc.dto.ComplejoDeportivoDTO;
import mvc.dto.EspacioDeportivoDTO;
import mvc.model.enums.TipoEspacio;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;

public class ConsultarEspaciosView extends JFrame {

    private JComboBox<ComplejoDeportivoDTO> cmbComplejo;
    private JTextField txtFecha, txtHoraInicio, txtHoraFin;
    private JComboBox<TipoEspacio> cmbTipo;
    private JTable tabla;
    private DefaultTableModel modeloTabla;

    public ConsultarEspaciosView() {
        setTitle("Consultar Espacios Disponibles");
        setSize(650, 420);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel filtros = new JPanel(new GridLayout(3, 4, 8, 8));
        filtros.setBorder(BorderFactory.createTitledBorder("Filtros de búsqueda"));

        cmbComplejo   = new JComboBox<>();
        txtFecha      = new JTextField(LocalDate.now().toString());
        txtHoraInicio = new JTextField("10:00");
        txtHoraFin    = new JTextField("12:00");
        cmbTipo       = new JComboBox<>(TipoEspacio.values());

        for (ComplejoDeportivoDTO c : ComplejoController.getInstancia().getComplejos())
            cmbComplejo.addItem(c);

        filtros.add(new JLabel("Complejo:"));           filtros.add(cmbComplejo);
        filtros.add(new JLabel("Fecha (yyyy-MM-dd):")); filtros.add(txtFecha);
        filtros.add(new JLabel("Hora Inicio:"));        filtros.add(txtHoraInicio);
        filtros.add(new JLabel("Hora Fin:"));           filtros.add(txtHoraFin);
        filtros.add(new JLabel("Tipo Actividad:"));     filtros.add(cmbTipo);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> buscarEspacios());
        filtros.add(new JLabel(""));
        filtros.add(btnBuscar);

        modeloTabla = new DefaultTableModel(
                new String[]{"Código", "Nombre", "Tipo", "Precio/h", "Superficie", "Estado"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        add(filtros, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }

    private void buscarEspacios() {
        ComplejoDeportivoDTO complejo = (ComplejoDeportivoDTO) cmbComplejo.getSelectedItem();
        if (complejo == null) {
            JOptionPane.showMessageDialog(this, "Seleccione un complejo.",
                    "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDate fecha;
        LocalTime horaInicio, horaFin;
        try {
            fecha      = LocalDate.parse(txtFecha.getText().trim());
            horaInicio = LocalTime.parse(txtHoraInicio.getText().trim());
            horaFin    = LocalTime.parse(txtHoraFin.getText().trim());
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Formato de fecha u hora inválido.",
                    "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            List<EspacioDeportivoDTO> espacios = ComplejoController.getInstancia()
                    .consultarEspaciosDisponibles(
                            complejo.codigo, fecha, horaInicio, horaFin,
                            (TipoEspacio) cmbTipo.getSelectedItem());

            modeloTabla.setRowCount(0);
            for (EspacioDeportivoDTO e : espacios) {
                modeloTabla.addRow(new Object[]{
                        e.codigo, e.nombre, e.tipoEspacio, "$" + e.precioBaseHora, e.superficie, e.estado
                });
            }
            if (espacios.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "No se encontraron espacios disponibles para los filtros ingresados.",
                        "Sin resultados", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
