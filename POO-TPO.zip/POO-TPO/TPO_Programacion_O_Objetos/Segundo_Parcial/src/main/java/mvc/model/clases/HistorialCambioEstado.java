package mvc.model.clases;

import java.time.LocalDate;

public class HistorialCambioEstado {
    private LocalDate fechaCambio;
    private String estadoAnterior;
    private String estadoNuevo;
    private String tipoEntidad;
    private String referencia;
    private String usuarioResponsable;

    public HistorialCambioEstado() {}

    public void registrarCambio(String estadoAnterior, String estadoNuevo,
                                 String tipoEntidad, String referencia, String usuario) {
        this.fechaCambio = LocalDate.now();
        this.estadoAnterior = estadoAnterior != null ? estadoAnterior : "NINGUNO";
        this.estadoNuevo = estadoNuevo;
        this.tipoEntidad = tipoEntidad;
        this.referencia = referencia;
        this.usuarioResponsable = usuario;
    }

    public LocalDate getFechaCambio() { return fechaCambio; }
    public String getEstadoAnterior() { return estadoAnterior; }
    public String getEstadoNuevo() { return estadoNuevo; }
    public String getTipoEntidad() { return tipoEntidad; }
    public String getReferencia() { return referencia; }
    public String getUsuarioResponsable() { return usuarioResponsable; }
}
