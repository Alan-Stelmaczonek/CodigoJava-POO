package mvc.controller;

import mvc.model.clases.Pago;
import mvc.model.enums.EstadoPago;
import mvc.model.enums.MedioPago;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PagoController {

    private static PagoController instancia;
    private List<Pago> pagos;

    private PagoController() {
        pagos = new ArrayList<>();
    }

    public static PagoController getInstancia() {
        if (instancia == null) {
            instancia = new PagoController();
        }
        return instancia;
    }

    public Pago registrarPago(String codigoReserva, double importe, MedioPago medioPago, String usuario) {
        Pago pago = new Pago();
        pago.inicializar(LocalDate.now(), importe, medioPago, EstadoPago.REGISTRADO, usuario);
        pago.confirmar();
        pagos.add(pago);
        return pago;
    }

    public void anularPago(Pago pago) {
        pago.anular();
    }

    public void limpiar() {
        pagos.clear();
    }
}
