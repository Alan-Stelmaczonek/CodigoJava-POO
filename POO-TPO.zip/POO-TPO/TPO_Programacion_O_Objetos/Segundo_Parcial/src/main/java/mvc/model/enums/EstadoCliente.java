package mvc.model.enums;
public enum EstadoCliente { ACTIVO, INACTIVO }
