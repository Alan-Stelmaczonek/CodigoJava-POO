package mvc.model.enums;
public enum EstadoEspacio { DISPONIBLE, NO_DISPONIBLE, MANTENIMIENTO }
