package mvc.model.enums;
public enum EstadoReserva { INGRESADA, CONFIRMADA, CANCELADA, EN_CURSO, FINALIZADA }
