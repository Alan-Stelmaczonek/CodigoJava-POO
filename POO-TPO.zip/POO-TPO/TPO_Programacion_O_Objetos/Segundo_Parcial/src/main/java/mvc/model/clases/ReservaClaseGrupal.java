package mvc.model.clases;

public class ReservaClaseGrupal extends Reserva {
    private double porcentajeRecargo;

    public ReservaClaseGrupal() {
        super();
        this.porcentajeRecargo = 10.0;
    }

    public ReservaClaseGrupal(double porcentajeRecargo) {
        super();
        this.porcentajeRecargo = porcentajeRecargo;
    }

    @Override
    public double calcularRecargo() {
        return calcularPrecioBase() * (porcentajeRecargo / 100.0);
    }

    @Override
    public String getTipoReserva() {
        return "CLASE_GRUPAL";
    }

    public double getPorcentajeRecargo() { return porcentajeRecargo; }
    public void setPorcentajeRecargo(double p) { this.porcentajeRecargo = p; }
}
