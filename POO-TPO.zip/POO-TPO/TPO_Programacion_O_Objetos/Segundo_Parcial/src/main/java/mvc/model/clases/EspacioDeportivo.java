package mvc.model.clases;

import mvc.model.enums.EstadoEspacio;
import mvc.model.enums.TipoEspacio;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class EspacioDeportivo {
    private String codigo;
    private String nombre;
    private int capacidad;
    private double precioBaseHora;
    private EstadoEspacio estado;
    private TipoEspacio tipoEspacio;
    private String superficie;
    private List<ReservaOcupacion> ocupaciones = new ArrayList<>();

    private static class ReservaOcupacion {
        LocalDate fecha;
        LocalTime horaInicio;
        LocalTime horaFin;
        ReservaOcupacion(LocalDate f, LocalTime hi, LocalTime hf) {
            this.fecha = f; this.horaInicio = hi; this.horaFin = hf;
        }
        boolean solapa(LocalDate f, LocalTime hi, LocalTime hf) {
            return this.fecha.equals(f) && hi.isBefore(this.horaFin) && hf.isAfter(this.horaInicio);
        }
    }

    public EspacioDeportivo(String codigo, String nombre, int capacidad, double precioBaseHora,
                             EstadoEspacio estado, TipoEspacio tipoEspacio, String superficie) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.precioBaseHora = precioBaseHora;
        this.estado = estado;
        this.tipoEspacio = tipoEspacio;
        this.superficie = superficie;
    }

    public boolean coincideCodigo(String codigo) {
        return this.codigo.equals(codigo);
    }

    public boolean coincideTipoActividad(TipoEspacio tipo) {
        return this.tipoEspacio == tipo;
    }

    public boolean estaDisponible(LocalDate fecha, LocalTime horaInicio, LocalTime horaFin) {
        if (this.estado != EstadoEspacio.DISPONIBLE) return false;
        for (ReservaOcupacion o : ocupaciones) {
            if (o.solapa(fecha, horaInicio, horaFin)) return false;
        }
        return true;
    }

    public void registrarOcupacion(LocalDate fecha, LocalTime horaInicio, LocalTime horaFin) {
        ocupaciones.add(new ReservaOcupacion(fecha, horaInicio, horaFin));
    }

    public void liberarOcupacion(LocalDate fecha, LocalTime horaInicio, LocalTime horaFin) {
        ocupaciones.removeIf(o -> o.solapa(fecha, horaInicio, horaFin));
    }

    public double calcularPrecioBase(double cantidadHoras) {
        return cantidadHoras * precioBaseHora;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public int getCapacidad() { return capacidad; }
    public double getPrecioBaseHora() { return precioBaseHora; }
    public EstadoEspacio getEstado() { return estado; }
    public TipoEspacio getTipoEspacio() { return tipoEspacio; }
    public String getSuperficie() { return superficie; }
    public void setEstado(EstadoEspacio estado) { this.estado = estado; }
}
