package mvc.dto;

public class EspacioDeportivoDTO {
    public String codigo;
    public String nombre;
    public int capacidad;
    public double precioBaseHora;
    public String tipoEspacio;
    public String superficie;
    public String estado;

    @Override
    public String toString() {
        return "[" + codigo + "] " + nombre + " (" + tipoEspacio + ") - $" + precioBaseHora + "/h - " + superficie;
    }
}
