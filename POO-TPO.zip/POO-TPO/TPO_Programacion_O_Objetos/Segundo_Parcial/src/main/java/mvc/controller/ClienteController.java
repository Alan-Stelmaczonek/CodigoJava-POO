package mvc.controller;

import mvc.dto.ClienteDTO;
import mvc.model.clases.Cliente;
import mvc.model.clases.Descuento;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ClienteController {

    private static ClienteController instancia;
    private List<Cliente> clientes;

    private ClienteController() {
        clientes = new ArrayList<>();
    }

    public static ClienteController getInstancia() {
        if (instancia == null) {
            instancia = new ClienteController();
        }
        return instancia;
    }

    public ClienteDTO registrarCliente(String dni, String nombre, String apellido,
                                        String telefono, String email) {
        Cliente cliente = new Cliente(dni, nombre, apellido, telefono, email);
        clientes.add(cliente);
        return mapToDTO(cliente);
    }

    public Cliente buscarClientePorDni(String dni) {
        for (Cliente c : clientes) {
            if (c.coincideDni(dni)) return c;
        }
        return null;
    }

    public Descuento obtenerDescuentoVigente(String dni, LocalDate fecha) {
        Cliente cliente = buscarClientePorDni(dni);
        if (cliente == null) return null;
        return cliente.obtenerDescuentoVigente(fecha);
    }

    private ClienteDTO mapToDTO(Cliente c) {
        ClienteDTO dto = new ClienteDTO();
        dto.dni = c.getDni();
        dto.nombre = c.getNombre();
        dto.apellido = c.getApellido();
        dto.telefono = c.getTelefono();
        dto.email = c.getEmail();
        dto.estado = c.getEstado().name();
        dto.creditoAFavor = c.getCreditoAFavor();
        return dto;
    }

    public void limpiar() {
        clientes.clear();
    }
}
