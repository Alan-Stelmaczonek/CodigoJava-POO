package mvc.dto;

public class ClienteDTO {
    public String dni;
    public String nombre;
    public String apellido;
    public String telefono;
    public String email;
    public String estado;
    public double creditoAFavor;

    @Override
    public String toString() {
        return nombre + " " + apellido + " (DNI: " + dni + ") - Crédito: $" + creditoAFavor;
    }
}
