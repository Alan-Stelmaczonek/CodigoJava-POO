package mvc.model.enums;
public enum EstadoComplejo { ACTIVO, INACTIVO }
