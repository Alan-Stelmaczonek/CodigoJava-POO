package mvc.model.clases;

import mvc.model.enums.EstadoReserva;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public abstract class Reserva {
    private String codigo;
    private LocalDate fecha;
    private LocalTime horaInicio;
    private LocalTime horaFin;
    private EstadoReserva estado;
    private double importeSena;
    private double porcentajeDescuentoAplicado;
    private List<Pago> pagos;
    private Cliente cliente;
    private ComplejoDeportivo complejo;
    private EspacioDeportivo espacio;

    public Reserva() {
        this.pagos = new ArrayList<>();
        this.porcentajeDescuentoAplicado = 0;
    }

    public void inicializar(Cliente cliente, ComplejoDeportivo complejo, EspacioDeportivo espacio,
                             LocalDate fecha, LocalTime horaInicio, LocalTime horaFin, String tipoReserva) {
        this.codigo = "RES-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.cliente = cliente;
        this.complejo = complejo;
        this.espacio = espacio;
        this.fecha = fecha;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.estado = EstadoReserva.INGRESADA;
        this.importeSena = 0;
    }

    public boolean coincideCodigo(String codigo) {
        return this.codigo.equals(codigo);
    }

    public void cambiarEstado(EstadoReserva nuevoEstado, String usuario) {
        this.estado = nuevoEstado;
    }

    public boolean estaConfirmada() {
        return this.estado == EstadoReserva.CONFIRMADA;
    }

    public Cliente obtenerCliente() {
        return cliente;
    }

    public double obtenerImporteSena() {
        return importeSena;
    }

    public void registrarImporteSena(double importe) {
        this.importeSena = importe;
    }

    public void agregarPago(Pago pago) {
        pagos.add(pago);
    }

    public double calcularHorasAnticipacion(LocalDate fechaCancelacion) {
        long dias = ChronoUnit.DAYS.between(fechaCancelacion, this.fecha);
        return dias * 24.0;
    }

    public double calcularPrecioBase() {
        double horas = Duration.between(horaInicio, horaFin).toMinutes() / 60.0;
        return espacio.calcularPrecioBase(horas);
    }

    public abstract double calcularRecargo();

    public double calcularTotal() {
        return calcularPrecioBase() + calcularRecargo();
    }

    public void aplicarDescuento(double porcentaje) {
        this.porcentajeDescuentoAplicado = porcentaje;
    }

    public double calcularSaldoPendiente() {
        double total = calcularTotal();
        double descuento = total * (porcentajeDescuentoAplicado / 100.0);
        return total - descuento - importeSena;
    }

    public abstract String getTipoReserva();

    public String getCodigo() { return codigo; }
    public LocalDate getFecha() { return fecha; }
    public LocalTime getHoraInicio() { return horaInicio; }
    public LocalTime getHoraFin() { return horaFin; }
    public EstadoReserva getEstado() { return estado; }
    public double getImporteSena() { return importeSena; }
    public double getPorcentajeDescuentoAplicado() { return porcentajeDescuentoAplicado; }
    public List<Pago> getPagos() { return new ArrayList<>(pagos); }
    public ComplejoDeportivo getComplejo() { return complejo; }
    public EspacioDeportivo getEspacio() { return espacio; }
}
