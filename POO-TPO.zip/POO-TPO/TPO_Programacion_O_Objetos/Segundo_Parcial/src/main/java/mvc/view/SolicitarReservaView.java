package mvc.view;

import mvc.controller.ComplejoController;
import mvc.controller.ReservaController;
import mvc.dto.ComplejoDeportivoDTO;
import mvc.dto.EspacioDeportivoDTO;
import mvc.dto.ReservaDTO;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;

public class SolicitarReservaView extends JFrame {

    private JTextField txtDni, txtFecha, txtHoraInicio, txtHoraFin, txtUsuario;
    private JComboBox<ComplejoDeportivoDTO> cmbComplejo;
    private JComboBox<EspacioDeportivoDTO> cmbEspacio;
    private JComboBox<String> cmbTipo;
    private JTextArea txtResultado;

    public SolicitarReservaView() {
        setTitle("Solicitar Reserva");
        setSize(520, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel form = new JPanel(new GridLayout(9, 2, 5, 10));
        form.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        txtDni        = new JTextField();
        cmbComplejo   = new JComboBox<>();
        cmbEspacio    = new JComboBox<>();
        txtFecha      = new JTextField(LocalDate.now().plusDays(3).toString());
        txtHoraInicio = new JTextField("10:00");
        txtHoraFin    = new JTextField("12:00");
        cmbTipo       = new JComboBox<>(new String[]{"COMUN", "TORNEO", "CLASE_GRUPAL"});
        txtUsuario    = new JTextField("admin");

        cargarComplejos();

        cmbComplejo.addActionListener(e -> cargarEspacios());

        form.add(new JLabel("DNI Cliente:"));           form.add(txtDni);
        form.add(new JLabel("Complejo:"));              form.add(cmbComplejo);
        form.add(new JLabel("Espacio:"));               form.add(cmbEspacio);
        form.add(new JLabel("Fecha (yyyy-MM-dd):"));    form.add(txtFecha);
        form.add(new JLabel("Hora Inicio (HH:mm):"));   form.add(txtHoraInicio);
        form.add(new JLabel("Hora Fin (HH:mm):"));      form.add(txtHoraFin);
        form.add(new JLabel("Tipo Reserva:"));          form.add(cmbTipo);
        form.add(new JLabel("Usuario:"));               form.add(txtUsuario);

        JButton btnSolicitar = new JButton("Solicitar Reserva");
        btnSolicitar.addActionListener(e -> solicitarReserva());
        JPanel panelBtn = new JPanel();
        panelBtn.add(btnSolicitar);

        txtResultado = new JTextArea(5, 40);
        txtResultado.setEditable(false);
        txtResultado.setLineWrap(true);
        txtResultado.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(txtResultado);
        scroll.setBorder(BorderFactory.createTitledBorder("Resultado"));

        JPanel south = new JPanel(new BorderLayout(5, 5));
        south.setBorder(BorderFactory.createEmptyBorder(0, 20, 15, 20));
        south.add(panelBtn, BorderLayout.NORTH);
        south.add(scroll, BorderLayout.CENTER);

        add(form, BorderLayout.NORTH);
        add(south, BorderLayout.CENTER);
    }

    private void cargarComplejos() {
        cmbComplejo.removeAllItems();
        List<ComplejoDeportivoDTO> complejos = ComplejoController.getInstancia().getComplejos();
        for (ComplejoDeportivoDTO c : complejos) cmbComplejo.addItem(c);
        cargarEspacios();
    }

    private void cargarEspacios() {
        cmbEspacio.removeAllItems();
        ComplejoDeportivoDTO seleccionado = (ComplejoDeportivoDTO) cmbComplejo.getSelectedItem();
        if (seleccionado == null) return;
        List<EspacioDeportivoDTO> espacios = ComplejoController.getInstancia()
                .getEspaciosDeComplejo(seleccionado.codigo);
        for (EspacioDeportivoDTO e : espacios) cmbEspacio.addItem(e);
    }

    private void solicitarReserva() {
        ComplejoDeportivoDTO complejo = (ComplejoDeportivoDTO) cmbComplejo.getSelectedItem();
        EspacioDeportivoDTO espacio   = (EspacioDeportivoDTO) cmbEspacio.getSelectedItem();

        if (txtDni.getText().isBlank() || complejo == null || espacio == null) {
            JOptionPane.showMessageDialog(this, "DNI, Complejo y Espacio son obligatorios.",
                    "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDate fecha;
        LocalTime horaInicio, horaFin;
        try {
            fecha      = LocalDate.parse(txtFecha.getText().trim());
            horaInicio = LocalTime.parse(txtHoraInicio.getText().trim());
            horaFin    = LocalTime.parse(txtHoraFin.getText().trim());
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Formato de fecha u hora inválido (yyyy-MM-dd / HH:mm).",
                    "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!horaFin.isAfter(horaInicio)) {
            JOptionPane.showMessageDialog(this, "La hora de fin debe ser posterior a la hora de inicio.",
                    "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            ReservaDTO dto = ReservaController.getInstancia().solicitarReserva(
                    txtDni.getText().trim(),
                    complejo.codigo,
                    espacio.codigo,
                    fecha, horaInicio, horaFin,
                    (String) cmbTipo.getSelectedItem(),
                    txtUsuario.getText().trim()
            );
            txtResultado.setText("Reserva registrada exitosamente:\n" + dto.toString());
        } catch (Exception ex) {
            txtResultado.setText("Error: " + ex.getMessage());
        }
    }
}
