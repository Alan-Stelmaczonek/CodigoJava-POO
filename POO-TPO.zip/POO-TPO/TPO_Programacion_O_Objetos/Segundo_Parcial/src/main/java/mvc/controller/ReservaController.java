package mvc.controller;

import mvc.dto.ReservaDTO;
import mvc.model.clases.*;
import mvc.model.enums.EstadoReserva;
import mvc.model.enums.MedioPago;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class ReservaController {

    private static ReservaController instancia;
    private List<Reserva> reservas;
    private List<HistorialCambioEstado> historiales;

    private ReservaController() {
        reservas = new ArrayList<>();
        historiales = new ArrayList<>();
    }

    public static ReservaController getInstancia() {
        if (instancia == null) {
            instancia = new ReservaController();
        }
        return instancia;
    }

    // DS1 — Solicitar reserva
    public ReservaDTO solicitarReserva(String dni, String codigoComplejo, String codigoEspacio,
            LocalDate fecha, LocalTime horaInicio, LocalTime horaFin,
            String tipoReserva, String usuario) {

        Cliente cliente = ClienteController.getInstancia().buscarClientePorDni(dni);
        if (cliente == null || !cliente.estaActivo())
            throw new IllegalArgumentException("Cliente no encontrado o inactivo: " + dni);

        ComplejoDeportivo complejo = ComplejoController.getInstancia().buscarComplejo(codigoComplejo);
        if (complejo == null)
            throw new IllegalArgumentException("Complejo no encontrado: " + codigoComplejo);

        EspacioDeportivo espacio = complejo.buscarEspacio(codigoEspacio);
        if (espacio == null)
            throw new IllegalArgumentException("Espacio no encontrado: " + codigoEspacio);

        if (!espacio.estaDisponible(fecha, horaInicio, horaFin))
            throw new IllegalStateException("El espacio no está disponible para la fecha y horario solicitado.");

        Reserva reserva = crearReserva(tipoReserva);
        reserva.inicializar(cliente, complejo, espacio, fecha, horaInicio, horaFin, tipoReserva);
        reserva.cambiarEstado(EstadoReserva.INGRESADA, usuario);
        espacio.registrarOcupacion(fecha, horaInicio, horaFin);
        reservas.add(reserva);

        HistorialCambioEstado historial = new HistorialCambioEstado();
        historial.registrarCambio(null, "INGRESADA", "Reserva", reserva.getCodigo(), usuario);
        historiales.add(historial);

        return mapToDTO(reserva);
    }

    // DS2 — Confirmar reserva con seña
    public void confirmarReservaConSena(String codigoReserva, double importeSena,
                                         MedioPago medioPago, String usuario) {
        Reserva reserva = buscarReserva(codigoReserva);
        if (reserva == null)
            throw new IllegalArgumentException("Reserva no encontrada: " + codigoReserva);

        Pago pago = PagoController.getInstancia().registrarPago(codigoReserva, importeSena, medioPago, usuario);
        reserva.agregarPago(pago);
        reserva.registrarImporteSena(importeSena);
        reserva.cambiarEstado(EstadoReserva.CONFIRMADA, usuario);

        HistorialCambioEstado historial = new HistorialCambioEstado();
        historial.registrarCambio("INGRESADA", "CONFIRMADA", "Reserva", codigoReserva, usuario);
        historiales.add(historial);
    }

    // DS3 — Cancelar reserva
    public void cancelarReserva(String codigoReserva, LocalDate fechaCancelacion, String usuario) {
        Reserva reserva = buscarReserva(codigoReserva);
        if (reserva == null)
            throw new IllegalArgumentException("Reserva no encontrada: " + codigoReserva);

        EstadoReserva estadoActual = reserva.getEstado();
        if (estadoActual == EstadoReserva.CANCELADA || estadoActual == EstadoReserva.FINALIZADA)
            throw new IllegalStateException("La reserva ya está " + estadoActual.name().toLowerCase() + " y no puede cancelarse.");

        Cliente cliente = reserva.obtenerCliente();
        double horasAnticipacion = reserva.calcularHorasAnticipacion(fechaCancelacion);

        if (horasAnticipacion > 24) {
            cliente.agregarCredito(reserva.obtenerImporteSena());
        }

        reserva.getEspacio().liberarOcupacion(reserva.getFecha(), reserva.getHoraInicio(), reserva.getHoraFin());
        String estadoAnterior = estadoActual.name();
        reserva.cambiarEstado(EstadoReserva.CANCELADA, usuario);

        HistorialCambioEstado historial = new HistorialCambioEstado();
        historial.registrarCambio(estadoAnterior, "CANCELADA", "Reserva", codigoReserva, usuario);
        historiales.add(historial);
    }

    // DS4 — Finalizar reserva y calcular saldo
    public double finalizarReserva(String codigoReserva, String usuario) {
        Reserva reserva = buscarReserva(codigoReserva);
        if (reserva == null)
            throw new IllegalArgumentException("Reserva no encontrada: " + codigoReserva);

        String estadoAnterior = reserva.getEstado().name();
        reserva.cambiarEstado(EstadoReserva.FINALIZADA, usuario);

        Cliente cliente = reserva.obtenerCliente();
        Descuento descuento = cliente.obtenerDescuentoVigente(reserva.getFecha());

        if (descuento != null) {
            reserva.aplicarDescuento(descuento.obtenerPorcentaje());
        }

        double saldo = reserva.calcularSaldoPendiente();

        HistorialCambioEstado historial = new HistorialCambioEstado();
        historial.registrarCambio(estadoAnterior, "FINALIZADA", "Reserva", codigoReserva, usuario);
        historiales.add(historial);

        return saldo;
    }

    // Query 2 — Reservas confirmadas de un cliente
    public List<ReservaDTO> getReservasConfirmadasCliente(String dni) {
        List<ReservaDTO> resultado = new ArrayList<>();
        for (Reserva r : reservas) {
            if (r.obtenerCliente().coincideDni(dni) && r.estaConfirmada()) {
                resultado.add(mapToDTO(r));
            }
        }
        return resultado;
    }

    // Query 1 — Total recaudado por complejo en un período
    public double totalRecaudadoPorPeriodo(String codigoComplejo, LocalDate desde, LocalDate hasta) {
        double total = 0;
        for (Reserva r : reservas) {
            if (r.getEstado() == EstadoReserva.FINALIZADA
                    && r.getComplejo().coincideCodigo(codigoComplejo)
                    && !r.getFecha().isBefore(desde)
                    && !r.getFecha().isAfter(hasta)) {
                total += r.calcularTotal();
            }
        }
        return total;
    }

    private Reserva buscarReserva(String codigoReserva) {
        for (Reserva r : reservas) {
            if (r.coincideCodigo(codigoReserva)) return r;
        }
        return null;
    }

    private Reserva crearReserva(String tipoReserva) {
        return switch (tipoReserva.toUpperCase()) {
            case "TORNEO"       -> new ReservaTorneo();
            case "CLASE_GRUPAL" -> new ReservaClaseGrupal();
            default             -> new ReservaComun();
        };
    }

    private ReservaDTO mapToDTO(Reserva r) {
        ReservaDTO dto = new ReservaDTO();
        dto.codigo         = r.getCodigo();
        dto.fecha          = r.getFecha();
        dto.horaInicio     = r.getHoraInicio();
        dto.horaFin        = r.getHoraFin();
        dto.estado         = r.getEstado().name();
        dto.tipoReserva    = r.getTipoReserva();
        dto.importeSena    = r.getImporteSena();
        dto.saldoPendiente = r.calcularSaldoPendiente();
        dto.nombreCliente  = r.obtenerCliente().getNombre() + " " + r.obtenerCliente().getApellido();
        dto.nombreEspacio  = r.getEspacio().getNombre();
        return dto;
    }

    public void limpiar() {
        reservas.clear();
        historiales.clear();
    }

    public List<Reserva> getReservas() {
        return new ArrayList<>(reservas);
    }
}
