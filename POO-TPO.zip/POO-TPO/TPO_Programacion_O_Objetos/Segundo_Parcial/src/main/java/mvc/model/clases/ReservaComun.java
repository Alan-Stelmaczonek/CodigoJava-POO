package mvc.model.clases;

public class ReservaComun extends Reserva {

    public ReservaComun() {
        super();
    }

    @Override
    public double calcularRecargo() {
        return 0.0;
    }

    @Override
    public String getTipoReserva() {
        return "COMUN";
    }
}
