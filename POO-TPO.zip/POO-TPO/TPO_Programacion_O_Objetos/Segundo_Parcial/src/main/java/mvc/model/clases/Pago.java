package mvc.model.clases;

import mvc.model.enums.EstadoPago;
import mvc.model.enums.MedioPago;
import java.time.LocalDate;

public class Pago {
    private LocalDate fecha;
    private double importe;
    private MedioPago medioPago;
    private EstadoPago estado;
    private String usuarioRegistro;

    public Pago() {}

    public void inicializar(LocalDate fecha, double importe, MedioPago medioPago,
                             EstadoPago estado, String usuario) {
        this.fecha = fecha;
        this.importe = importe;
        this.medioPago = medioPago;
        this.estado = estado;
        this.usuarioRegistro = usuario;
    }

    public void confirmar() {
        this.estado = EstadoPago.CONFIRMADO;
    }

    public void anular() {
        this.estado = EstadoPago.ANULADO;
    }

    public LocalDate getFecha() { return fecha; }
    public double getImporte() { return importe; }
    public MedioPago getMedioPago() { return medioPago; }
    public EstadoPago getEstado() { return estado; }
    public String getUsuarioRegistro() { return usuarioRegistro; }
}
