package mvc.model.clases;

import java.time.LocalDate;

public class Descuento {
    private double porcentaje;
    private LocalDate fechaDesde;
    private LocalDate fechaHasta;

    public Descuento(double porcentaje, LocalDate fechaDesde, LocalDate fechaHasta) {
        this.porcentaje = porcentaje;
        this.fechaDesde = fechaDesde;
        this.fechaHasta = fechaHasta;
    }

    public boolean estaVigente(LocalDate fecha) {
        return !fecha.isBefore(fechaDesde) && !fecha.isAfter(fechaHasta);
    }

    public double obtenerPorcentaje() {
        return porcentaje;
    }

    public LocalDate getFechaDesde() { return fechaDesde; }
    public LocalDate getFechaHasta() { return fechaHasta; }
}
