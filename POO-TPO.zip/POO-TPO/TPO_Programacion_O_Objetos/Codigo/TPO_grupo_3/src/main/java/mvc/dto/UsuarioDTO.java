package mvc.dto;

public class UsuarioDTO {
    private String nombreUsuario;
    private String nombreRol;
    private String permisos;

    public UsuarioDTO(String nombreUsuario, String nombreRol, String permisos) {
        this.nombreUsuario = nombreUsuario;
        this.nombreRol = nombreRol;
        this.permisos = permisos;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }
    public String getNombreRol() {
        return nombreRol;
    }
    public String getPermisos() {
        return permisos;
    }
}
