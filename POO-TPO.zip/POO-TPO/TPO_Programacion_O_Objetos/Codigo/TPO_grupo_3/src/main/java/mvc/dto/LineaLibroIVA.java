package mvc.dto;

import java.util.Date;

public class LineaLibroIVA {
    private String cuitProveedor;
    private String razonSocial;
    private Date fechaDocumento;
    private String tipoDocumento;
    private float montoIVA2_5;
    private float montoIVA5;
    private float montoIVA10_5;
    private float montoIVA21;
    private float montoIVA27;
    private float totalDocumento;

    public LineaLibroIVA(String cuitProveedor, String razonSocial, Date fechaDocumento, String tipoDocumento, float montoIVA2_5, float montoIVA5, float montoIVA10_5, float montoIVA21, float montoIVA27, float totalDocumento) {
        this.cuitProveedor = cuitProveedor;
        this.razonSocial = razonSocial;
        this.fechaDocumento = fechaDocumento;
        this.tipoDocumento = tipoDocumento;
        this.montoIVA2_5 = montoIVA2_5;
        this.montoIVA5 = montoIVA5;
        this.montoIVA10_5 = montoIVA10_5;
        this.montoIVA21 = montoIVA21;
        this.montoIVA27 = montoIVA27;
        this.totalDocumento = totalDocumento;
    }

    public String getCuitProveedor() { return cuitProveedor; }
    public String getRazonSocial() { return razonSocial; }
    public Date getFechaDocumento() { return fechaDocumento; }
    public String getTipoDocumento() { return tipoDocumento; }
    public float getMontoIVA2_5() { return montoIVA2_5; }
    public float getMontoIVA5() { return montoIVA5; }
    public float getMontoIVA10_5() { return montoIVA10_5; }
    public float getMontoIVA21() { return montoIVA21; }
    public float getMontoIVA27() { return montoIVA27; }
    public float getTotalDocumento() { return totalDocumento; }
}