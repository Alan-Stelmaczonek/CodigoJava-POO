package mvc.view;

import mvc.controller.UsuarioController;
import mvc.model.clases.Usuario;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private Usuario usuarioLogueado;
    private JTabbedPane pestanias;

    public MainFrame() {
        mostrarLogin();
    }

    private void mostrarLogin() {
        setTitle("Login - Sistema de Gestión");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(350, 200);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtUsuario = new JTextField(15);
        JPasswordField txtContrasenia = new JPasswordField(15);
        JButton btnLogin = new JButton("Ingresar");
        JLabel lblError = new JLabel(" ");
        lblError.setForeground(Color.RED);

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1;
        panel.add(txtUsuario, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Contraseña:"), gbc);
        gbc.gridx = 1;
        panel.add(txtContrasenia, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        panel.add(btnLogin, gbc);

        gbc.gridy = 3;
        panel.add(lblError, gbc);

        btnLogin.addActionListener(e -> {
            String nombre = txtUsuario.getText();
            String contrasenia = new String(txtContrasenia.getPassword());
            Usuario usuario = UsuarioController.getInstance().login(nombre, contrasenia);

            if (usuario != null) {
                usuarioLogueado = usuario;
                cargarMenuPrincipal();
            } else {
                lblError.setText("Credenciales incorrectas.");
            }
        });

        getRootPane().setDefaultButton(btnLogin);

        add(panel);
        setVisible(true);
    }

    private void cargarMenuPrincipal() {
        getContentPane().removeAll();

        setTitle("Sistema de Gestión - " + usuarioLogueado.getNombreusuario());
        setSize(950, 550);
        setLocationRelativeTo(null);
        setResizable(true);

        pestanias = new JTabbedPane();

        if (usuarioLogueado.tienePermiso("proveedores")) {
            pestanias.addTab("Proveedores", new ProveedorView());
        }

        if (usuarioLogueado.tienePermiso("productos")) {
            pestanias.addTab("Productos", new ProductoView());
        }

        if (usuarioLogueado.tienePermiso("ordenesCompra")) {
            pestanias.addTab("Órdenes de Compra", new OrdenCompraView());
        }

        if (usuarioLogueado.tienePermiso("comprobantes")) {
            pestanias.addTab("Comprobantes", new ComprobanteView());
        }

        if (usuarioLogueado.tienePermiso("ordenesPago")) {
            pestanias.addTab("Órdenes de Pago", new OrdenPagoView());
        }

        if (usuarioLogueado.tienePermiso("usuarios")) {
            pestanias.addTab("Usuarios", new UsuarioView());
        }

        if (usuarioLogueado.tienePermiso("parametros")) {
            pestanias.addTab("Parámetros de Retención", new ParametroRetencionView());
        }

        if (usuarioLogueado.tienePermiso("consultas")) {
            pestanias.addTab("Consultas y Reportes", new ConsultaView());
        }

        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.addActionListener(e -> cerrarSesion());
        panelInferior.add(btnCerrarSesion);

        add(pestanias, BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);

        revalidate();
        repaint();
    }

    private void cerrarSesion() {
        usuarioLogueado = null;
        getContentPane().removeAll();
        setResizable(false);
        mostrarLogin();
        revalidate();
        repaint();
    }
}
