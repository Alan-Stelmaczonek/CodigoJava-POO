package mvc.view;

import mvc.controller.ProductoController;
import mvc.controller.ProveedorController;
import mvc.dto.ProveedorDTO;
import mvc.model.clases.Rubro;
import mvc.model.enums.ResponsabilidadIVA;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProveedorView extends JPanel {

    private ProveedorController controller;
    private JTable tablaProveedores;
    private DefaultTableModel modeloTabla;

    public ProveedorView() {
        this.controller = ProveedorController.getInstance();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(crearPanelBotones(), BorderLayout.NORTH);
        add(crearPanelTabla(), BorderLayout.CENTER);

        actualizarTabla();
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        JButton btnAlta = new JButton("Alta Proveedor");
        JButton btnModificar = new JButton("Modificar Proveedor");
        JButton btnBuscar = new JButton("Buscar Proveedor");
        JButton btnActualizar = new JButton("Actualizar Listado");

        btnAlta.addActionListener(e -> mostrarDialogoAlta());
        btnModificar.addActionListener(e -> mostrarDialogoModificar());
        btnBuscar.addActionListener(e -> mostrarDialogoBuscar());
        btnActualizar.addActionListener(e -> actualizarTabla());

        panel.add(btnAlta);
        panel.add(btnModificar);
        panel.add(btnBuscar);
        panel.add(btnActualizar);

        return panel;
    }

    private JScrollPane crearPanelTabla() {
        String[] columnas = {"CUIT", "Razón Social", "Nombre Fantasía", "Resp. IVA", "Teléfono", "Email", "Deuda Total", "Rubros"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaProveedores = new JTable(modeloTabla);
        return new JScrollPane(tablaProveedores);
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);
        List<ProveedorDTO> proveedores = controller.listarProveedores();
        for (ProveedorDTO p : proveedores) {
            modeloTabla.addRow(new Object[]{
                    p.getCuit(),
                    p.getRazonSocial(),
                    p.getNombreFantasia(),
                    p.getResponsabilidadIVA(),
                    p.getTelefono(),
                    p.getEmail(),
                    p.getDeudaTotal(),
                    p.getCantidadRubros()
            });
        }
    }

    private JFrame getVentanaPadre() {
        return (JFrame) SwingUtilities.getWindowAncestor(this);
    }

    private void mostrarDialogoAlta() {
        JDialog dialogo = new JDialog(getVentanaPadre(), "Alta de Proveedor", true);
        dialogo.setSize(480, 600);
        dialogo.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtCuit = new JTextField(20);
        JTextField txtRazonSocial = new JTextField(20);
        JTextField txtNombreFantasia = new JTextField(20);
        JComboBox<ResponsabilidadIVA> cmbResponsabilidad = new JComboBox<>(ResponsabilidadIVA.values());
        JTextField txtDireccion = new JTextField(20);
        JTextField txtTelefono = new JTextField(20);
        JTextField txtEmail = new JTextField(20);
        JTextField txtNroIIBB = new JTextField(20);
        JTextField txtFechaInicio = new JTextField(20);
        txtFechaInicio.setToolTipText("dd/MM/yyyy");
        JTextField txtLimiteDeuda = new JTextField(20);

        List<Rubro> rubrosDisponibles = ProductoController.getInstance().getRubros();
        JList<Rubro> lstRubros = new JList<>(rubrosDisponibles.toArray(new Rubro[0]));
        lstRubros.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollRubros = new JScrollPane(lstRubros);
        scrollRubros.setPreferredSize(new Dimension(200, 80));

        JLabel[] labels = {
                UIHelper.crearLabelObligatorio("CUIT:"),
                UIHelper.crearLabelObligatorio("Razón Social:"),
                new JLabel("Nombre Fantasía:"),
                UIHelper.crearLabelObligatorio("Resp. IVA:"),
                UIHelper.crearLabelObligatorio("Dirección:"),
                UIHelper.crearLabelObligatorio("Teléfono:"),
                UIHelper.crearLabelObligatorio("Email:"),
                UIHelper.crearLabelObligatorio("Nro. IIBB:"),
                UIHelper.crearLabelObligatorio("Fecha Inicio (dd/MM/yyyy):"),
                UIHelper.crearLabelObligatorio("Límite Deuda:"),
                new JLabel("Rubros (Ctrl+click para varios):")
        };
        JComponent[] campos = {txtCuit, txtRazonSocial, txtNombreFantasia, cmbResponsabilidad,
                txtDireccion, txtTelefono, txtEmail, txtNroIIBB,
                txtFechaInicio, txtLimiteDeuda, scrollRubros};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i;
            panel.add(labels[i], gbc);
            gbc.gridx = 1;
            panel.add(campos[i], gbc);
        }

        gbc.gridx = 0; gbc.gridy = labels.length; gbc.gridwidth = 2;
        panel.add(UIHelper.crearLabelCamposObligatorios(), gbc);

        JButton btnGuardar = new JButton("Guardar");
        gbc.gridy = labels.length + 1;
        panel.add(btnGuardar, gbc);

        UIHelper.configurarEnterEscape(dialogo, btnGuardar);

        btnGuardar.addActionListener(e -> {
            String error;

            error = UIHelper.validarCuit(txtCuit.getText());
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarNoVacio(txtRazonSocial.getText(), "Razón Social");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarNoVacio(txtDireccion.getText(), "Dirección");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarTelefono(txtTelefono.getText());
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarEmail(txtEmail.getText());
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarNroIIBB(txtNroIIBB.getText());
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarFecha(txtFechaInicio.getText());
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarFloatPositivo(txtLimiteDeuda.getText(), "Límite de deuda");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            try {
                Date fecha = UIHelper.parsearFecha(txtFechaInicio.getText());
                float limiteDeuda = Float.parseFloat(txtLimiteDeuda.getText());

                controller.altaProveedor(
                        txtCuit.getText(),
                        txtRazonSocial.getText(),
                        (ResponsabilidadIVA) cmbResponsabilidad.getSelectedItem(),
                        txtNombreFantasia.getText(),
                        txtDireccion.getText(),
                        txtTelefono.getText(),
                        txtEmail.getText(),
                        txtNroIIBB.getText(),
                        fecha,
                        lstRubros.getSelectedValuesList(),
                        limiteDeuda
                );

                JOptionPane.showMessageDialog(dialogo, "Proveedor dado de alta correctamente.");
                dialogo.dispose();
                actualizarTabla();
            } catch (Exception ex) {
                UIHelper.mostrarError(dialogo, "Error inesperado: " + ex.getMessage());
            }
        });

        dialogo.add(panel);
        dialogo.setVisible(true);
    }

    private void mostrarDialogoModificar() {
        String cuit = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el CUIT del proveedor a modificar:");
        if (cuit == null || cuit.trim().isEmpty()) return;

        if (controller.buscarProveedor(cuit) == null) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No se encontró un proveedor con CUIT: " + cuit,
                    "No encontrado", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JDialog dialogo = new JDialog(getVentanaPadre(), "Modificar Proveedor - " + cuit, true);
        dialogo.setSize(400, 350);
        dialogo.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtRazonSocial = new JTextField(20);
        JTextField txtNombreFantasia = new JTextField(20);
        JTextField txtTelefono = new JTextField(20);
        JTextField txtEmail = new JTextField(20);
        JTextField txtDireccion = new JTextField(20);
        JTextField txtLimiteDeuda = new JTextField(20);

        String[] labels = {"Razón Social:", "Nombre Fantasía:", "Teléfono:", "Email:", "Dirección:", "Límite Deuda:"};
        JTextField[] campos = {txtRazonSocial, txtNombreFantasia, txtTelefono, txtEmail, txtDireccion, txtLimiteDeuda};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i;
            panel.add(new JLabel(labels[i]), gbc);
            gbc.gridx = 1;
            panel.add(campos[i], gbc);
        }

        JLabel lblInfo = new JLabel("Deje vacío lo que no desee modificar.");
        lblInfo.setFont(lblInfo.getFont().deriveFont(Font.ITALIC, 11f));
        gbc.gridx = 0; gbc.gridy = labels.length; gbc.gridwidth = 2;
        panel.add(lblInfo, gbc);

        JButton btnGuardar = new JButton("Guardar Cambios");
        gbc.gridy = labels.length + 1;
        panel.add(btnGuardar, gbc);

        UIHelper.configurarEnterEscape(dialogo, btnGuardar);

        btnGuardar.addActionListener(e -> {
            String error;
            Map<String, Object> datos = new HashMap<>();

            if (!txtRazonSocial.getText().isEmpty()) datos.put("razonSocial", txtRazonSocial.getText());
            if (!txtNombreFantasia.getText().isEmpty()) datos.put("nombreFantasia", txtNombreFantasia.getText());

            if (!txtTelefono.getText().isEmpty()) {
                error = UIHelper.validarTelefono(txtTelefono.getText());
                if (error != null) { UIHelper.mostrarError(dialogo, error); return; }
                datos.put("telefono", txtTelefono.getText());
            }
            if (!txtEmail.getText().isEmpty()) {
                error = UIHelper.validarEmail(txtEmail.getText());
                if (error != null) { UIHelper.mostrarError(dialogo, error); return; }
                datos.put("email", txtEmail.getText());
            }
            if (!txtDireccion.getText().isEmpty()) datos.put("direccion", txtDireccion.getText());
            if (!txtLimiteDeuda.getText().isEmpty()) {
                error = UIHelper.validarFloatPositivo(txtLimiteDeuda.getText(), "Límite de deuda");
                if (error != null) { UIHelper.mostrarError(dialogo, error); return; }
                datos.put("limiteDeuda", Float.parseFloat(txtLimiteDeuda.getText()));
            }

            if (datos.isEmpty()) {
                JOptionPane.showMessageDialog(dialogo, "No se ingresaron cambios.");
                return;
            }

            controller.modificarProveedor(cuit, datos);
            JOptionPane.showMessageDialog(dialogo, "Proveedor modificado correctamente.");
            dialogo.dispose();
            actualizarTabla();
        });

        dialogo.add(panel);
        dialogo.setVisible(true);
    }

    private void mostrarDialogoBuscar() {
        String cuit = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el CUIT del proveedor:");
        if (cuit == null || cuit.trim().isEmpty()) return;

        var proveedor = controller.buscarProveedor(cuit);
        if (proveedor == null) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No se encontró un proveedor con CUIT: " + cuit,
                    "No encontrado", JOptionPane.WARNING_MESSAGE);
        } else {
            String info = "CUIT: " + proveedor.getCuit()
                    + "\nRazón Social: " + proveedor.getRazonSocial()
                    + "\nNombre Fantasía: " + proveedor.getNombreFantasia()
                    + "\nResp. IVA: " + proveedor.getResponsabilidadIVA()
                    + "\nDirección: " + proveedor.getDireccion()
                    + "\nTeléfono: " + proveedor.getTelefono()
                    + "\nEmail: " + proveedor.getEmail()
                    + "\nDeuda Total: " + proveedor.getDeudaTotal();
            JOptionPane.showMessageDialog(getVentanaPadre(), info, "Proveedor encontrado", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
