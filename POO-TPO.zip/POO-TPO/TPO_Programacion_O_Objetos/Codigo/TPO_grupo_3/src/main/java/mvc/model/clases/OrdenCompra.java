package mvc.model.clases;

import mvc.model.enums.EstadoOrdenCompra;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;


public class OrdenCompra {
    private int numero;
    private Date fecha;
    private EstadoOrdenCompra estado;
    private List<LineaOrdenCompra> lineas = new ArrayList<>();
    private Proveedor proveedor;

    public OrdenCompra(int numero, Date fecha,  Proveedor proveedor, EstadoOrdenCompra estado) {
        this.numero = numero;
        this.fecha = fecha;
        this.proveedor = proveedor;
        this.estado = estado;

    }

    public int getNumero() {
        return numero;
    }

    public void agregarLinea(LineaOrdenCompra linea) {
        lineas.add(linea);
    }

    public void aprobar() {
        this.estado = EstadoOrdenCompra.APROBADA;
    }

    public void marcarPendienteAprobacion()  {
        this.estado = EstadoOrdenCompra.PENDIENTE_APROBACION;
    }

    public boolean requiereAprobacion() {
        if (estado != EstadoOrdenCompra.PENDIENTE_APROBACION) {
            return false;
        } else {
            return true;
        }
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public float calcularTotal() {
        float total = 0;
        for (int i = 0; lineas.size() > i; i++) {
            total = total + lineas.get(i).getSubtotal() ;
        }
        return total;
    }
    public List<LineaOrdenCompra> getLineas() {
        return lineas;
    }
    public EstadoOrdenCompra getEstado() {
        return estado;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    public Date getFecha() {
        return fecha;
    }
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    public void setEstado(EstadoOrdenCompra estado) {
        this.estado = estado;
    }
    public void setLineas(List<LineaOrdenCompra> lineas) {
        this.lineas = lineas;
    }
    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }
    public String getRazonSocialProveedor() {
        return proveedor.getRazonSocial();
    }
    public float getTotal() {
        return calcularTotal();
    }
}
