package mvc.model.clases;

public class Efectivo extends MedioPago{

    public Efectivo(float monto){
        super(monto);
    }

    @Override
    public String getDescripcion() {
        return "Efectivo";
    }
    @Override
    public String getDetalle() {
        return  "Monto: " + monto;
    }

}
