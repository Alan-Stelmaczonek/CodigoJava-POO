package mvc.model.clases;

import mvc.model.enums.TipoRetencion;

public class ParametroRetencion {
    private TipoRetencion tipoImpuesto;
    private float porcentaje;
    private float minimoNoImponible;

    public ParametroRetencion(TipoRetencion tipoImpuesto, float porcentaje, float minimoNoImponible) {
        this.tipoImpuesto = tipoImpuesto;
        this.porcentaje = porcentaje;
        this.minimoNoImponible = minimoNoImponible;
    }

    public TipoRetencion getTipoImpuesto() {
        return tipoImpuesto;
    }
    public float getPorcentaje() {
        return porcentaje;
    }
    public float getMinimoNoImponible() {
        return minimoNoImponible;
    }

    public void setPorcentaje(float porcentaje) {
        this.porcentaje = porcentaje;
    }

    public void setMinimoNoImponible(float minimoNoImponible) {
        this.minimoNoImponible = minimoNoImponible;
    }
}
