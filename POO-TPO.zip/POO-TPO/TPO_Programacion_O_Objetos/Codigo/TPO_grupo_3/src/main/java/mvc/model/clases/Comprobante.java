package mvc.model.clases;

import mvc.model.enums.EstadoComprobante;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;


public abstract class Comprobante {
    protected int numero;
    protected Date fecha;
    protected EstadoComprobante estado;
    protected List<LineaComprobante> lineas = new ArrayList<>();
    private Proveedor proveedor;


    public Comprobante(int numero, Date fecha, EstadoComprobante estado, List<LineaComprobante> lineas,  Proveedor proveedor) {
        this.numero = numero;
        this.fecha = fecha;
        this.estado = estado;
        this.lineas = lineas;
        this.proveedor = proveedor;
    }

    public int getNumero() {
        return numero;
    }

    public Date getFecha() {
        return fecha;
    }

    public EstadoComprobante getEstado() {
        return estado;
    }

    public void marcarPendienteAprobacion() {
        this.estado = EstadoComprobante.PENDIENTE_APROBACION;
    }

    public void marcarPagado() {
        this.estado = EstadoComprobante.PAGADO;
    }

    public void aprobar() {
        this.estado = EstadoComprobante.IMPAGO;
    }

    public boolean estaPago() {
        if (estado != EstadoComprobante.PAGADO) {
            return false;
        } else {
            return true;
        }
    }

    public boolean requiereAprobacion() {
        if (estado != EstadoComprobante.PENDIENTE_APROBACION) {
            return false;
        } else {
            return true;
        }
    }

    public void agregarLinea(LineaComprobante linea) {
        lineas.add(linea);
    }

    public List<LineaComprobante> getLineas() {
        return new ArrayList<>(lineas);
    }

    public float calcularTotalIVA() {
        float total = 0;
        for (int i = 0; i < lineas.size(); i++) {
            total = total + lineas.get(i).getMontoIVA();
        }
        return total;
    }
    public abstract float calcularTotal();

    public abstract float getMontoParaCuentaCorriente();

    public abstract String getTipo();

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setEstado(EstadoComprobante estado) {
        this.estado = estado;
    }

    public void setLineas(List<LineaComprobante> lineas) {
        this.lineas = lineas;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }
}

