package mvc.model.clases;

import java.util.Date;

public class Transferencia extends MedioPago{
    private String cbuDestino;
    private Date fechaTransferencia;

    public Transferencia(String cbuDestino, Date fechaTransferencia, float monto) {
        super (monto);
        this.cbuDestino = cbuDestino;
        this.fechaTransferencia = fechaTransferencia;
    }
    @Override
    public String getDescripcion() {
        return "Transferencia";
    }
    @Override
    public String getDetalle() {
        return "CBU Destino: " + cbuDestino +
                "Fecha de Transferencia: " + fechaTransferencia +
                "Monto: " + monto ;
    }


}
