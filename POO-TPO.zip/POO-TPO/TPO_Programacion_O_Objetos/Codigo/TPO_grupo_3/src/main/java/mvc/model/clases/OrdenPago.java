package mvc.model.clases;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrdenPago {
    private int numero;
    private Date fecha;
    private float totalACancelar;
    private float totalRetenciones;
    private List <Retencion> retenciones = new ArrayList<>();
    private List <MedioPago>  medioPagos = new ArrayList<>();
    private List <Comprobante> comprobantes = new ArrayList<>();

    public OrdenPago(int numero, Date fecha, float totalACancelar, float totalRetenciones) {
        this.numero = numero;
        this.fecha = fecha;
        this.totalACancelar = totalACancelar;
        this.totalRetenciones = totalRetenciones;
    }
    public void agregarComprobante (Comprobante comprobante){
        comprobantes.add(comprobante);
    }
    public void agregarMedioPago (MedioPago medioPago){
        medioPagos.add(medioPago);
    }
    public void agregarRetencion (Retencion retencion){
        retenciones.add(retencion);
    }
    public int getNumero() {
        return numero;
    }
    public float getTotalACancelar() {
        return totalACancelar;
    }
    public float calcularTotalRetenciones (){
        float total = 0;
        for (Retencion r : retenciones){
            total += r.getMonto();
        }
        return total;
    }
    public float calcularMontoAPagar(){
        return totalACancelar - totalRetenciones;
    }
    public List <Retencion> getRetenciones() {
        return new ArrayList<>(retenciones);
    }
    public List <MedioPago> getMediosPago (){
        return new ArrayList<>(medioPagos);
    }
    public Date getFecha() {
        return fecha;
    }
}