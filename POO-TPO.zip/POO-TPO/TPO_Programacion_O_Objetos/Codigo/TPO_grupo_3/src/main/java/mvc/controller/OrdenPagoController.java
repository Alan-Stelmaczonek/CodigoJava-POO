package mvc.controller;

import mvc.model.clases.Comprobante;
import mvc.model.clases.MedioPago;
import mvc.model.clases.OrdenPago;
import mvc.model.clases.Proveedor;
import mvc.model.clases.Retencion;
import mvc.model.clases.ParametroRetencion;
import mvc.model.enums.TipoRetencion;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrdenPagoController {

    private static OrdenPagoController INSTANCE = null;

    private List<OrdenPago> ordenesPago;
    private int contadorOP;

    private OrdenPagoController() {
        this.ordenesPago = new ArrayList<>();
        this.contadorOP = 0;
    }

    public static synchronized OrdenPagoController getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new OrdenPagoController();
        }
        return INSTANCE;
    }

    public OrdenPago emitirOrdenPago(Proveedor proveedor, List<Comprobante> comprobantes, List<MedioPago> mediosPago) {
        float totalACancelar = 0;
        for (Comprobante comprobante : comprobantes) {
            totalACancelar += comprobante.getMontoParaCuentaCorriente();
        }

        List<Retencion> retenciones = calcularRetenciones(proveedor, totalACancelar);
        float totalRetenciones = 0;
        for (Retencion retencion : retenciones) {
            totalRetenciones += retencion.getMonto();
        }

        contadorOP++;
        OrdenPago ordenPago = new OrdenPago(contadorOP, new Date(), totalACancelar, totalRetenciones);

        for (Comprobante comprobante : comprobantes) {
            ordenPago.agregarComprobante(comprobante);
            comprobante.marcarPagado();
        }
        for (MedioPago medioPago : mediosPago) {
            ordenPago.agregarMedioPago(medioPago);
        }
        for (Retencion retencion : retenciones) {
            ordenPago.agregarRetencion(retencion);
        }

        proveedor.agregarOrdenPago(ordenPago);
        ordenesPago.add(ordenPago);

        return ordenPago;
    }

    private List<Retencion> calcularRetenciones(Proveedor proveedor, float baseImponible) {
        List<Retencion> retenciones = new ArrayList<>();
        ParametroRetencionController parametroController = ParametroRetencionController.getInstance();

        for (TipoRetencion tipo : TipoRetencion.values()) {
            if (proveedor.tieneCertificadoVigente(tipo)) {
                continue;
            }
            ParametroRetencion parametro = parametroController.buscarParametro(tipo);
            if (parametro == null) {
                continue;
            }
            Retencion retencionTentativa = new Retencion(tipo, parametro.getPorcentaje(), 0, parametro.getMinimoNoImponible());
            if (retencionTentativa.correspondeRetener(baseImponible)) {
                float monto = retencionTentativa.calcularMonto(baseImponible);
                retenciones.add(new Retencion(tipo, parametro.getPorcentaje(), monto, parametro.getMinimoNoImponible()));
            }
        }
        return retenciones;
    }

    public List<OrdenPago> getOrdenesPago() {
        return ordenesPago;
    }

    public List<OrdenPago> obtenerOrdenesPagoEmitidas(Date desde, Date hasta) {
        List<OrdenPago> resultado = new ArrayList<>();
        for (OrdenPago ordenPago : ordenesPago) {
            Date fecha = ordenPago.getFecha();
            if (!fecha.before(desde) && !fecha.after(hasta)) {
                resultado.add(ordenPago);
            }
        }
        return resultado;
    }
}
