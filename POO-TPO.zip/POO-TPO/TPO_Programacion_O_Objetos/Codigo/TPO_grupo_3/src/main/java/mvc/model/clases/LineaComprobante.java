package mvc.model.clases;

import mvc.model.enums.TipoIVA;


public class LineaComprobante {
    private int cantidad;
    private float precioUnitario;
    private TipoIVA tipoIVA;

    public LineaComprobante(int cantidad, float precioUnitario, TipoIVA tipoIVA) {
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.tipoIVA = tipoIVA;
    }

    public int getCantidad() {
        return cantidad;
    }

    public float getPrecioUnitario() {
        return precioUnitario;
    }

    public TipoIVA getTipoIVA() {
        return tipoIVA;
    }

    public float getSubtotal() {
        return cantidad * precioUnitario;
    }

    public float getMontoIVA() {
        return getSubtotal() * tipoIVA.getPorcentaje() / 100;
    }
}
