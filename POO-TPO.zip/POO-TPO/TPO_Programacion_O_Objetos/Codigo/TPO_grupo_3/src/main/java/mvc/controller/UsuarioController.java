package mvc.controller;

import mvc.dto.UsuarioDTO;
    import mvc.model.clases.Rol;
import mvc.model.clases.Usuario;

import java.util.ArrayList;
import java.util.*;


public class UsuarioController {
    private static UsuarioController INSTANCE = null;
    private List<Usuario> usuarios = new ArrayList<>();

    private UsuarioController() {
        this.usuarios = new ArrayList<>();
    }

    public synchronized static UsuarioController getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new UsuarioController();
        }
        return INSTANCE;
    }

    public Usuario login(String nombreUsuario, String contrasenia) {
        Usuario usuario = buscarUsuario(nombreUsuario);
        if (usuario == null) {
            return null;
        }
        if (usuario.validarCredenciales(contrasenia)) {
            return usuario;
        }
        return null;
    }

    public Usuario altaUsuario(String nombreUsuario, String contrasenia, Rol rol) {
        if (buscarUsuario(nombreUsuario) != null) {
            System.out.println("El usuario " + nombreUsuario + " ya existe en el sistema");
            return null;
        } else {
            Usuario usuario = new Usuario(nombreUsuario, contrasenia, rol);
            usuarios.add(usuario);
            return usuario;
        }
    }

    public Usuario buscarUsuario(String nombreUsuario) {
        for (Usuario usuario : usuarios) {
            if (usuario.getNombreusuario().equals(nombreUsuario)) {
                return usuario;
            }
        }
        return null;
    }

    public boolean modificarUsuario(String nombreUsuario, Map<String, Object> datosActualizados) {
        Usuario usuario = buscarUsuario(nombreUsuario);
        if (usuario == null) {
            return false;
        } else {
            if (datosActualizados.containsKey("NombreUsuario")) {
                usuario.setNombreusuario((String) datosActualizados.get("NombreUsuario"));
            }
            if (datosActualizados.containsKey("contrasenia")) {
                usuario.setContrasenia((String) datosActualizados.get("contrasenia"));
            }
            if (datosActualizados.containsKey("rol")) {
                usuario.setRol((Rol) datosActualizados.get("rol"));
            }
        }
        return true;
    }

    public boolean eliminarUsuario(String nombreUsuario) {
        Usuario usuario = buscarUsuario(nombreUsuario);
        if (usuario == null) {
            return false;
        }
        usuarios.remove(usuario);
        return true;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public List<UsuarioDTO> listarUsuarios() {
        List<UsuarioDTO> lista = new ArrayList<>();
        for (Usuario usuario : usuarios) {
            lista.add(toDTO(usuario));
        }
        return lista;
    }

    private UsuarioDTO toDTO(Usuario usuario) {
        UsuarioDTO dto = new UsuarioDTO(usuario.getNombreusuario(),
                                        usuario.getRol().getNombre(),
                                        usuario.getRol().getPermisos().toString());
        return dto;

    }

}
