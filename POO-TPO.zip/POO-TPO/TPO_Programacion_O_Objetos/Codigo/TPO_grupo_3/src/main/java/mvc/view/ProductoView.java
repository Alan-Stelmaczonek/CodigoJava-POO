package mvc.view;

import mvc.controller.ProductoController;
import mvc.controller.ProveedorController;
import mvc.dto.ProductoDTO;
import mvc.model.clases.Producto;
import mvc.model.clases.ProductoProveedor;
import mvc.model.clases.Proveedor;
import mvc.model.clases.Rubro;
import mvc.model.enums.TipoIVA;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ProductoView extends JPanel {

    private ProductoController controller;
    private JTable tablaProductos;
    private DefaultTableModel modeloTabla;

    public ProductoView() {
        this.controller = ProductoController.getInstance();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(crearPanelBotones(), BorderLayout.NORTH);
        add(crearPanelTabla(), BorderLayout.CENTER);

        actualizarTabla();
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        JButton btnAltaProducto = new JButton("Alta Producto");
        JButton btnAltaRubro = new JButton("Alta Rubro");
        JButton btnModificarRubro = new JButton("Modificar Rubro");
        JButton btnAsociarProveedor = new JButton("Asociar Proveedor");
        JButton btnModificarPrecio = new JButton("Modificar Precio");
        JButton btnActualizar = new JButton("Actualizar Listado");

        btnAltaProducto.addActionListener(e -> mostrarDialogoAltaProducto());
        btnAltaRubro.addActionListener(e -> mostrarDialogoAltaRubro());
        btnModificarRubro.addActionListener(e -> mostrarDialogoModificarRubro());
        btnAsociarProveedor.addActionListener(e -> mostrarDialogoAsociarProveedor());
        btnModificarPrecio.addActionListener(e -> mostrarDialogoModificarPrecio());
        btnActualizar.addActionListener(e -> actualizarTabla());

        panel.add(btnAltaProducto);
        panel.add(btnAltaRubro);
        panel.add(btnModificarRubro);
        panel.add(btnAsociarProveedor);
        panel.add(btnModificarPrecio);
        panel.add(btnActualizar);

        return panel;
    }

    private JScrollPane crearPanelTabla() {
        String[] columnas = {"ID", "Descripción", "Rubro", "Cant. Proveedores"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaProductos = new JTable(modeloTabla);
        return new JScrollPane(tablaProductos);
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);
        List<ProductoDTO> productos = controller.listarProductos();
        for (ProductoDTO p : productos) {
            modeloTabla.addRow(new Object[]{
                    p.getId(),
                    p.getDescripcion(),
                    p.getRubroDescripcion(),
                    p.getCantidadProveedores()
            });
        }
    }

    private JFrame getVentanaPadre() {
        return (JFrame) SwingUtilities.getWindowAncestor(this);
    }

    private void mostrarDialogoAltaProducto() {
        List<Rubro> rubros = controller.getRubros();
        if (rubros.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "Debe crear al menos un rubro antes de dar de alta un producto.",
                    "Sin rubros", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JDialog dialogo = new JDialog(getVentanaPadre(), "Alta de Producto", true);
        dialogo.setSize(400, 320);
        dialogo.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtId = new JTextField(20);
        JTextField txtDescripcion = new JTextField(20);
        JComboBox<TipoIVA> cmbTipoIVA = new JComboBox<>(TipoIVA.values());
        JTextField txtUnidadMedida = new JTextField(20);
        JComboBox<String> cmbRubro = new JComboBox<>();
        for (Rubro r : rubros) {
            cmbRubro.addItem(r.getDescripcion());
        }

        JLabel[] labels = {
                UIHelper.crearLabelObligatorio("ID:"),
                UIHelper.crearLabelObligatorio("Descripción:"),
                UIHelper.crearLabelObligatorio("Tipo IVA:"),
                UIHelper.crearLabelObligatorio("Unidad de Medida:"),
                UIHelper.crearLabelObligatorio("Rubro:")
        };
        JComponent[] campos = {txtId, txtDescripcion, cmbTipoIVA, txtUnidadMedida, cmbRubro};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i;
            panel.add(labels[i], gbc);
            gbc.gridx = 1;
            panel.add(campos[i], gbc);
        }

        gbc.gridx = 0; gbc.gridy = labels.length; gbc.gridwidth = 2;
        panel.add(UIHelper.crearLabelCamposObligatorios(), gbc);

        JButton btnGuardar = new JButton("Guardar");
        gbc.gridy = labels.length + 1;
        panel.add(btnGuardar, gbc);

        UIHelper.configurarEnterEscape(dialogo, btnGuardar);

        btnGuardar.addActionListener(e -> {
            String error;

            error = UIHelper.validarEnteroPositivo(txtId.getText(), "ID");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarNoVacio(txtDescripcion.getText(), "Descripción");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarNoVacio(txtUnidadMedida.getText(), "Unidad de Medida");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            int id = Integer.parseInt(txtId.getText());
            String descripcion = txtDescripcion.getText();
            TipoIVA tipoIVA = (TipoIVA) cmbTipoIVA.getSelectedItem();
            String unidadMedida = txtUnidadMedida.getText();
            Rubro rubroSeleccionado = rubros.get(cmbRubro.getSelectedIndex());

            controller.altaProducto(id, descripcion, tipoIVA, unidadMedida, rubroSeleccionado);

            JOptionPane.showMessageDialog(dialogo, "Producto dado de alta correctamente.");
            dialogo.dispose();
            actualizarTabla();
        });

        dialogo.add(panel);
        dialogo.setVisible(true);
    }

    private void mostrarDialogoAltaRubro() {
        String descripcion = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese la descripción del rubro:");
        if (descripcion == null || descripcion.trim().isEmpty()) return;

        controller.altaRubro(descripcion);
        JOptionPane.showMessageDialog(getVentanaPadre(), "Rubro dado de alta correctamente.");
    }

    private void mostrarDialogoModificarRubro() {
        List<Rubro> rubros = controller.getRubros();
        if (rubros.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No hay rubros cargados.", "Sin rubros", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] opciones = new String[rubros.size()];
        for (int i = 0; i < rubros.size(); i++) {
            opciones[i] = rubros.get(i).getId() + " - " + rubros.get(i).getDescripcion();
        }

        String seleccion = (String) JOptionPane.showInputDialog(getVentanaPadre(), "Seleccione el rubro a modificar:",
                "Modificar Rubro", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        if (seleccion == null) return;

        int index = java.util.Arrays.asList(opciones).indexOf(seleccion);
        Rubro rubro = rubros.get(index);

        String nuevaDescripcion = JOptionPane.showInputDialog(getVentanaPadre(), "Nueva descripción:", rubro.getDescripcion());
        if (nuevaDescripcion == null || nuevaDescripcion.trim().isEmpty()) return;

        controller.modificarRubro(rubro.getId(), nuevaDescripcion);
        JOptionPane.showMessageDialog(getVentanaPadre(), "Rubro modificado correctamente.");
        actualizarTabla();
    }

    private void mostrarDialogoAsociarProveedor() {
        List<Producto> productos = controller.getProductos();
        List<Proveedor> proveedores = ProveedorController.getInstance().getProveedores();

        if (productos.isEmpty() || proveedores.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "Debe haber al menos un producto y un proveedor cargados.",
                    "Datos insuficientes", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JDialog dialogo = new JDialog(getVentanaPadre(), "Asociar Producto - Proveedor", true);
        dialogo.setSize(400, 250);
        dialogo.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JComboBox<String> cmbProducto = new JComboBox<>();
        for (Producto p : productos) {
            cmbProducto.addItem(p.getId() + " - " + p.getDescripcion());
        }

        JComboBox<String> cmbProveedor = new JComboBox<>();
        for (Proveedor p : proveedores) {
            cmbProveedor.addItem(p.getCuit() + " - " + p.getRazonSocial());
        }

        JTextField txtPrecio = new JTextField(20);

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(UIHelper.crearLabelObligatorio("Producto:"), gbc);
        gbc.gridx = 1;
        panel.add(cmbProducto, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(UIHelper.crearLabelObligatorio("Proveedor:"), gbc);
        gbc.gridx = 1;
        panel.add(cmbProveedor, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(UIHelper.crearLabelObligatorio("Precio Unitario:"), gbc);
        gbc.gridx = 1;
        panel.add(txtPrecio, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        panel.add(UIHelper.crearLabelCamposObligatorios(), gbc);

        JButton btnGuardar = new JButton("Asociar");
        gbc.gridy = 4;
        panel.add(btnGuardar, gbc);

        UIHelper.configurarEnterEscape(dialogo, btnGuardar);

        btnGuardar.addActionListener(e -> {
            String error = UIHelper.validarFloatPositivo(txtPrecio.getText(), "Precio Unitario");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            Producto producto = productos.get(cmbProducto.getSelectedIndex());
            Proveedor proveedor = proveedores.get(cmbProveedor.getSelectedIndex());
            float precio = Float.parseFloat(txtPrecio.getText());

            controller.asociarProductoProveedor(producto, proveedor, precio);

            JOptionPane.showMessageDialog(dialogo, "Producto asociado al proveedor correctamente.");
            dialogo.dispose();
            actualizarTabla();
        });

        dialogo.add(panel);
        dialogo.setVisible(true);
    }

    private void mostrarDialogoModificarPrecio() {
        List<Producto> productos = controller.getProductos();
        if (productos.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No hay productos cargados.", "Sin productos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] opcionesProducto = new String[productos.size()];
        for (int i = 0; i < productos.size(); i++) {
            opcionesProducto[i] = productos.get(i).getId() + " - " + productos.get(i).getDescripcion();
        }

        String selProd = (String) JOptionPane.showInputDialog(getVentanaPadre(), "Seleccione el producto:",
                "Modificar Precio", JOptionPane.QUESTION_MESSAGE, null, opcionesProducto, opcionesProducto[0]);
        if (selProd == null) return;

        int indexProd = java.util.Arrays.asList(opcionesProducto).indexOf(selProd);
        Producto producto = productos.get(indexProd);

        List<ProductoProveedor> asociaciones = producto.getProveedores();
        if (asociaciones.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "El producto no tiene proveedores asociados.",
                    "Sin proveedores", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] opcionesProveedor = new String[asociaciones.size()];
        for (int i = 0; i < asociaciones.size(); i++) {
            ProductoProveedor pp = asociaciones.get(i);
            opcionesProveedor[i] = pp.getProveedor().getRazonSocial() + " - $" + pp.getPrecioUnitario();
        }

        String selProv = (String) JOptionPane.showInputDialog(getVentanaPadre(), "Seleccione el proveedor:",
                "Modificar Precio", JOptionPane.QUESTION_MESSAGE, null, opcionesProveedor, opcionesProveedor[0]);
        if (selProv == null) return;

        int indexProv = java.util.Arrays.asList(opcionesProveedor).indexOf(selProv);
        ProductoProveedor productoProveedor = asociaciones.get(indexProv);

        String nuevoPrecioStr = JOptionPane.showInputDialog(getVentanaPadre(), "Nuevo precio unitario:",
                productoProveedor.getPrecioUnitario());
        if (nuevoPrecioStr == null) return;

        String error = UIHelper.validarFloatPositivo(nuevoPrecioStr, "Precio Unitario");
        if (error != null) {
            UIHelper.mostrarError(getVentanaPadre(), error);
            return;
        }

        productoProveedor.actualizarPrecio(Float.parseFloat(nuevoPrecioStr));
        JOptionPane.showMessageDialog(getVentanaPadre(), "Precio actualizado correctamente.");
        actualizarTabla();
    }
}
