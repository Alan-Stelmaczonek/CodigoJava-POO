package mvc.view;

import mvc.controller.ParametroRetencionController;
import mvc.model.clases.ParametroRetencion;
import mvc.model.enums.TipoRetencion;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ParametroRetencionView extends JPanel {

    private ParametroRetencionController controller;
    private JTable tablaParametros;
    private DefaultTableModel modeloTabla;

    public ParametroRetencionView() {
        this.controller = ParametroRetencionController.getInstance();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(crearPanelBotones(), BorderLayout.NORTH);
        add(crearPanelTabla(), BorderLayout.CENTER);

        actualizarTabla();
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        JButton btnAlta = new JButton("Alta Parámetro");
        JButton btnModificar = new JButton("Modificar Parámetro");
        JButton btnActualizar = new JButton("Actualizar Listado");

        btnAlta.addActionListener(e -> mostrarDialogoAlta());
        btnModificar.addActionListener(e -> mostrarDialogoModificar());
        btnActualizar.addActionListener(e -> actualizarTabla());

        panel.add(btnAlta);
        panel.add(btnModificar);
        panel.add(btnActualizar);

        return panel;
    }

    private JScrollPane crearPanelTabla() {
        String[] columnas = {"Tipo Impuesto", "Porcentaje (%)", "Mínimo No Imponible"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaParametros = new JTable(modeloTabla);
        return new JScrollPane(tablaParametros);
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);
        List<ParametroRetencion> parametros = controller.listarParametros();
        for (ParametroRetencion p : parametros) {
            modeloTabla.addRow(new Object[]{
                    p.getTipoImpuesto(),
                    p.getPorcentaje(),
                    p.getMinimoNoImponible()
            });
        }
    }

    private JFrame getVentanaPadre() {
        return (JFrame) SwingUtilities.getWindowAncestor(this);
    }

    private void mostrarDialogoAlta() {
        JDialog dialogo = new JDialog(getVentanaPadre(), "Alta de Parámetro de Retención", true);
        dialogo.setSize(400, 250);
        dialogo.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JComboBox<TipoRetencion> cmbTipo = new JComboBox<>(TipoRetencion.values());
        JTextField txtPorcentaje = new JTextField(20);
        JTextField txtMinimo = new JTextField(20);

        JLabel[] labels = {
                UIHelper.crearLabelObligatorio("Tipo Impuesto:"),
                UIHelper.crearLabelObligatorio("Porcentaje (%):"),
                UIHelper.crearLabelObligatorio("Mínimo No Imponible:")
        };
        JComponent[] campos = {cmbTipo, txtPorcentaje, txtMinimo};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i;
            panel.add(labels[i], gbc);
            gbc.gridx = 1;
            panel.add(campos[i], gbc);
        }

        gbc.gridx = 0; gbc.gridy = labels.length; gbc.gridwidth = 2;
        panel.add(UIHelper.crearLabelCamposObligatorios(), gbc);

        JButton btnGuardar = new JButton("Guardar");
        gbc.gridy = labels.length + 1;
        panel.add(btnGuardar, gbc);

        UIHelper.configurarEnterEscape(dialogo, btnGuardar);

        btnGuardar.addActionListener(e -> {
            String error;

            error = UIHelper.validarPorcentaje(txtPorcentaje.getText());
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarFloatPositivo(txtMinimo.getText(), "Mínimo No Imponible");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            TipoRetencion tipo = (TipoRetencion) cmbTipo.getSelectedItem();
            float porcentaje = Float.parseFloat(txtPorcentaje.getText());
            float minimo = Float.parseFloat(txtMinimo.getText());

            ParametroRetencion resultado = controller.altaParametro(tipo, porcentaje, minimo);
            if (resultado == null) {
                UIHelper.mostrarError(dialogo, "Ya existe un parámetro para ese tipo de retención.");
            } else {
                JOptionPane.showMessageDialog(dialogo, "Parámetro dado de alta correctamente.");
                dialogo.dispose();
                actualizarTabla();
            }
        });

        dialogo.add(panel);
        dialogo.setVisible(true);
    }

    private void mostrarDialogoModificar() {
        List<ParametroRetencion> parametros = controller.listarParametros();
        if (parametros.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No hay parámetros cargados.",
                    "Sin parámetros", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] opciones = new String[parametros.size()];
        for (int i = 0; i < parametros.size(); i++) {
            opciones[i] = parametros.get(i).getTipoImpuesto().toString();
        }

        String seleccion = (String) JOptionPane.showInputDialog(getVentanaPadre(), "Seleccione el parámetro a modificar:",
                "Modificar Parámetro", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        if (seleccion == null) return;

        TipoRetencion tipoSeleccionado = TipoRetencion.valueOf(seleccion);
        ParametroRetencion parametro = controller.buscarParametro(tipoSeleccionado);

        JDialog dialogo = new JDialog(getVentanaPadre(), "Modificar Parámetro - " + seleccion, true);
        dialogo.setSize(400, 220);
        dialogo.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtPorcentaje = new JTextField(String.valueOf(parametro.getPorcentaje()), 20);
        JTextField txtMinimo = new JTextField(String.valueOf(parametro.getMinimoNoImponible()), 20);

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(UIHelper.crearLabelObligatorio("Porcentaje (%):"), gbc);
        gbc.gridx = 1;
        panel.add(txtPorcentaje, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(UIHelper.crearLabelObligatorio("Mínimo No Imponible:"), gbc);
        gbc.gridx = 1;
        panel.add(txtMinimo, gbc);

        JButton btnGuardar = new JButton("Guardar Cambios");
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        panel.add(btnGuardar, gbc);

        UIHelper.configurarEnterEscape(dialogo, btnGuardar);

        btnGuardar.addActionListener(e -> {
            String error;

            error = UIHelper.validarPorcentaje(txtPorcentaje.getText());
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarFloatPositivo(txtMinimo.getText(), "Mínimo No Imponible");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            float porcentaje = Float.parseFloat(txtPorcentaje.getText());
            float minimo = Float.parseFloat(txtMinimo.getText());

            controller.modificarParametro(tipoSeleccionado, porcentaje, minimo);
            JOptionPane.showMessageDialog(dialogo, "Parámetro modificado correctamente.");
            dialogo.dispose();
            actualizarTabla();
        });

        dialogo.add(panel);
        dialogo.setVisible(true);
    }
}
