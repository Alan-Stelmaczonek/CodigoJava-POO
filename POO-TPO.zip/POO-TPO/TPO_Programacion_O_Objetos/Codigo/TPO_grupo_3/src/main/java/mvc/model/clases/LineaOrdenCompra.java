package mvc.model.clases;


public class LineaOrdenCompra {
    private int cantidad;
    private ProductoProveedor productoProveedor;

    public LineaOrdenCompra(int cantidad, ProductoProveedor productoProveedor) {
        this.cantidad = cantidad;
        this.productoProveedor = productoProveedor;
    }

    public int getCantidad() {
        return cantidad;
    }

    public ProductoProveedor getProductoProveedor() {
        return productoProveedor;
    }

    public float getSubtotal() {
        return cantidad * productoProveedor.getPrecioUnitario();
    }




}
