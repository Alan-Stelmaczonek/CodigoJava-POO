package mvc.dto;

import java.util.Date;

public class OrdenPagoDTO {
    private int numero;
    private Date fecha;
    private String razonSocialProveedor;
    private float totalACancelar;
    private float totalRetenciones;
    private float montoAPagar;

    public OrdenPagoDTO(int numero, Date fecha, String razonSocialProveedor, float totalACancelar, float totalRetenciones, float montoAPagar) {
        this.numero = numero;
        this.fecha = fecha;
        this.razonSocialProveedor = razonSocialProveedor;
        this.totalACancelar = totalACancelar;
        this.totalRetenciones = totalRetenciones;
        this.montoAPagar = montoAPagar;
    }

    public int getNumero() {
        return numero;
    }
    public Date getFecha() {
        return fecha;
    }
    public String getRazonSocialProveedor() {
        return razonSocialProveedor;
    }
    public float getTotalACancelar() {
        return totalACancelar;
    }
    public float getTotalRetenciones() {
        return totalRetenciones;
    }
    public float getMontoAPagar() {
        return montoAPagar;
    }
}
