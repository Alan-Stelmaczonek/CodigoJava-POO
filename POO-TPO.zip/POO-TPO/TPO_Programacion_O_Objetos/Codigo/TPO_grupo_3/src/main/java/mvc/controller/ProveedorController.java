package mvc.controller;

import mvc.dto.ProveedorDTO;
import mvc.model.clases.CertificadoNoRetencion;
import mvc.model.clases.Proveedor;
import mvc.model.clases.Rubro;
import mvc.model.enums.ResponsabilidadIVA;
import mvc.model.enums.TipoRetencion;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.Map;

public class ProveedorController {

    private static ProveedorController INSTANCE = null;

    private List<Proveedor> proveedores = new ArrayList<>();

    private ProveedorController() {
        this.proveedores = new ArrayList<>();
    }

    public static synchronized ProveedorController getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ProveedorController();
        }
        return INSTANCE;
    }

    public Proveedor altaProveedor(String cuit, String razonSocial, ResponsabilidadIVA respIVA,
                                   String nombreFantasia, String direccion, String telefono, String email, String nroIIBB,
                                   Date fechaInicio, List<Rubro> rubros, float limiteDeuda) {
        if (buscarProveedor(cuit) != null) {
            System.out.println("El Proveedor que quiso crear con CUIT " + cuit + " ya existe en el sistema");
            return null;
        } else {
            Proveedor proveedor = new Proveedor(cuit, respIVA,
                    nombreFantasia, razonSocial, direccion, telefono, email,
                    nroIIBB, fechaInicio, limiteDeuda);
            for (Rubro rubro : rubros) {
                proveedor.agregarRubro(rubro);
            }
            proveedores.add(proveedor);
            return proveedor;
        }
    }

    public boolean modificarProveedor(String cuit, Map<String, Object> datosActualizados) {
        Proveedor proveedor = buscarProveedor(cuit);
        if (proveedor == null) {
            return false;
        } else {
            if (datosActualizados.containsKey("razonSocial")) {
                proveedor.setRazonSocial((String) datosActualizados.get("razonSocial"));
            }
            if (datosActualizados.containsKey("telefono")) {
                proveedor.setTelefono((String) datosActualizados.get("telefono"));
            }
            if (datosActualizados.containsKey("email")) {
                proveedor.setEmail((String) datosActualizados.get("email"));
            }
            if (datosActualizados.containsKey("direccion")) {
                proveedor.setDireccion((String) datosActualizados.get("direccion"));
            }
            if (datosActualizados.containsKey("limiteDeuda")) {
                proveedor.setLimiteDeuda((Float) datosActualizados.get("limiteDeuda"));
            }
            if (datosActualizados.containsKey("nombreFantasia")) {
                proveedor.setNombreFantasia((String) datosActualizados.get("nombreFantasia"));
            }
            if (datosActualizados.containsKey("nroIIBB")) {
                proveedor.setNroIngresosBrutos((String) datosActualizados.get("nroIIBB"));
            }
            if (datosActualizados.containsKey("responsabilidadIVA")) {
                proveedor.setResponsabilidadIVA((ResponsabilidadIVA) datosActualizados.get("responsabilidadIVA"));
            }
            return true;
        }
    }

    public Proveedor buscarProveedor(String cuit) {
        for (Proveedor proveedor : proveedores) {
            if (proveedor.getCuit().equals(cuit)) {
                return proveedor;
            }
        }
        return null;
    }

    public CertificadoNoRetencion cargarCertificadoNoRetencion(Proveedor proveedor, TipoRetencion tipoImpuesto, Date fechaInicio, Date fechaVencimiento) {
        CertificadoNoRetencion certificadoNoRetencion = new CertificadoNoRetencion(tipoImpuesto, fechaInicio,fechaVencimiento);
        proveedor.agregarCertificado(certificadoNoRetencion);
        return certificadoNoRetencion;
    }

    public List<ProveedorDTO> listarProveedores() {
            List<ProveedorDTO> lista = new ArrayList<>();
            for (Proveedor proveedor : proveedores) {
                lista.add(toDTO(proveedor));
            }
            return lista;
        }

    public List<Proveedor> getProveedores() {
        return proveedores;
    }

    private Proveedor toModel(String cuit, String razonSocial, String nombreFantasia,
                              String responsabilidadIVA, String direccion, String telefono,
                              String email, String nroIngresosBrutos, String fechaInicio,
                              String limiteDeuda) throws Exception {
        ResponsabilidadIVA respIVA = ResponsabilidadIVA.valueOf(responsabilidadIVA);
        float limDeuda = Float.parseFloat(limiteDeuda);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date fecha = sdf.parse(fechaInicio);

        Proveedor proveedor = new Proveedor(cuit, respIVA, razonSocial, nombreFantasia, direccion, telefono, email,
                nroIngresosBrutos, fecha, limDeuda);

        return proveedor;
    }


    private ProveedorDTO toDTO(Proveedor proveedor) {
        ProveedorDTO dto = new ProveedorDTO(proveedor.getCuit(), proveedor.getRazonSocial(), proveedor.getNombreFantasia(), proveedor.getResponsabilidadIVA(), proveedor.getDireccion(),
                proveedor.getTelefono(), proveedor.getEmail(), proveedor.getNroIngresosBrutos(), proveedor.getFechaInicioActividades(),
                proveedor.getLimiteDeuda(), proveedor.getDeudaTotal(), proveedor.getRubros().size(), proveedor.getOrdenesDePago().size(), proveedor.getCertificados().size());
        return dto;
    }
}

















