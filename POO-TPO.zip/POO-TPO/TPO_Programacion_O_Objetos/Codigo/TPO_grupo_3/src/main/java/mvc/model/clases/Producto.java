package mvc.model.clases;

import mvc.model.enums.TipoIVA;
import java.util.ArrayList;
import java.util.List;


public class Producto {
    private int id;
    private String descripcion;
    private TipoIVA tipoIVA;
    private String UnidadMedidad;
    private Rubro rubro;
    private List<ProductoProveedor> proveedores = new ArrayList<>();

    public Producto(int id, String descripcion, TipoIVA tipoIVA, String unidadMedidad, Rubro rubro) {
        this.id = id;
        this.descripcion = descripcion;
        this.tipoIVA = tipoIVA;
        this.UnidadMedidad = unidadMedidad;
        this.rubro = rubro;
    }

    public int getId() {
        return id;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public TipoIVA getTipoIVA() {
        return tipoIVA;
    }
    public Rubro getRubro() {
        return rubro;
    }
    public String getUnidadMedidad() {
        return UnidadMedidad;
    }

    public void agregarProveedor(ProductoProveedor productoProveedor) {
        proveedores.add(productoProveedor);
    }

    public List<ProductoProveedor> getProveedores() {
        return new ArrayList<>(proveedores);
    }
}