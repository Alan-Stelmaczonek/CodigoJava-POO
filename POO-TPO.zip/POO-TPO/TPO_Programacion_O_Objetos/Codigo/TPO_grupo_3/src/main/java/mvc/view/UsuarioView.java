package mvc.view;

import mvc.controller.UsuarioController;
import mvc.dto.UsuarioDTO;
import mvc.model.clases.Rol;
import mvc.model.clases.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsuarioView extends JPanel {

    private UsuarioController controller;
    private JTable tablaUsuarios;
    private DefaultTableModel modeloTabla;

    public UsuarioView() {
        this.controller = UsuarioController.getInstance();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(crearPanelBotones(), BorderLayout.NORTH);
        add(crearPanelTabla(), BorderLayout.CENTER);

        actualizarTabla();
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        JButton btnAlta = new JButton("Alta Usuario");
        JButton btnModificar = new JButton("Modificar Usuario");
        JButton btnEliminar = new JButton("Eliminar Usuario");
        JButton btnActualizar = new JButton("Actualizar Listado");

        btnAlta.addActionListener(e -> mostrarDialogoAlta());
        btnModificar.addActionListener(e -> mostrarDialogoModificar());
        btnEliminar.addActionListener(e -> eliminarUsuario());
        btnActualizar.addActionListener(e -> actualizarTabla());

        panel.add(btnAlta);
        panel.add(btnModificar);
        panel.add(btnEliminar);
        panel.add(btnActualizar);

        return panel;
    }

    private JScrollPane crearPanelTabla() {
        String[] columnas = {"Nombre Usuario", "Rol", "Permisos"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaUsuarios = new JTable(modeloTabla);
        return new JScrollPane(tablaUsuarios);
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);
        List<UsuarioDTO> usuarios = controller.listarUsuarios();
        for (UsuarioDTO u : usuarios) {
            modeloTabla.addRow(new Object[]{
                    u.getNombreUsuario(),
                    u.getNombreRol(),
                    u.getPermisos()
            });
        }
    }

    private JFrame getVentanaPadre() {
        return (JFrame) SwingUtilities.getWindowAncestor(this);
    }

    private void mostrarDialogoAlta() {
        JDialog dialogo = new JDialog(getVentanaPadre(), "Alta de Usuario", true);
        dialogo.setSize(400, 320);
        dialogo.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtNombreUsuario = new JTextField(20);
        JPasswordField txtContrasenia = new JPasswordField(20);
        JTextField txtNombreRol = new JTextField(20);
        JTextField txtPermisos = new JTextField(20);
        txtPermisos.setToolTipText("Separados por coma: proveedores,productos,usuarios");

        JLabel[] labels = {
                UIHelper.crearLabelObligatorio("Nombre Usuario:"),
                UIHelper.crearLabelObligatorio("Contraseña:"),
                UIHelper.crearLabelObligatorio("Nombre del Rol:"),
                UIHelper.crearLabelObligatorio("Permisos:")
        };
        JComponent[] campos = {txtNombreUsuario, txtContrasenia, txtNombreRol, txtPermisos};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i;
            panel.add(labels[i], gbc);
            gbc.gridx = 1;
            panel.add(campos[i], gbc);
        }

        gbc.gridx = 0; gbc.gridy = labels.length; gbc.gridwidth = 2;
        panel.add(UIHelper.crearLabelCamposObligatorios(), gbc);

        JButton btnGuardar = new JButton("Guardar");
        gbc.gridy = labels.length + 1;
        panel.add(btnGuardar, gbc);

        UIHelper.configurarEnterEscape(dialogo, btnGuardar);

        btnGuardar.addActionListener(e -> {
            String nombre = txtNombreUsuario.getText();
            String contrasenia = new String(txtContrasenia.getPassword());
            String nombreRol = txtNombreRol.getText();
            String permisosTexto = txtPermisos.getText();

            String error;

            error = UIHelper.validarNombreUsuario(nombre);
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarContrasenia(contrasenia);
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarNoVacio(nombreRol, "Nombre del Rol");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            error = UIHelper.validarNoVacio(permisosTexto, "Permisos");
            if (error != null) { UIHelper.mostrarError(dialogo, error); return; }

            List<String> listaPermisos = Arrays.asList(permisosTexto.split(","));
            Rol rol = new Rol(nombreRol, listaPermisos);

            Usuario resultado = controller.altaUsuario(nombre, contrasenia, rol);
            if (resultado == null) {
                UIHelper.mostrarError(dialogo, "El usuario ya existe.");
            } else {
                JOptionPane.showMessageDialog(dialogo, "Usuario dado de alta correctamente.");
                dialogo.dispose();
                actualizarTabla();
            }
        });

        dialogo.add(panel);
        dialogo.setVisible(true);
    }

    private void mostrarDialogoModificar() {
        String nombreUsuario = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el nombre del usuario a modificar:");
        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()) return;

        if (controller.buscarUsuario(nombreUsuario) == null) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No se encontró el usuario: " + nombreUsuario,
                    "No encontrado", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JDialog dialogo = new JDialog(getVentanaPadre(), "Modificar Usuario - " + nombreUsuario, true);
        dialogo.setSize(400, 250);
        dialogo.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtNuevoNombre = new JTextField(20);
        JPasswordField txtNuevaContrasenia = new JPasswordField(20);

        String[] labels = {"Nuevo Nombre:", "Nueva Contraseña:"};
        JComponent[] campos = {txtNuevoNombre, txtNuevaContrasenia};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i;
            panel.add(new JLabel(labels[i]), gbc);
            gbc.gridx = 1;
            panel.add(campos[i], gbc);
        }

        JLabel lblInfo = new JLabel("Deje vacío lo que no desee modificar.");
        lblInfo.setFont(lblInfo.getFont().deriveFont(Font.ITALIC, 11f));
        gbc.gridx = 0; gbc.gridy = labels.length; gbc.gridwidth = 2;
        panel.add(lblInfo, gbc);

        JButton btnGuardar = new JButton("Guardar Cambios");
        gbc.gridy = labels.length + 1;
        panel.add(btnGuardar, gbc);

        UIHelper.configurarEnterEscape(dialogo, btnGuardar);

        btnGuardar.addActionListener(e -> {
            Map<String, Object> datos = new HashMap<>();
            String error;

            if (!txtNuevoNombre.getText().isEmpty()) {
                error = UIHelper.validarNombreUsuario(txtNuevoNombre.getText());
                if (error != null) { UIHelper.mostrarError(dialogo, error); return; }
                datos.put("NombreUsuario", txtNuevoNombre.getText());
            }

            String nuevaPass = new String(txtNuevaContrasenia.getPassword());
            if (!nuevaPass.isEmpty()) {
                error = UIHelper.validarContrasenia(nuevaPass);
                if (error != null) { UIHelper.mostrarError(dialogo, error); return; }
                datos.put("contrasenia", nuevaPass);
            }

            if (datos.isEmpty()) {
                JOptionPane.showMessageDialog(dialogo, "No se ingresaron cambios.");
                return;
            }

            controller.modificarUsuario(nombreUsuario, datos);
            JOptionPane.showMessageDialog(dialogo, "Usuario modificado correctamente.");
            dialogo.dispose();
            actualizarTabla();
        });

        dialogo.add(panel);
        dialogo.setVisible(true);
    }

    private void eliminarUsuario() {
        String nombreUsuario = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el nombre del usuario a eliminar:");
        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()) return;

        int confirmacion = JOptionPane.showConfirmDialog(getVentanaPadre(),
                "¿Está seguro de eliminar al usuario '" + nombreUsuario + "'?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            boolean eliminado = controller.eliminarUsuario(nombreUsuario);
            if (eliminado) {
                JOptionPane.showMessageDialog(getVentanaPadre(), "Usuario eliminado correctamente.");
                actualizarTabla();
            } else {
                JOptionPane.showMessageDialog(getVentanaPadre(), "No se encontró el usuario: " + nombreUsuario,
                        "No encontrado", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
}
