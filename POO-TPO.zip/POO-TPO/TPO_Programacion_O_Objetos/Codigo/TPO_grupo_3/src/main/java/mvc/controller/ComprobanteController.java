package mvc.controller;

import mvc.dto.ComprobanteDTO;
import mvc.model.enums.EstadoComprobante;
import mvc.model.clases.*;
import mvc.model.clases.Usuario;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ComprobanteController {
    private static ComprobanteController INSTANCE = null;
    private List<Comprobante> comprobante = new ArrayList<>();
    private int contadorComprobante;

    private ComprobanteController() {
        comprobante = new ArrayList<>();
        this.contadorComprobante = 0;
    }

    public static synchronized ComprobanteController getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ComprobanteController();
        }
        return INSTANCE;
    }

    public NotaCredito registrarNotaCredito(Proveedor proveedor, List<LineaComprobante> lineas, Date fecha, Factura facturaAsociada) {
        contadorComprobante++;
        NotaCredito notaCredito = new NotaCredito(contadorComprobante, fecha, EstadoComprobante.PENDIENTE_APROBACION,
                                                  lineas, proveedor, facturaAsociada);
        proveedor.agregarComprobante(notaCredito);
        comprobante.add(notaCredito);
        return notaCredito;
    }

    public NotaDebito registrarNotaDebito(Proveedor proveedor, List<LineaComprobante> lineas, Date fecha, String descripcionMotivo) {
        contadorComprobante++;
        NotaDebito notaDebito = new NotaDebito(contadorComprobante, fecha, EstadoComprobante.PENDIENTE_APROBACION,
                lineas, proveedor, descripcionMotivo);
        proveedor.agregarComprobante(notaDebito);
        comprobante.add(notaDebito);
        return notaDebito;
    }

    public Factura registrarFactura(Proveedor proveedor, OrdenCompra oc, List<LineaComprobante> lineas, Date fecha, Usuario usuario) {
        contadorComprobante++;
        Factura factura = new Factura(contadorComprobante, fecha, EstadoComprobante.PENDIENTE_APROBACION, lineas, proveedor, oc);

        // Si la factura tiene OC asociada y los precios coinciden, se aprueba automáticamente.
        // Si no tiene OC o los precios no coinciden, requiere validación y aceptación de un
        // supervisor (en el momento de la carga, o luego mediante aprobarFactura).
        boolean precioCoincideConOC = oc != null && factura.validarPreciosContraOC(oc);
        if (precioCoincideConOC || usuario.esSupervisor()) {
            factura.aprobar();
        }

        proveedor.agregarComprobante(factura);
        comprobante.add(factura);
        return factura;
    }

    
    public boolean aprobarFactura(int numero, Usuario supervisor) {
        for (Comprobante factura : comprobante) {
            if (factura.getNumero() == numero) {
                if (supervisor.esSupervisor()) {
                    factura.aprobar();
                    return true;
                }
            }
        }
        return false;
    }

    public Factura buscarFacturaPorNumero(int numero) {
        for (Comprobante c : comprobante) {
            if (c instanceof Factura && c.getNumero() == numero) {
                return (Factura) c;
            }
        }
        return null;
    }

    public List<ComprobanteDTO> listarComprobante() {
        List<ComprobanteDTO> lista = new ArrayList<>();
        for (Comprobante factura : comprobante) {
            lista.add(toDTO(factura));
        }
        return lista;
    }

    private ComprobanteDTO toDTO(Comprobante comprobante) {
        ComprobanteDTO dto = new ComprobanteDTO(comprobante.getNumero(), comprobante.getTipo(),
                                                comprobante.getFecha(), comprobante.getProveedor().getRazonSocial(),
                                                comprobante.calcularTotal() ,comprobante.getEstado());
        return dto;
    }
}
