package mvc.model.clases;

import java.util.ArrayList;
import java.util.List;

public class Rol {
    private String nombre;
    private  List <String> permisos = new ArrayList<>();

    public Rol (String nombre, List <String> permisos) {
        this.nombre = nombre;
        this.permisos = new ArrayList<>(permisos);
    }
    public void  agregarPermisos(String permisos){
        this.permisos.add(permisos);
    }
    public String getNombre() {
        return nombre;
    }
    public List<String> getPermisos() {
        return new ArrayList<>(permisos);
    }
    public boolean tienePermiso(String permiso)  {
        return permisos.contains(permiso);
    }
}
