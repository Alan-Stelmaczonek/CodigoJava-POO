package mvc.view;

import mvc.controller.ComprobanteController;
import mvc.controller.OrdenCompraController;
import mvc.controller.ProveedorController;
import mvc.controller.UsuarioController;
import mvc.dto.ComprobanteDTO;
import mvc.model.clases.Factura;
import mvc.model.clases.LineaComprobante;
import mvc.model.clases.OrdenCompra;
import mvc.model.clases.Proveedor;
import mvc.model.clases.Usuario;
import mvc.model.enums.TipoIVA;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ComprobanteView extends JPanel {

    private ComprobanteController controller;
    private JTable tablaComprobantes;
    private DefaultTableModel modeloTabla;

    public ComprobanteView() {
        this.controller = ComprobanteController.getInstance();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(crearPanelBotones(), BorderLayout.NORTH);
        add(crearPanelTabla(), BorderLayout.CENTER);

        actualizarTabla();
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        JButton btnFactura = new JButton("Registrar Factura");
        JButton btnNotaCredito = new JButton("Registrar Nota Crédito");
        JButton btnNotaDebito = new JButton("Registrar Nota Débito");
        JButton btnAprobar = new JButton("Aprobar Comprobante");
        JButton btnActualizar = new JButton("Actualizar Listado");

        btnFactura.addActionListener(e -> mostrarDialogoFactura());
        btnNotaCredito.addActionListener(e -> mostrarDialogoNotaCredito());
        btnNotaDebito.addActionListener(e -> mostrarDialogoNotaDebito());
        btnAprobar.addActionListener(e -> aprobarComprobante());
        btnActualizar.addActionListener(e -> actualizarTabla());

        panel.add(btnFactura);
        panel.add(btnNotaCredito);
        panel.add(btnNotaDebito);
        panel.add(btnAprobar);
        panel.add(btnActualizar);

        return panel;
    }

    private JScrollPane crearPanelTabla() {
        String[] columnas = {"Número", "Tipo", "Fecha", "Proveedor", "Total", "Estado"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaComprobantes = new JTable(modeloTabla);
        return new JScrollPane(tablaComprobantes);
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);
        List<ComprobanteDTO> comprobantes = controller.listarComprobante();
        for (ComprobanteDTO c : comprobantes) {
            modeloTabla.addRow(new Object[]{
                    c.getNumero(),
                    c.getTipo(),
                    c.getFecha(),
                    c.getRazonSocialProveedor(),
                    c.getTotal(),
                    c.getEstado()
            });
        }
    }

    private JFrame getVentanaPadre() {
        return (JFrame) SwingUtilities.getWindowAncestor(this);
    }

    private Proveedor seleccionarProveedor() {
        List<Proveedor> proveedores = ProveedorController.getInstance().getProveedores();
        if (proveedores.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No hay proveedores cargados.",
                    "Sin proveedores", JOptionPane.WARNING_MESSAGE);
            return null;
        }

        String[] opciones = new String[proveedores.size()];
        for (int i = 0; i < proveedores.size(); i++) {
            opciones[i] = proveedores.get(i).getCuit() + " - " + proveedores.get(i).getRazonSocial();
        }

        String seleccion = (String) JOptionPane.showInputDialog(getVentanaPadre(), "Seleccione el proveedor:",
                "Proveedor", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        if (seleccion == null) return null;

        int index = java.util.Arrays.asList(opciones).indexOf(seleccion);
        return proveedores.get(index);
    }

    private List<LineaComprobante> cargarLineas() {
        List<LineaComprobante> lineas = new ArrayList<>();
        boolean agregarMas = true;

        while (agregarMas) {
            JPanel panelLinea = new JPanel(new GridLayout(3, 2, 5, 5));
            JTextField txtCantidad = new JTextField();
            JTextField txtPrecio = new JTextField();
            JComboBox<TipoIVA> cmbIVA = new JComboBox<>(TipoIVA.values());

            panelLinea.add(new JLabel("Cantidad:"));
            panelLinea.add(txtCantidad);
            panelLinea.add(new JLabel("Precio Unitario:"));
            panelLinea.add(txtPrecio);
            panelLinea.add(new JLabel("Tipo IVA:"));
            panelLinea.add(cmbIVA);

            int resultado = JOptionPane.showConfirmDialog(getVentanaPadre(), panelLinea,
                    "Línea " + (lineas.size() + 1), JOptionPane.OK_CANCEL_OPTION);

            if (resultado == JOptionPane.OK_OPTION) {
                String error;

                error = UIHelper.validarEnteroPositivo(txtCantidad.getText(), "Cantidad");
                if (error != null) { UIHelper.mostrarError(getVentanaPadre(), error); continue; }

                error = UIHelper.validarFloatPositivo(txtPrecio.getText(), "Precio Unitario");
                if (error != null) { UIHelper.mostrarError(getVentanaPadre(), error); continue; }

                int cantidad = Integer.parseInt(txtCantidad.getText());
                float precio = Float.parseFloat(txtPrecio.getText());
                TipoIVA tipoIVA = (TipoIVA) cmbIVA.getSelectedItem();

                lineas.add(new LineaComprobante(cantidad, precio, tipoIVA));

                int otraLinea = JOptionPane.showConfirmDialog(getVentanaPadre(),
                        "¿Agregar otra línea?", "Continuar", JOptionPane.YES_NO_OPTION);
                agregarMas = (otraLinea == JOptionPane.YES_OPTION);
            } else {
                agregarMas = false;
            }
        }

        return lineas;
    }

    private void mostrarDialogoFactura() {
        Proveedor proveedor = seleccionarProveedor();
        if (proveedor == null) return;

        List<OrdenCompra> ordenesCompra = OrdenCompraController.getInstance().getOrdenesCompra();
        OrdenCompra ocSeleccionada = null;

        if (!ordenesCompra.isEmpty()) {
            String[] opciones = new String[ordenesCompra.size()];
            for (int i = 0; i < ordenesCompra.size(); i++) {
                opciones[i] = "OC #" + ordenesCompra.get(i).getNumero() + " - " + ordenesCompra.get(i).getRazonSocialProveedor();
            }

            String seleccion = (String) JOptionPane.showInputDialog(getVentanaPadre(),
                    "Seleccione la Orden de Compra asociada:", "Orden de Compra",
                    JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

            if (seleccion != null) {
                int index = java.util.Arrays.asList(opciones).indexOf(seleccion);
                ocSeleccionada = ordenesCompra.get(index);
            }
        }

        List<LineaComprobante> lineas = cargarLineas();
        if (lineas.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "Debe agregar al menos una línea.", "Sin líneas", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String nombreUsuario = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el nombre del usuario que carga la factura:");
        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()) return;

        Usuario usuarioActual = UsuarioController.getInstance().buscarUsuario(nombreUsuario);
        if (usuarioActual == null) {
            UIHelper.mostrarError(getVentanaPadre(), "No se encontró el usuario: " + nombreUsuario);
            return;
        }

        controller.registrarFactura(proveedor, ocSeleccionada, lineas, new Date(), usuarioActual);
        JOptionPane.showMessageDialog(getVentanaPadre(), "Factura registrada correctamente.");
        actualizarTabla();
    }

    private void mostrarDialogoNotaCredito() {
        Proveedor proveedor = seleccionarProveedor();
        if (proveedor == null) return;

        List<ComprobanteDTO> comprobantes = controller.listarComprobante();
        List<ComprobanteDTO> facturas = new ArrayList<>();
        for (ComprobanteDTO c : comprobantes) {
            if (c.getTipo().equals("Factura")) {
                facturas.add(c);
            }
        }

        Factura facturaAsociada = null;
        if (!facturas.isEmpty()) {
            String[] opciones = new String[facturas.size()];
            for (int i = 0; i < facturas.size(); i++) {
                opciones[i] = "Factura #" + facturas.get(i).getNumero() + " - $" + facturas.get(i).getTotal();
            }

            String seleccion = (String) JOptionPane.showInputDialog(getVentanaPadre(),
                    "Seleccione la factura asociada:", "Factura asociada",
                    JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

            if (seleccion == null) return;

            int indiceSeleccionado = java.util.Arrays.asList(opciones).indexOf(seleccion);
            facturaAsociada = controller.buscarFacturaPorNumero(facturas.get(indiceSeleccionado).getNumero());
        }

        List<LineaComprobante> lineas = cargarLineas();
        if (lineas.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "Debe agregar al menos una línea.", "Sin líneas", JOptionPane.WARNING_MESSAGE);
            return;
        }

        controller.registrarNotaCredito(proveedor, lineas, new Date(), facturaAsociada);
        JOptionPane.showMessageDialog(getVentanaPadre(), "Nota de Crédito registrada correctamente.");
        actualizarTabla();
    }

    private void mostrarDialogoNotaDebito() {
        Proveedor proveedor = seleccionarProveedor();
        if (proveedor == null) return;

        String motivo = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el motivo de la Nota de Débito:");
        if (motivo == null || motivo.trim().isEmpty()) {
            UIHelper.mostrarError(getVentanaPadre(), "El motivo es obligatorio.");
            return;
        }

        List<LineaComprobante> lineas = cargarLineas();
        if (lineas.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "Debe agregar al menos una línea.", "Sin líneas", JOptionPane.WARNING_MESSAGE);
            return;
        }

        controller.registrarNotaDebito(proveedor, lineas, new Date(), motivo);
        JOptionPane.showMessageDialog(getVentanaPadre(), "Nota de Débito registrada correctamente.");
        actualizarTabla();
    }

    private void aprobarComprobante() {
        String numeroStr = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el número del comprobante a aprobar:");
        if (numeroStr == null || numeroStr.trim().isEmpty()) return;

        String error = UIHelper.validarEnteroPositivo(numeroStr, "Número de comprobante");
        if (error != null) { UIHelper.mostrarError(getVentanaPadre(), error); return; }

        String supervisorNombre = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el nombre del supervisor:");
        if (supervisorNombre == null || supervisorNombre.trim().isEmpty()) return;

        int numero = Integer.parseInt(numeroStr);
        Usuario supervisor = UsuarioController.getInstance().buscarUsuario(supervisorNombre);

        if (supervisor == null) {
            UIHelper.mostrarError(getVentanaPadre(), "No se encontró el usuario: " + supervisorNombre);
            return;
        }

        boolean aprobado = controller.aprobarFactura(numero, supervisor);
        if (aprobado) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "Comprobante aprobado correctamente.");
            actualizarTabla();
        } else {
            UIHelper.mostrarError(getVentanaPadre(), "No se pudo aprobar. Verifique el número y que el usuario sea supervisor.");
        }
    }
}
