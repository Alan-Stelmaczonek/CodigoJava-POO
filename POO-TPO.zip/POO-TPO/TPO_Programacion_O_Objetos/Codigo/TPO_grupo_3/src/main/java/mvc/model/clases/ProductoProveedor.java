package mvc.model.clases;

public class ProductoProveedor {
    private Producto producto;
    private Proveedor proveedor;
    float precioUnitario;

    public ProductoProveedor(Producto producto, Proveedor proveedor, float precioUnitario) {
        this.producto = producto;
        this.proveedor = proveedor;
        this.precioUnitario = precioUnitario;
    }


    public void actualizarPrecio(float nuevoPrecio) {
        precioUnitario = nuevoPrecio;
    }
    public float getPrecioUnitario() {
        return precioUnitario;
    }

    public Producto getProducto() {
        return producto;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }
}
