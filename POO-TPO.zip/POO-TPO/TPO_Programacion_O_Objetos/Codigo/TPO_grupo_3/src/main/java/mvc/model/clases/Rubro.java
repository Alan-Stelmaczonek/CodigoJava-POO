package mvc.model.clases;

public class Rubro {
    private int id;
    private String descripcion;

    public Rubro(int id, String descripcion) {
        this.id = id;
        this.descripcion = descripcion;
    }
    public int getId() {
        return id;
    }
    public String getDescripcion() {
        return descripcion;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
