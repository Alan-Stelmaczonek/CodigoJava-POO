package mvc.dto;

import mvc.model.enums.EstadoOrdenCompra;

import java.util.Date;

public class OrdenCompraDTO {
    private int numero;
    private Date fecha;
    private String razonSocialProveedor;
    private float total;
    private EstadoOrdenCompra estado;

    public OrdenCompraDTO(int numero, Date fecha, String razonSocialProveedor, float total, EstadoOrdenCompra estado) {
        this.numero = numero;
        this.fecha = fecha;
        this.razonSocialProveedor = razonSocialProveedor;
        this.total = total;
        this.estado = estado;
    }
    public int getNumero() {
        return numero;
    }
    public Date getFecha() {
        return fecha;
    }
    public String getRazonSocialProveedor() {
        return razonSocialProveedor;
    }
    public float getTotal() {
        return total;
    }
    public EstadoOrdenCompra getEstado() {
        return estado;
    }
}
