package mvc.model.clases;

import java.util.Date;

public abstract class Cheque extends MedioPago {
    Date fechaEmision;
    Date fechaVencimiento;
    String firmante;


    public Cheque(float monto, Date fechaEmision , Date fechaVencimiento, String firmante) {
        super(monto);
        this.fechaEmision = fechaEmision;
        this.fechaVencimiento = fechaVencimiento;
        this.firmante = firmante;
    }
    public Date getFechaEmision() {
        return fechaEmision;

    }

    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }

    public String getFirmante() {
        return firmante;
    }

    public boolean isVencido() {
        return new Date().after(fechaVencimiento);
    }
}
