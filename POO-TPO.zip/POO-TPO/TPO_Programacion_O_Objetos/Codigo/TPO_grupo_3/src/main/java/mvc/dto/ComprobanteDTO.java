package mvc.dto;

import mvc.model.enums.EstadoComprobante;

import java.util.Date;

public class ComprobanteDTO {
    private int numero;
    private String tipo;
    private Date fecha;
    private String razonSocialProveedor;
    private float total;
    private EstadoComprobante estado;

    public ComprobanteDTO(int numero, String tipo, Date fecha, String razonSocialProveedor, float total, EstadoComprobante estado) {

        this.numero = numero;
        this.tipo = tipo;
        this.fecha = fecha;
        this.razonSocialProveedor = razonSocialProveedor;
        this.total = total;
        this.estado = estado;

    }

    public int getNumero() {
        return numero;
    }

    public String getTipo() {
        return tipo;
    }

    public Date getFecha() {
        return fecha;
    }

    public String getRazonSocialProveedor() {
        return razonSocialProveedor;
    }

    public float getTotal() {
        return total;
    }

    public EstadoComprobante getEstado() {
        return estado;
    }

    public boolean isPagado() {
        return estado == EstadoComprobante.PAGADO;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setRazonSocialProveedor(String razonSocialProveedor) {
        this.razonSocialProveedor = razonSocialProveedor;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public void setEstado(EstadoComprobante estado) {
        this.estado = estado;
    }
}
