package mvc.model.clases;

import java.util.Date;

public class ChequeDeTerceros extends Cheque{
    String emisorOriginal;


    public ChequeDeTerceros (float monto, Date fechaEmision, Date fechaVencimiento, String firmante, String emisorOriginal) {
        super(monto, fechaEmision, fechaVencimiento, firmante);
        this.emisorOriginal = emisorOriginal;
    }

    @Override
    public String getDescripcion() {
        return "Terceros";
    }

    @Override
    public String getDetalle() {
        return "Firmante: " + firmante +
                " | Emisión: " + fechaEmision +
                " | Emisor: " + emisorOriginal +
                " | Vencimiento: " + fechaVencimiento;
    }
}
