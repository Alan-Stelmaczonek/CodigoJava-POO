package mvc.dto;

public class ComparacionPreciosDTO {
    private String razonSocialProveedor;
    private String cuitProveedor;
    private float precioUnitario;
    private String unidadMedidad;

    public ComparacionPreciosDTO(String razonSocialProveedor, String cuitProveedor, float precioUnitario, String unidadMedidad) {
        this.razonSocialProveedor = razonSocialProveedor;
        this.cuitProveedor = cuitProveedor;
        this.precioUnitario = precioUnitario;
        this.unidadMedidad = unidadMedidad;
    }

    public String getRazonSocialProveedor() {
        return razonSocialProveedor;
    }

    public String getCuitProveedor() {
        return cuitProveedor;
    }

    public float getPrecioUnitario() {
        return precioUnitario;
    }

    public String getUnidadMedidad() {
        return unidadMedidad;
    }
}

