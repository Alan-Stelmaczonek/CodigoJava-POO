package mvc.view;

import mvc.controller.ConsultaController;
import mvc.controller.ProductoController;
import mvc.controller.ProveedorController;
import mvc.dto.ComparacionPreciosDTO;
import mvc.dto.ComprobanteDTO;
import mvc.dto.CuentaCorrienteDTO;
import mvc.dto.LineaLibroIVA;
import mvc.dto.OrdenPagoDTO;
import mvc.dto.RankingAcreedorDTO;
import mvc.model.clases.Factura;
import mvc.model.clases.Producto;
import mvc.model.clases.Proveedor;
import mvc.model.enums.TipoRetencion;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

public class ConsultaView extends JPanel {

    private final ConsultaController controller;

    public ConsultaView() {
        this.controller = ConsultaController.getInstance();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(crearPanelBotones(), BorderLayout.NORTH);
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));

        JButton btnCuentaCorriente = new JButton("Cuenta Corriente de Proveedor");
        JButton btnCompulsaPrecios = new JButton("Compulsa de Precios");
        JButton btnRanking = new JButton("Ranking de Acreedores");
        JButton btnRetenciones = new JButton("Total de Retenciones Emitidas");
        JButton btnLibroIVA = new JButton("Libro IVA Compras");
        JButton btnFacturasRecibidas = new JButton("Facturas Recibidas por Período");

        btnCuentaCorriente.addActionListener(e -> mostrarCuentaCorriente());
        btnCompulsaPrecios.addActionListener(e -> mostrarCompulsaPrecios());
        btnRanking.addActionListener(e -> mostrarRankingAcreedores());
        btnRetenciones.addActionListener(e -> mostrarTotalRetenciones());
        btnLibroIVA.addActionListener(e -> mostrarLibroIVA());
        btnFacturasRecibidas.addActionListener(e -> mostrarFacturasRecibidas());

        panel.add(btnCuentaCorriente);
        panel.add(btnCompulsaPrecios);
        panel.add(btnRanking);
        panel.add(btnRetenciones);
        panel.add(btnLibroIVA);
        panel.add(btnFacturasRecibidas);

        return panel;
    }

    private JFrame getVentanaPadre() {
        return (JFrame) SwingUtilities.getWindowAncestor(this);
    }

    private Proveedor seleccionarProveedor() {
        List<Proveedor> proveedores = ProveedorController.getInstance().getProveedores();
        if (proveedores.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No hay proveedores cargados.",
                    "Sin proveedores", JOptionPane.WARNING_MESSAGE);
            return null;
        }

        String[] opciones = new String[proveedores.size()];
        for (int i = 0; i < proveedores.size(); i++) {
            opciones[i] = proveedores.get(i).getCuit() + " - " + proveedores.get(i).getRazonSocial();
        }

        String seleccion = (String) JOptionPane.showInputDialog(getVentanaPadre(), "Seleccione el proveedor:",
                "Proveedor", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        if (seleccion == null) return null;

        int index = java.util.Arrays.asList(opciones).indexOf(seleccion);
        return proveedores.get(index);
    }

    private void mostrarTabla(String titulo, String[] columnas, Object[][] filas) {
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        for (Object[] fila : filas) {
            modelo.addRow(fila);
        }

        JTable tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setPreferredSize(new Dimension(650, 300));

        JOptionPane.showMessageDialog(getVentanaPadre(), scroll, titulo, JOptionPane.PLAIN_MESSAGE);
    }

    private void mostrarCuentaCorriente() {
        Proveedor proveedor = seleccionarProveedor();
        if (proveedor == null) return;

        CuentaCorrienteDTO cuenta = controller.obtenerCuentaCorriente(proveedor);

        StringBuilder mensaje = new StringBuilder();
        mensaje.append("Proveedor: ").append(proveedor.getRazonSocial()).append("\n");
        mensaje.append("Deuda Total: $").append(cuenta.getDeudaTotal()).append("\n\n");

        mensaje.append("Documentos recibidos:\n");
        for (ComprobanteDTO c : cuenta.getComprobantes()) {
            mensaje.append("  ").append(c.getTipo()).append(" #").append(c.getNumero())
                    .append(" - $").append(c.getTotal()).append(" - ").append(c.getEstado()).append("\n");
        }

        mensaje.append("\nDocumentos impagos:\n");
        for (ComprobanteDTO c : cuenta.getComprobantesImpagos()) {
            mensaje.append("  ").append(c.getTipo()).append(" #").append(c.getNumero())
                    .append(" - $").append(c.getTotal()).append("\n");
        }

        mensaje.append("\nHistorial de pagos:\n");
        for (OrdenPagoDTO op : cuenta.getOrdenesPago()) {
            mensaje.append("  OP #").append(op.getNumero()).append(" - ").append(op.getFecha())
                    .append(" - Pagado: $").append(op.getMontoAPagar()).append("\n");
        }

        JTextArea area = new JTextArea(mensaje.toString());
        area.setEditable(false);
        JScrollPane scroll = new JScrollPane(area);
        scroll.setPreferredSize(new Dimension(500, 350));
        JOptionPane.showMessageDialog(getVentanaPadre(), scroll, "Cuenta Corriente", JOptionPane.PLAIN_MESSAGE);
    }

    private void mostrarCompulsaPrecios() {
        List<Producto> productos = ProductoController.getInstance().getProductos();
        if (productos.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No hay productos cargados.",
                    "Sin productos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] opciones = new String[productos.size()];
        for (int i = 0; i < productos.size(); i++) {
            opciones[i] = productos.get(i).getDescripcion() + " (" + productos.get(i).getRubro().getDescripcion() + ")";
        }

        String seleccion = (String) JOptionPane.showInputDialog(getVentanaPadre(), "Seleccione el producto:",
                "Compulsa de Precios", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        if (seleccion == null) return;

        int index = java.util.Arrays.asList(opciones).indexOf(seleccion);
        Producto producto = productos.get(index);

        List<ComparacionPreciosDTO> comparacion = controller.compararPrecios(producto);
        if (comparacion.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "El producto no tiene proveedores asociados.",
                    "Sin datos", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Object[][] filas = new Object[comparacion.size()][];
        for (int i = 0; i < comparacion.size(); i++) {
            ComparacionPreciosDTO c = comparacion.get(i);
            filas[i] = new Object[]{c.getRazonSocialProveedor(), c.getCuitProveedor(), c.getPrecioUnitario(), c.getUnidadMedidad()};
        }

        mostrarTabla("Compulsa de Precios - " + producto.getDescripcion(),
                new String[]{"Proveedor", "CUIT", "Precio Unitario", "Unidad"}, filas);
    }

    private void mostrarRankingAcreedores() {
        List<RankingAcreedorDTO> ranking = controller.obtenerRankingAcreedores();
        if (ranking.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No hay proveedores con deuda registrada.",
                    "Sin datos", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Object[][] filas = new Object[ranking.size()][];
        for (int i = 0; i < ranking.size(); i++) {
            RankingAcreedorDTO r = ranking.get(i);
            filas[i] = new Object[]{r.getPosicion(), r.getRazonSocial(), r.getCuit(), r.getDeudaTotal()};
        }

        mostrarTabla("Ranking de Acreedores", new String[]{"Posición", "Razón Social", "CUIT", "Deuda Total"}, filas);
    }

    private void mostrarTotalRetenciones() {
        Map<TipoRetencion, Float> totales = controller.obtenerTotalRetencionesEmitidas();

        Object[][] filas = new Object[totales.size()][];
        int i = 0;
        for (Map.Entry<TipoRetencion, Float> entry : totales.entrySet()) {
            filas[i++] = new Object[]{entry.getKey(), entry.getValue()};
        }

        mostrarTabla("Total de Retenciones Emitidas", new String[]{"Tipo de Impuesto", "Monto Retenido"}, filas);
    }

    private void mostrarLibroIVA() {
        String mesAnio = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese mes y año (MM/yyyy):");
        if (mesAnio == null || mesAnio.trim().isEmpty()) return;

        String error = UIHelper.validarMesAnio(mesAnio);
        if (error != null) {
            UIHelper.mostrarError(getVentanaPadre(), error);
            return;
        }

        List<LineaLibroIVA> libro = controller.obtenerLibroIVACompras(mesAnio);
        if (libro.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No hay documentos registrados para ese período.",
                    "Sin datos", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Object[][] filas = new Object[libro.size()][];
        for (int i = 0; i < libro.size(); i++) {
            LineaLibroIVA l = libro.get(i);
            filas[i] = new Object[]{l.getCuitProveedor(), l.getRazonSocial(), l.getFechaDocumento(), l.getTipoDocumento(),
                    l.getMontoIVA2_5(), l.getMontoIVA5(), l.getMontoIVA10_5(), l.getMontoIVA21(), l.getMontoIVA27(), l.getTotalDocumento()};
        }

        mostrarTabla("Libro IVA Compras - " + mesAnio,
                new String[]{"CUIT", "Proveedor", "Fecha", "Tipo", "IVA 2,5%", "IVA 5%", "IVA 10,5%", "IVA 21%", "IVA 27%", "Total"},
                filas);
    }

    private void mostrarFacturasRecibidas() {
        String desdeStr = JOptionPane.showInputDialog(getVentanaPadre(), "Fecha desde (dd/MM/yyyy):");
        if (desdeStr == null || desdeStr.trim().isEmpty()) return;

        String hastaStr = JOptionPane.showInputDialog(getVentanaPadre(), "Fecha hasta (dd/MM/yyyy):");
        if (hastaStr == null || hastaStr.trim().isEmpty()) return;

        String error = UIHelper.validarRangoFechas(desdeStr, hastaStr);
        if (error != null) {
            UIHelper.mostrarError(getVentanaPadre(), error);
            return;
        }

        int filtrarProveedor = JOptionPane.showConfirmDialog(getVentanaPadre(),
                "¿Filtrar por un proveedor en particular?", "Filtro opcional", JOptionPane.YES_NO_OPTION);
        Proveedor proveedor = null;
        if (filtrarProveedor == JOptionPane.YES_OPTION) {
            proveedor = seleccionarProveedor();
            if (proveedor == null) return;
        }

        try {
            java.util.Date desde = UIHelper.parsearFecha(desdeStr);
            java.util.Date hasta = UIHelper.parsearFecha(hastaStr);

            List<Factura> facturas = controller.obtenerFacturasRecibidas(desde, hasta, proveedor);
            if (facturas.isEmpty()) {
                JOptionPane.showMessageDialog(getVentanaPadre(), "No se encontraron facturas en ese período.",
                        "Sin datos", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            Object[][] filas = new Object[facturas.size()][];
            for (int i = 0; i < facturas.size(); i++) {
                Factura f = facturas.get(i);
                filas[i] = new Object[]{f.getNumero(), f.getFecha(), f.getProveedor().getRazonSocial(),
                        f.calcularTotal(), f.getEstado()};
            }

            mostrarTabla("Facturas Recibidas", new String[]{"Número", "Fecha", "Proveedor", "Total", "Estado"}, filas);
        } catch (Exception ex) {
            UIHelper.mostrarError(getVentanaPadre(), "Error al procesar las fechas.");
        }
    }
}
