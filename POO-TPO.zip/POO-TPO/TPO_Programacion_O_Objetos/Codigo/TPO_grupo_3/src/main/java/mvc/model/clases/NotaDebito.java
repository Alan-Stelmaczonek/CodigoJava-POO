package mvc.model.clases;

import mvc.model.enums.EstadoComprobante;

import java.util.Date;
import java.util.List;

public class NotaDebito extends Comprobante {
    private String descripcionMotivo;

    public NotaDebito(int numero, Date fecha, EstadoComprobante estado, List<LineaComprobante> lineas, Proveedor proveedor, String descripcionMotivo) {
        super(numero, fecha, estado, lineas, proveedor);
        this.descripcionMotivo = descripcionMotivo;
    }

    @Override
    public String getTipo() {
        return "Nota Debito";
    }

    @Override
    public float calcularTotal() {
        float total = 0;
        for (int i = 0; lineas.size() > i; i++) {
            total = total + lineas.get(i).getSubtotal() + lineas.get(i).getMontoIVA();
        }
        return total;
    }

    @Override
    public float getMontoParaCuentaCorriente() {
        return calcularTotal();
    }

    public String getDescripcionMotivo() {
        return descripcionMotivo;
    }

}
