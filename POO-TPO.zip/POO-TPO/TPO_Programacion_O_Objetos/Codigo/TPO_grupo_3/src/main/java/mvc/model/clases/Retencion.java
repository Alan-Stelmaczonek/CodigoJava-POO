package mvc.model.clases;

import mvc.model.enums.TipoRetencion;

public class Retencion {
    private TipoRetencion tipoImpuesto;
    private float porcentaje;
    private float monto;
    private float minimoNoImponible;

    public Retencion(TipoRetencion tipoImpuesto , float porcentaje, float monto, float minimoNoImponible) {
        this.tipoImpuesto = tipoImpuesto;
        this.porcentaje = porcentaje;
        this.monto = monto;
        this.minimoNoImponible = minimoNoImponible;
    }
    public float calcularMonto(float baseImponible) {
        if (correspondeRetener(baseImponible)) {
            return baseImponible * (porcentaje / 100);
        }
        return 0;
    }
    public boolean correspondeRetener(float baseImponible) {
        return baseImponible > minimoNoImponible;
    }
    public TipoRetencion getTipoImpuesto() { return tipoImpuesto; }
    public float getPorcentaje() { return porcentaje; }
    public float getMinimoNoImponible() { return minimoNoImponible; }
    public float getMonto() { return monto; }
}
