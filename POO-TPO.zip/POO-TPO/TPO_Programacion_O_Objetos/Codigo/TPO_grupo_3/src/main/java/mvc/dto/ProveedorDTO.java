package mvc.dto;

import mvc.model.enums.ResponsabilidadIVA;
import java.util.Date;

public class ProveedorDTO {
    private String cuit;
    private String razonSocial;
    private String nombreFantasia;
    private ResponsabilidadIVA responsabilidadIVA;
    private String direccion;
    private String telefono;
    private String email;
    private String nroIngresosBrutos;
    private Date fechaInicioActividades;
    private float limiteDeuda;
    private float deudaTotal;
    private int cantidadRubros;
    private int cantidadOrdenesPago;
    private int cantidadCertificados;

    public ProveedorDTO(String cuit, String razonSocial, String nombreFantasia, ResponsabilidadIVA responsabilidadIVA,
                        String direccion, String telefono, String email, String nroIngresosBrutos,
                        Date fechaInicioActividades, float limiteDeuda, float deudaTotal,
                        int cantidadRubros, int cantidadOrdenesPago, int cantidadCertificados) {
        this.cuit = cuit;
        this.razonSocial = razonSocial;
        this.nombreFantasia = nombreFantasia;
        this.responsabilidadIVA = responsabilidadIVA;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.nroIngresosBrutos = nroIngresosBrutos;
        this.fechaInicioActividades = fechaInicioActividades;
        this.limiteDeuda = limiteDeuda;
        this.deudaTotal = deudaTotal;
        this.cantidadRubros = cantidadRubros;
        this.cantidadOrdenesPago = cantidadOrdenesPago;
        this.cantidadCertificados = cantidadCertificados;
    }

    public String getCuit() { return cuit; }
    public String getRazonSocial() { return razonSocial; }
    public String getNombreFantasia() { return nombreFantasia; }
    public ResponsabilidadIVA getResponsabilidadIVA() { return responsabilidadIVA; }
    public String getDireccion() { return direccion; }
    public String getTelefono() { return telefono; }
    public String getEmail() { return email; }
    public String getNroIngresosBrutos() { return nroIngresosBrutos; }
    public Date getFechaInicioActividades() { return fechaInicioActividades; }
    public float getLimiteDeuda() { return limiteDeuda; }
    public float getDeudaTotal() { return deudaTotal; }
    public int getCantidadRubros() { return cantidadRubros; }
    public int getCantidadOrdenesPago() { return cantidadOrdenesPago; }
    public int getCantidadCertificados() { return cantidadCertificados; }

    @Override
    public String toString() {
        return "Proveedor: " + razonSocial + " | CUIT: " + cuit;
    }

}