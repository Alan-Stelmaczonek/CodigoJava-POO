package mvc.model.clases;

public abstract class  MedioPago {
    float monto;


    public MedioPago(float monto) {
        this.monto = monto;
    }
    public float getMonto() {
        return monto;
    }
    public abstract String getDescripcion();
    public abstract String getDetalle();
}
