package mvc.controller;

import mvc.dto.ComparacionPreciosDTO;
import mvc.dto.ComprobanteDTO;
import mvc.dto.CuentaCorrienteDTO;
import mvc.dto.LineaLibroIVA;
import mvc.dto.OrdenPagoDTO;
import mvc.dto.RankingAcreedorDTO;
import mvc.model.clases.Comprobante;
import mvc.model.clases.Factura;
import mvc.model.clases.OrdenPago;
import mvc.model.clases.Producto;
import mvc.model.clases.ProductoProveedor;
import mvc.model.clases.Proveedor;
import mvc.model.clases.Retencion;
import mvc.model.enums.TipoIVA;
import mvc.model.enums.TipoRetencion;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class ConsultaController {

    private static ConsultaController INSTANCE = null;

    private ConsultaController() {
    }

    public static synchronized ConsultaController getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ConsultaController();
        }
        return INSTANCE;
    }

    public CuentaCorrienteDTO obtenerCuentaCorriente(Proveedor proveedor) {
        List<ComprobanteDTO> comprobantes = new ArrayList<>();
        for (Comprobante c : proveedor.getComprobantes()) {
            comprobantes.add(toComprobanteDTO(c));
        }

        List<ComprobanteDTO> comprobantesImpagos = new ArrayList<>();
        for (Comprobante c : proveedor.getComprobantesImpagos()) {
            comprobantesImpagos.add(toComprobanteDTO(c));
        }

        List<OrdenPagoDTO> ordenesPago = new ArrayList<>();
        for (OrdenPago op : proveedor.getOrdenesDePago()) {
            ordenesPago.add(toOrdenPagoDTO(op, proveedor));
        }

        return new CuentaCorrienteDTO(proveedor.getDeudaTotal(), comprobantes, comprobantesImpagos, ordenesPago);
    }

    public List<ComparacionPreciosDTO> compararPrecios(Producto producto) {
        List<ComparacionPreciosDTO> comparacion = new ArrayList<>();
        for (ProductoProveedor pp : producto.getProveedores()) {
            Proveedor proveedor = pp.getProveedor();
            comparacion.add(new ComparacionPreciosDTO(proveedor.getRazonSocial(), proveedor.getCuit(),
                    pp.getPrecioUnitario(), producto.getUnidadMedidad()));
        }
        return comparacion;
    }

    public List<LineaLibroIVA> obtenerLibroIVACompras(String mesAnio) {
        List<LineaLibroIVA> lineas = new ArrayList<>();
        SimpleDateFormat sdfMesAnio = new SimpleDateFormat("MM/yyyy");

        for (Proveedor proveedor : ProveedorController.getInstance().getProveedores()) {
            for (Comprobante c : proveedor.getComprobantes()) {
                if (sdfMesAnio.format(c.getFecha()).equals(mesAnio)) {
                    lineas.add(toLineaLibroIVA(c, proveedor));
                }
            }
        }
        return lineas;
    }

    public List<RankingAcreedorDTO> obtenerRankingAcreedores() {
        List<Proveedor> proveedores = new ArrayList<>(ProveedorController.getInstance().getProveedores());
        proveedores.sort(Comparator.comparing(Proveedor::getDeudaTotal).reversed());

        List<RankingAcreedorDTO> ranking = new ArrayList<>();
        int posicion = 1;
        for (Proveedor proveedor : proveedores) {
            if (proveedor.getDeudaTotal() <= 0) {
                continue;
            }
            ranking.add(new RankingAcreedorDTO(posicion, proveedor.getRazonSocial(), proveedor.getCuit(), proveedor.getDeudaTotal()));
            posicion++;
        }
        return ranking;
    }

    public Map<TipoRetencion, Float> obtenerTotalRetencionesEmitidas() {
        Map<TipoRetencion, Float> totales = new EnumMap<>(TipoRetencion.class);
        for (TipoRetencion tipo : TipoRetencion.values()) {
            totales.put(tipo, 0f);
        }

        for (Proveedor proveedor : ProveedorController.getInstance().getProveedores()) {
            for (OrdenPago ordenPago : proveedor.getOrdenesDePago()) {
                for (Retencion retencion : ordenPago.getRetenciones()) {
                    float acumulado = totales.get(retencion.getTipoImpuesto());
                    totales.put(retencion.getTipoImpuesto(), acumulado + retencion.getMonto());
                }
            }
        }
        return totales;
    }

    public List<Factura> obtenerFacturasRecibidas(Date desde, Date hasta, Proveedor proveedor) {
        List<Factura> facturas = new ArrayList<>();
        List<Proveedor> proveedores = proveedor != null
                ? List.of(proveedor)
                : ProveedorController.getInstance().getProveedores();

        for (Proveedor p : proveedores) {
            for (Comprobante c : p.getComprobantes()) {
                if (c instanceof Factura && !c.getFecha().before(desde) && !c.getFecha().after(hasta)) {
                    facturas.add((Factura) c);
                }
            }
        }
        return facturas;
    }

    private ComprobanteDTO toComprobanteDTO(Comprobante c) {
        return new ComprobanteDTO(c.getNumero(), c.getTipo(), c.getFecha(),
                c.getProveedor().getRazonSocial(), c.calcularTotal(), c.getEstado());
    }

    private OrdenPagoDTO toOrdenPagoDTO(OrdenPago op, Proveedor proveedor) {
        return new OrdenPagoDTO(op.getNumero(), op.getFecha(), proveedor.getRazonSocial(),
                op.getTotalACancelar(), op.calcularTotalRetenciones(), op.calcularMontoAPagar());
    }

    private LineaLibroIVA toLineaLibroIVA(Comprobante c, Proveedor proveedor) {
        float montoIVA2_5 = 0, montoIVA5 = 0, montoIVA10_5 = 0, montoIVA21 = 0, montoIVA27 = 0;

        for (var linea : c.getLineas()) {
            float montoIVA = linea.getMontoIVA();
            TipoIVA tipoIVA = linea.getTipoIVA();
            switch (tipoIVA) {
                case IVA_2_5 -> montoIVA2_5 += montoIVA;
                case IVA_5 -> montoIVA5 += montoIVA;
                case IVA_10_5 -> montoIVA10_5 += montoIVA;
                case IVA_21 -> montoIVA21 += montoIVA;
                case IVA_27 -> montoIVA27 += montoIVA;
            }
        }

        return new LineaLibroIVA(proveedor.getCuit(), proveedor.getRazonSocial(), c.getFecha(), c.getTipo(),
                montoIVA2_5, montoIVA5, montoIVA10_5, montoIVA21, montoIVA27, c.calcularTotal());
    }
}
