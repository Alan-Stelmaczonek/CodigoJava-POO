package mvc.controller;

import mvc.dto.ProductoDTO;
import mvc.model.clases.Producto;
import mvc.model.clases.ProductoProveedor;
import mvc.model.clases.Proveedor;
import mvc.model.clases.Rubro;
import mvc.model.enums.TipoIVA;

import java.util.ArrayList;
import java.util.List;

public class ProductoController {

    private static ProductoController INSTANCE = null;
    private List<Producto> productos = new ArrayList<>();
    private List<Rubro> rubros = new ArrayList<>();
    private int contadorRubro;

    private ProductoController() {
        productos = new ArrayList<>();
        rubros = new ArrayList<>();
        this.contadorRubro = 0;
    }

    public static synchronized ProductoController getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ProductoController();
        }
        return INSTANCE;
    }

    public Producto altaProducto(int id, String descripcion, TipoIVA tipoIVA, String unidadMedidad, Rubro rubro) {
        Producto producto = new Producto(id, descripcion, tipoIVA, unidadMedidad, rubro);
        productos.add(producto);
        return producto;
    }

    public Rubro altaRubro(String descripcion) {
        contadorRubro++;
        Rubro rubro = new Rubro(contadorRubro, descripcion);
        rubros.add(rubro);
        return rubro;
    }

    public boolean modificarRubro(int id, String descripcion) {
        for (Rubro rubro : rubros) {
            if (rubro.getId() == id) {
                rubro.setDescripcion(descripcion);
                return true;
            }
        }
        return false;
    }

    public List<ProductoDTO> listarProductos() {
        List<ProductoDTO> lista = new ArrayList<>();
        for (Producto producto : productos) {
            lista.add(toDTO(producto));
        }
        return lista;
    }

    public ProductoProveedor asociarProductoProveedor(Producto  producto, Proveedor proveedor, float precioUnitario) {
        ProductoProveedor productoProveedor = new ProductoProveedor(producto, proveedor, precioUnitario);
        producto.agregarProveedor(productoProveedor);
        return productoProveedor;
    }

    public List<Producto> getProductos() { return productos; }
    public List<Rubro> getRubros() { return rubros; }

    private ProductoDTO toDTO(Producto producto) {
        return new ProductoDTO(producto.getId(), producto.getDescripcion(),
                producto.getRubro().getDescripcion(), producto.getProveedores().size());
    }
}