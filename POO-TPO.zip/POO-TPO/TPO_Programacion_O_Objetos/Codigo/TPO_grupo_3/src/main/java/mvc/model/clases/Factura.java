package mvc.model.clases;

import mvc.model.enums.EstadoComprobante;

import java.util.Date;
import java.util.List;

public class Factura extends Comprobante {

    private OrdenCompra ordenCompra;

    public Factura(int numero, Date fecha, EstadoComprobante estado, List<LineaComprobante> lineas, Proveedor proveedor, OrdenCompra ordenCompra) {
        super(numero, fecha, estado, lineas, proveedor);
        this.ordenCompra = ordenCompra;
    }

    @Override
    public String getTipo() {
        return "Factura";
    }

    @Override
    public float calcularTotal() {
        float total = 0;
        for (int i = 0; lineas.size() > i; i++) {
            total = total + lineas.get(i).getSubtotal() + lineas.get(i).getMontoIVA();
        }
        return total;
    }

    // Reduce lo que le debe al proveedor
    // Le hacés una Orden de Compra al proveedor: "quiero 10 cajas de tornillos a $300 cada una".
    // El proveedor acepta y te manda las cajas. Después te manda la Factura por $3000.
    // Entonces la deuda sube
    @Override
    public float getMontoParaCuentaCorriente() {
        return calcularTotal();
    }

    public OrdenCompra getOrdenCompra() {
        return ordenCompra;
    }

    public boolean validarPreciosContraOC(OrdenCompra ordenCompra) {
        if (lineas.size() != ordenCompra.getLineas().size()) {
            return false;
        }

        for (int i = 0; i < lineas.size(); i++) {
            if (lineas.get(i).getPrecioUnitario() != ordenCompra.getLineas().get(i).getProductoProveedor().getPrecioUnitario()) {
                return false;
            }
        }
        return true;
    }
}

