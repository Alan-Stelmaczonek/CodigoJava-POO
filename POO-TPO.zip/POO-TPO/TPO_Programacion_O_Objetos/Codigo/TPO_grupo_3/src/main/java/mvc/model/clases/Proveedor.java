package mvc.model.clases;

import mvc.model.enums.ResponsabilidadIVA;
import mvc.model.enums.EstadoComprobante;
import mvc.model.enums.TipoRetencion;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Proveedor {
    private String cuit;
    private ResponsabilidadIVA responsabilidadIVA;
    private String nombreFantasia;
    private String razonSocial;
    private String direccion;
    private String telefono;
    private String email;
    private String nroIngresosBrutos;
    private Date fechaInicioActividades;
    private float limiteDeuda;
    private List<OrdenPago> ordenesDePago = new ArrayList<>();
    private List<Comprobante> comprobantes = new ArrayList<>();
    private List<CertificadoNoRetencion> certificados = new ArrayList<>();
    private List<Rubro> rubros = new ArrayList<>();

    public Proveedor(String cuit, ResponsabilidadIVA responsabilidadIVA, String nombreFantasia, String razonSocial, String direccion, String telefono, String email, String nroIngresosBrutos, Date fechaInicioActividades, float limiteDeuda) {
        this.cuit = cuit;
        this.responsabilidadIVA = responsabilidadIVA;
        this.nombreFantasia = nombreFantasia;
        this.razonSocial = razonSocial;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.nroIngresosBrutos = nroIngresosBrutos;
        this.fechaInicioActividades = fechaInicioActividades;
        this.limiteDeuda = limiteDeuda;
    }

    public String getCuit() {
        return cuit;
    }

    public float getDeudaTotal() {
        float totalAPagar = 0;
        for (Comprobante comprobante : comprobantes) {
            if (comprobante.estaPago() == false) {
                totalAPagar += comprobante.getMontoParaCuentaCorriente();
            }
        }
        return totalAPagar;
    }

    public boolean superaLimiteDeuda (){
        return superaLimiteDeuda(0);
    }

    public boolean superaLimiteDeuda (float montoAdicional){
        return (getDeudaTotal() + montoAdicional) > limiteDeuda;
    }
    public void agregarComprobante (Comprobante comprobante){
        comprobantes.add(comprobante);
    }
    public void agregarOrdenPago (OrdenPago ordenPago){
        ordenesDePago.add(ordenPago);
    }
    public List<Comprobante> getComprobantesImpagos() {
        List<Comprobante> comprobantesImpagos = new ArrayList<>();
        for (Comprobante comprobante : comprobantes) {
            if (comprobante.getEstado() == EstadoComprobante.IMPAGO) {
                comprobantesImpagos.add(comprobante);
            }
        }
        return comprobantesImpagos;
    }
    public boolean tieneCertificadoVigente(TipoRetencion tipoImpuesto) {
        for (CertificadoNoRetencion certificado : certificados) {
            if (certificado.getTipoImpuesto() == tipoImpuesto && certificado.estaVigente()) {
                return true;
            }
        }
        return false;
    }
    public void agregarRubro (Rubro rubro){
        rubros.add(rubro);
    }
    public void agregarCertificado (CertificadoNoRetencion certificado){
        certificados.add(certificado);
    }

    public ResponsabilidadIVA getResponsabilidadIVA() {
        return responsabilidadIVA;
    }
    public String getNombreFantasia() {return nombreFantasia;}
    public String getRazonSocial() {
        return razonSocial;
    }
    public String getDireccion() {
        return direccion;
    }
    public String getTelefono() {
        return telefono;
    }
    public String getEmail() {
        return email;
    }
    public String getNroIngresosBrutos() {
        return nroIngresosBrutos;
    }
    public Date getFechaInicioActividades() {
        return fechaInicioActividades;
    }
    public float getLimiteDeuda() {
        return limiteDeuda;
    }
    public List<OrdenPago> getOrdenesDePago() {
        return new ArrayList<>(ordenesDePago);
    }
    public List<Comprobante> getComprobantes() {
        return new ArrayList<>(comprobantes);
    }
    public List<CertificadoNoRetencion> getCertificados() {
        return new ArrayList<>(certificados);
    }
    public List<Rubro> getRubros() {
        return new ArrayList<>(rubros);
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }
    public void setResponsabilidadIVA(ResponsabilidadIVA responsabilidadIVA) {
        this.responsabilidadIVA = responsabilidadIVA;
    }
    public void setNombreFantasia(String nombreFantasia) {
        this.nombreFantasia = nombreFantasia;
    }
    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setNroIngresosBrutos(String nroIngresosBrutos) {
        this.nroIngresosBrutos = nroIngresosBrutos;
    }
    public void setFechaInicioActividades(Date fechaInicioActividades) {
        this.fechaInicioActividades = fechaInicioActividades;
    }
    public void setLimiteDeuda(float limiteDeuda) {
        this.limiteDeuda = limiteDeuda;
    }
    public void setOrdenesDePago(List<OrdenPago> ordenesDePago) {
        this.ordenesDePago = ordenesDePago;
    }
    public void setComprobantes(List<Comprobante> comprobantes) {
        this.comprobantes = comprobantes;
    }
    public void setCertificados(List<CertificadoNoRetencion> certificados) {
        this.certificados = certificados;
    }
    public void setRubros(List<Rubro> rubros) {
        this.rubros = rubros;
    }

    @Override
    public String toString() {
        return "Proveedor{" +
                "cuit='" + cuit + '\'' +
                ", responsabilidadIVA=" + responsabilidadIVA +
                ", nombreFantasia='" + nombreFantasia + '\'' +
                '}';
    }
}
