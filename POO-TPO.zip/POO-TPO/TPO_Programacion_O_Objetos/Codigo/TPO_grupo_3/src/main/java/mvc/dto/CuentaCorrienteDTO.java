package mvc.dto;

import mvc.model.clases.Comprobante;
import mvc.model.clases.OrdenPago;

import java.util.ArrayList;
import java.util.List;

public class CuentaCorrienteDTO {
    private float deudaTotal;
    private List<ComprobanteDTO> comprobantes = new ArrayList<>();
    private List<ComprobanteDTO> comprobantesImpagos = new ArrayList<>();
    private List<OrdenPagoDTO> ordenesPago = new ArrayList<>();

    public CuentaCorrienteDTO(float deudaTotal, List<ComprobanteDTO> comprobantes, List<ComprobanteDTO> comprobantesImpagos, List<OrdenPagoDTO> ordenesPago) {
        this.deudaTotal = deudaTotal;
        this.comprobantes = comprobantes;
        this.comprobantesImpagos = comprobantesImpagos;
        this.ordenesPago = ordenesPago;
    }

    public float getDeudaTotal() {
        return deudaTotal;
    }
    public List<ComprobanteDTO> getComprobantes() {
        return comprobantes;
    }
    public List<ComprobanteDTO> getComprobantesImpagos() {
        return comprobantesImpagos;
    }
    public List<OrdenPagoDTO> getOrdenesPago() {
        return ordenesPago;
    }
}
