package mvc.dto;

public class RankingAcreedorDTO {
    private int posicion;
    private String razonSocial;
    private String cuit;
    private float deudaTotal;

    public RankingAcreedorDTO(int posicion, String razonSocial, String cuit, float deudaTotal) {
        this.posicion = posicion;
        this.razonSocial = razonSocial;
        this.cuit = cuit;
        this.deudaTotal = deudaTotal;
    }

    public int getPosicion() {
        return posicion;
    }
    public String getRazonSocial() {
        return razonSocial;
    }
    public String getCuit() {
        return cuit;
    }
    public float getDeudaTotal() {
        return deudaTotal;
    }
}
