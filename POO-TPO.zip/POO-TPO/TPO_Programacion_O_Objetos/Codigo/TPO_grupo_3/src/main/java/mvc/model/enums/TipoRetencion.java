package mvc.model.enums;

public enum TipoRetencion {
    IVA ,
    IIBB ,
    GANANCIAS
}
