package mvc.view;

import mvc.controller.OrdenPagoController;
import mvc.controller.ProveedorController;
import mvc.model.clases.ChequeDeTerceros;
import mvc.model.clases.ChequePropio;
import mvc.model.clases.Comprobante;
import mvc.model.clases.Efectivo;
import mvc.model.clases.MedioPago;
import mvc.model.clases.Proveedor;
import mvc.model.clases.Transferencia;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrdenPagoView extends JPanel {

    private OrdenPagoController controller;
    private JTable tablaOrdenesPago;
    private DefaultTableModel modeloTabla;

    public OrdenPagoView() {
        this.controller = OrdenPagoController.getInstance();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(crearPanelBotones(), BorderLayout.NORTH);
        add(crearPanelTabla(), BorderLayout.CENTER);

        actualizarTabla();
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        JButton btnEmitir = new JButton("Emitir Orden de Pago");
        JButton btnListarPorFecha = new JButton("Listar por Fecha");
        JButton btnActualizar = new JButton("Actualizar Listado");

        btnEmitir.addActionListener(e -> mostrarDialogoEmitir());
        btnListarPorFecha.addActionListener(e -> listarPorFecha());
        btnActualizar.addActionListener(e -> actualizarTabla());

        panel.add(btnEmitir);
        panel.add(btnListarPorFecha);
        panel.add(btnActualizar);

        return panel;
    }

    private JScrollPane crearPanelTabla() {
        String[] columnas = {"Número", "Fecha", "Total a Cancelar", "Retenciones", "Monto a Pagar"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaOrdenesPago = new JTable(modeloTabla);
        return new JScrollPane(tablaOrdenesPago);
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);
        List<mvc.model.clases.OrdenPago> ordenes = controller.getOrdenesPago();
        for (mvc.model.clases.OrdenPago op : ordenes) {
            modeloTabla.addRow(new Object[]{
                    op.getNumero(),
                    op.getFecha(),
                    op.getTotalACancelar(),
                    op.calcularTotalRetenciones(),
                    op.calcularMontoAPagar()
            });
        }
    }

    private JFrame getVentanaPadre() {
        return (JFrame) SwingUtilities.getWindowAncestor(this);
    }

    private void mostrarDialogoEmitir() {
        List<Proveedor> proveedores = ProveedorController.getInstance().getProveedores();
        if (proveedores.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No hay proveedores cargados.",
                    "Sin proveedores", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] opcionesProveedor = new String[proveedores.size()];
        for (int i = 0; i < proveedores.size(); i++) {
            opcionesProveedor[i] = proveedores.get(i).getCuit() + " - " + proveedores.get(i).getRazonSocial();
        }

        String selProv = (String) JOptionPane.showInputDialog(getVentanaPadre(), "Seleccione el proveedor:",
                "Proveedor", JOptionPane.QUESTION_MESSAGE, null, opcionesProveedor, opcionesProveedor[0]);
        if (selProv == null) return;

        int indexProv = java.util.Arrays.asList(opcionesProveedor).indexOf(selProv);
        Proveedor proveedor = proveedores.get(indexProv);

        List<Comprobante> impagos = proveedor.getComprobantesImpagos();
        if (impagos.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "El proveedor no tiene comprobantes impagos.",
                    "Sin deuda", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String[] opcionesComp = new String[impagos.size()];
        for (int i = 0; i < impagos.size(); i++) {
            Comprobante c = impagos.get(i);
            opcionesComp[i] = c.getTipo() + " #" + c.getNumero() + " - $" + c.getMontoParaCuentaCorriente();
        }

        JList<String> listaComprobantes = new JList<>(opcionesComp);
        listaComprobantes.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollComp = new JScrollPane(listaComprobantes);
        scrollComp.setPreferredSize(new Dimension(350, 150));

        int resultadoComp = JOptionPane.showConfirmDialog(getVentanaPadre(), scrollComp,
                "Seleccione comprobantes a pagar (Ctrl+click para varios)", JOptionPane.OK_CANCEL_OPTION);
        if (resultadoComp != JOptionPane.OK_OPTION) return;

        int[] indicesSeleccionados = listaComprobantes.getSelectedIndices();
        if (indicesSeleccionados.length == 0) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "Debe seleccionar al menos un comprobante.",
                    "Sin selección", JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<Comprobante> comprobantesSeleccionados = new ArrayList<>();
        for (int idx : indicesSeleccionados) {
            comprobantesSeleccionados.add(impagos.get(idx));
        }

        List<MedioPago> mediosPago = cargarMediosPago();
        if (mediosPago.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "Debe agregar al menos un medio de pago.",
                    "Sin medios de pago", JOptionPane.WARNING_MESSAGE);
            return;
        }

        controller.emitirOrdenPago(proveedor, comprobantesSeleccionados, mediosPago);
        JOptionPane.showMessageDialog(getVentanaPadre(), "Orden de Pago emitida correctamente.");
        actualizarTabla();
    }

    private List<MedioPago> cargarMediosPago() {
        List<MedioPago> medios = new ArrayList<>();
        boolean agregarMas = true;

        while (agregarMas) {
            String[] opciones = {"Efectivo", "Transferencia", "Cheque Propio", "Cheque de Terceros"};
            String tipo = (String) JOptionPane.showInputDialog(getVentanaPadre(),
                    "Seleccione el tipo de medio de pago:", "Medio de Pago",
                    JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
            if (tipo == null) break;

            String montoStr = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el monto:");
            if (montoStr == null) break;

            String error = UIHelper.validarFloatPositivo(montoStr, "Monto");
            if (error != null) {
                UIHelper.mostrarError(getVentanaPadre(), error);
                continue;
            }

            float monto = Float.parseFloat(montoStr);

            MedioPago medioPago = switch (tipo) {
                case "Efectivo" -> new Efectivo(monto);
                case "Transferencia" -> cargarTransferencia(monto);
                case "Cheque Propio" -> cargarCheque(monto, false);
                default -> cargarCheque(monto, true);
            };

            if (medioPago == null) {
                continue;
            }
            medios.add(medioPago);

            int otraMas = JOptionPane.showConfirmDialog(getVentanaPadre(),
                    "¿Agregar otro medio de pago?", "Continuar", JOptionPane.YES_NO_OPTION);
            agregarMas = (otraMas == JOptionPane.YES_OPTION);
        }

        return medios;
    }

    private MedioPago cargarTransferencia(float monto) {
        while (true) {
            String cbu = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el CBU destino (22 dígitos):");
            if (cbu == null) return null;

            String error = UIHelper.validarCBU(cbu);
            if (error != null) {
                UIHelper.mostrarError(getVentanaPadre(), error);
                continue;
            }

            return new Transferencia(cbu, new Date(), monto);
        }
    }

    private MedioPago cargarCheque(float monto, boolean deTerceros) {
        while (true) {
            String fechaEmisionStr = JOptionPane.showInputDialog(getVentanaPadre(), "Fecha de Emisión (dd/MM/yyyy):");
            if (fechaEmisionStr == null) return null;

            String fechaVencimientoStr = JOptionPane.showInputDialog(getVentanaPadre(), "Fecha de Vencimiento (dd/MM/yyyy):");
            if (fechaVencimientoStr == null) return null;

            String error = UIHelper.validarRangoFechas(fechaEmisionStr, fechaVencimientoStr);
            if (error != null) {
                UIHelper.mostrarError(getVentanaPadre(), error);
                continue;
            }

            String firmante = JOptionPane.showInputDialog(getVentanaPadre(), "Nombre del Firmante:");
            if (firmante == null) return null;

            error = UIHelper.validarNoVacio(firmante, "El nombre del firmante");
            if (error != null) {
                UIHelper.mostrarError(getVentanaPadre(), error);
                continue;
            }

            try {
                Date fechaEmision = UIHelper.parsearFecha(fechaEmisionStr);
                Date fechaVencimiento = UIHelper.parsearFecha(fechaVencimientoStr);

                if (!deTerceros) {
                    return new ChequePropio(monto, fechaEmision, fechaVencimiento, firmante);
                }

                String emisorOriginal = JOptionPane.showInputDialog(getVentanaPadre(), "Nombre del Emisor Original del cheque:");
                if (emisorOriginal == null) return null;

                error = UIHelper.validarNoVacio(emisorOriginal, "El emisor original");
                if (error != null) {
                    UIHelper.mostrarError(getVentanaPadre(), error);
                    continue;
                }

                return new ChequeDeTerceros(monto, fechaEmision, fechaVencimiento, firmante, emisorOriginal);
            } catch (Exception ex) {
                UIHelper.mostrarError(getVentanaPadre(), "Error al procesar las fechas.");
            }
        }
    }

    private void listarPorFecha() {
        JPanel panelFechas = new JPanel(new GridLayout(2, 2, 5, 5));
        JTextField txtDesde = new JTextField();
        JTextField txtHasta = new JTextField();
        panelFechas.add(new JLabel("Desde (dd/MM/yyyy):"));
        panelFechas.add(txtDesde);
        panelFechas.add(new JLabel("Hasta (dd/MM/yyyy):"));
        panelFechas.add(txtHasta);

        int resultado = JOptionPane.showConfirmDialog(getVentanaPadre(), panelFechas,
                "Filtrar por fecha", JOptionPane.OK_CANCEL_OPTION);
        if (resultado != JOptionPane.OK_OPTION) return;

        String error = UIHelper.validarRangoFechas(txtDesde.getText(), txtHasta.getText());
        if (error != null) {
            UIHelper.mostrarError(getVentanaPadre(), error);
            return;
        }

        try {
            Date desde = UIHelper.parsearFecha(txtDesde.getText());
            Date hasta = UIHelper.parsearFecha(txtHasta.getText());

            List<mvc.model.clases.OrdenPago> filtradas = controller.obtenerOrdenesPagoEmitidas(desde, hasta);

            modeloTabla.setRowCount(0);
            for (mvc.model.clases.OrdenPago op : filtradas) {
                modeloTabla.addRow(new Object[]{
                        op.getNumero(),
                        op.getFecha(),
                        op.getTotalACancelar(),
                        op.calcularTotalRetenciones(),
                        op.calcularMontoAPagar()
                });
            }

            JOptionPane.showMessageDialog(getVentanaPadre(),
                    "Se encontraron " + filtradas.size() + " órdenes de pago en el período.");
        } catch (Exception ex) {
            UIHelper.mostrarError(getVentanaPadre(), "Error al procesar las fechas.");
        }
    }
}
