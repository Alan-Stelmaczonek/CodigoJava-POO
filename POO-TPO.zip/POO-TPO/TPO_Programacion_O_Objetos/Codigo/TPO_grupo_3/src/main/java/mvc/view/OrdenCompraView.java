package mvc.view;

import mvc.controller.OrdenCompraController;
import mvc.controller.ProductoController;
import mvc.controller.ProveedorController;
import mvc.controller.UsuarioController;
import mvc.dto.OrdenCompraDTO;
import mvc.model.clases.LineaOrdenCompra;
import mvc.model.clases.Producto;
import mvc.model.clases.ProductoProveedor;
import mvc.model.clases.Proveedor;
import mvc.model.clases.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class OrdenCompraView extends JPanel {

    private OrdenCompraController controller;
    private JTable tablaOrdenes;
    private DefaultTableModel modeloTabla;

    public OrdenCompraView() {
        this.controller = OrdenCompraController.getInstance();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(crearPanelBotones(), BorderLayout.NORTH);
        add(crearPanelTabla(), BorderLayout.CENTER);

        actualizarTabla();
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        JButton btnGenerar = new JButton("Generar Orden de Compra");
        JButton btnAprobar = new JButton("Aprobar Orden");
        JButton btnBuscar = new JButton("Buscar Orden");
        JButton btnActualizar = new JButton("Actualizar Listado");

        btnGenerar.addActionListener(e -> mostrarDialogoGenerar());
        btnAprobar.addActionListener(e -> aprobarOrden());
        btnBuscar.addActionListener(e -> buscarOrden());
        btnActualizar.addActionListener(e -> actualizarTabla());

        panel.add(btnGenerar);
        panel.add(btnAprobar);
        panel.add(btnBuscar);
        panel.add(btnActualizar);

        return panel;
    }

    private JScrollPane crearPanelTabla() {
        String[] columnas = {"Número", "Fecha", "Proveedor", "Total", "Estado"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaOrdenes = new JTable(modeloTabla);
        return new JScrollPane(tablaOrdenes);
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);
        List<OrdenCompraDTO> ordenes = controller.listarOrdenCompra();
        for (OrdenCompraDTO oc : ordenes) {
            modeloTabla.addRow(new Object[]{
                    oc.getNumero(),
                    oc.getFecha(),
                    oc.getRazonSocialProveedor(),
                    oc.getTotal(),
                    oc.getEstado()
            });
        }
    }

    private JFrame getVentanaPadre() {
        return (JFrame) SwingUtilities.getWindowAncestor(this);
    }

    private void mostrarDialogoGenerar() {
        List<Proveedor> proveedores = ProveedorController.getInstance().getProveedores();
        if (proveedores.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No hay proveedores cargados.",
                    "Sin proveedores", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] opcionesProveedor = new String[proveedores.size()];
        for (int i = 0; i < proveedores.size(); i++) {
            opcionesProveedor[i] = proveedores.get(i).getCuit() + " - " + proveedores.get(i).getRazonSocial();
        }

        String selProv = (String) JOptionPane.showInputDialog(getVentanaPadre(), "Seleccione el proveedor:",
                "Proveedor", JOptionPane.QUESTION_MESSAGE, null, opcionesProveedor, opcionesProveedor[0]);
        if (selProv == null) return;

        int indexProv = java.util.Arrays.asList(opcionesProveedor).indexOf(selProv);
        Proveedor proveedor = proveedores.get(indexProv);

        List<Producto> productos = ProductoController.getInstance().getProductos();
        List<ProductoProveedor> productosDelProveedor = new ArrayList<>();
        for (Producto p : productos) {
            for (ProductoProveedor pp : p.getProveedores()) {
                if (pp.getProveedor().getCuit().equals(proveedor.getCuit())) {
                    productosDelProveedor.add(pp);
                }
            }
        }

        if (productosDelProveedor.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(),
                    "El proveedor no tiene productos asociados. Asocie productos primero desde el módulo Productos.",
                    "Sin productos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<LineaOrdenCompra> lineas = new ArrayList<>();
        boolean agregarMas = true;

        while (agregarMas) {
            String[] opcionesProducto = new String[productosDelProveedor.size()];
            for (int i = 0; i < productosDelProveedor.size(); i++) {
                ProductoProveedor pp = productosDelProveedor.get(i);
                opcionesProducto[i] = pp.getProducto().getDescripcion() + " - $" + pp.getPrecioUnitario();
            }

            String selProd = (String) JOptionPane.showInputDialog(getVentanaPadre(),
                    "Seleccione el producto (Línea " + (lineas.size() + 1) + "):",
                    "Producto", JOptionPane.QUESTION_MESSAGE, null, opcionesProducto, opcionesProducto[0]);
            if (selProd == null) break;

            String cantidadStr = JOptionPane.showInputDialog(getVentanaPadre(), "Cantidad:");
            if (cantidadStr == null) break;

            String error = UIHelper.validarEnteroPositivo(cantidadStr, "Cantidad");
            if (error != null) {
                UIHelper.mostrarError(getVentanaPadre(), error);
                continue;
            }

            int cantidad = Integer.parseInt(cantidadStr);
            int indexProd = java.util.Arrays.asList(opcionesProducto).indexOf(selProd);
            ProductoProveedor ppSeleccionado = productosDelProveedor.get(indexProd);

            lineas.add(new LineaOrdenCompra(cantidad, ppSeleccionado));

            int otraLinea = JOptionPane.showConfirmDialog(getVentanaPadre(),
                    "¿Agregar otra línea?", "Continuar", JOptionPane.YES_NO_OPTION);
            agregarMas = (otraLinea == JOptionPane.YES_OPTION);
        }

        if (lineas.isEmpty()) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "Debe agregar al menos una línea.",
                    "Sin líneas", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String supervisorNombre = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el nombre del usuario que genera la OC:");
        if (supervisorNombre == null || supervisorNombre.trim().isEmpty()) return;

        Usuario usuario = UsuarioController.getInstance().buscarUsuario(supervisorNombre);
        if (usuario == null) {
            UIHelper.mostrarError(getVentanaPadre(), "No se encontró el usuario: " + supervisorNombre);
            return;
        }

        controller.generarOrdenCompra(proveedor, lineas, usuario);
        JOptionPane.showMessageDialog(getVentanaPadre(), "Orden de Compra generada correctamente.");
        actualizarTabla();
    }

    private void aprobarOrden() {
        String numeroStr = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el número de la Orden de Compra a aprobar:");
        if (numeroStr == null || numeroStr.trim().isEmpty()) return;

        String error = UIHelper.validarEnteroPositivo(numeroStr, "Número de OC");
        if (error != null) { UIHelper.mostrarError(getVentanaPadre(), error); return; }

        String supervisorNombre = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el nombre del supervisor:");
        if (supervisorNombre == null || supervisorNombre.trim().isEmpty()) return;

        int numero = Integer.parseInt(numeroStr);
        Usuario supervisor = UsuarioController.getInstance().buscarUsuario(supervisorNombre);

        if (supervisor == null) {
            UIHelper.mostrarError(getVentanaPadre(), "No se encontró el usuario: " + supervisorNombre);
            return;
        }

        boolean aprobada = controller.aprobarOrdenCompra(numero, supervisor);
        if (aprobada) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "Orden de Compra aprobada correctamente.");
            actualizarTabla();
        } else {
            UIHelper.mostrarError(getVentanaPadre(), "No se pudo aprobar. Verifique el número y que el usuario sea supervisor.");
        }
    }

    private void buscarOrden() {
        String numeroStr = JOptionPane.showInputDialog(getVentanaPadre(), "Ingrese el número de la Orden de Compra:");
        if (numeroStr == null || numeroStr.trim().isEmpty()) return;

        String error = UIHelper.validarEnteroPositivo(numeroStr, "Número de OC");
        if (error != null) { UIHelper.mostrarError(getVentanaPadre(), error); return; }

        int numero = Integer.parseInt(numeroStr);
        var oc = controller.buscarOrdenCompra(numero);

        if (oc == null) {
            JOptionPane.showMessageDialog(getVentanaPadre(), "No se encontró la Orden de Compra #" + numero,
                    "No encontrada", JOptionPane.WARNING_MESSAGE);
        } else {
            String info = "Número: " + oc.getNumero()
                    + "\nFecha: " + oc.getFecha()
                    + "\nProveedor: " + oc.getRazonSocialProveedor()
                    + "\nEstado: " + oc.getEstado()
                    + "\nTotal: $" + oc.getTotal()
                    + "\nCantidad de líneas: " + oc.getLineas().size();
            JOptionPane.showMessageDialog(getVentanaPadre(), info, "Orden de Compra encontrada",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
