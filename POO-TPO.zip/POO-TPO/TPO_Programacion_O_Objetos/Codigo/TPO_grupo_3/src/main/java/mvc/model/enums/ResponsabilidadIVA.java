package mvc.model.enums;

public enum ResponsabilidadIVA {
    RESPONSABLE_INSCRIPTO,
    MONOTRIBUTO,
    EXENTO,
    CONSUMIDOR_FINAL,
}
