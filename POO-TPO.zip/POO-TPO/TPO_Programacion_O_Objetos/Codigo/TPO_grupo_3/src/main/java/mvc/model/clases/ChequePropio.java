package mvc.model.clases;

import java.util.Date;

public class ChequePropio extends Cheque {

    // No tiene atributos propios según el diagrama

    public ChequePropio(float monto, Date fechaEmision, Date fechaVencimiento, String firmante) {
        super(monto, fechaEmision, fechaVencimiento, firmante);
    }

    @Override
    public String getDescripcion() {
        return "Cheque Propio";
    }

    @Override
    public String getDetalle() {
        return "Firmante: " + firmante +
                " | Emisión: " + fechaEmision +
                " | Vencimiento: " + fechaVencimiento;
    }
}
