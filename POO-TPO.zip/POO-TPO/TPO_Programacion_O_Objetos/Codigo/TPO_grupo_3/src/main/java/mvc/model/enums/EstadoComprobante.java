package mvc.model.enums;

public enum EstadoComprobante {
    PENDIENTE_APROBACION,
    IMPAGO,
    PAGADO
}
