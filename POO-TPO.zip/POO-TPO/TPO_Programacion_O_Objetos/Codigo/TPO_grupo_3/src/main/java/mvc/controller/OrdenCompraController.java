package mvc.controller;

import mvc.dto.OrdenCompraDTO;
import mvc.model.clases.LineaOrdenCompra;
import mvc.model.clases.OrdenCompra;
import mvc.model.clases.Proveedor;
import mvc.model.clases.Usuario;
import mvc.model.enums.EstadoOrdenCompra;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrdenCompraController {
    private static OrdenCompraController INSTANCE = null;
    private List<OrdenCompra> ordenesCompra = new ArrayList<>();
    private int contadorOC;

    private OrdenCompraController() {
        ordenesCompra = new ArrayList<>();
        this.contadorOC = 0;
    }

    public static synchronized OrdenCompraController getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new OrdenCompraController();
        }
        return INSTANCE;
    }

    public OrdenCompra generarOrdenCompra(Proveedor proveedor, List<LineaOrdenCompra> lineas, Usuario usuario) {
        contadorOC++;
        OrdenCompra oc = new OrdenCompra(contadorOC, new Date(), proveedor, EstadoOrdenCompra.PENDIENTE_APROBACION);
        for (LineaOrdenCompra linea : lineas) {
            oc.agregarLinea(linea);
        }

        // El monto de la OC sumado a la deuda impaga no debe superar el tope; si lo supera,
        // requiere aprobación gerencial (supervisor) antes de emitirse.
        boolean requiereAprobacionGerencial = proveedor.superaLimiteDeuda(oc.calcularTotal());
        if (!requiereAprobacionGerencial || usuario.esSupervisor()) {
            oc.aprobar();
        }

        ordenesCompra.add(oc);
        return oc;
    }

    public OrdenCompra buscarOrdenCompra(int numero) {
        for (OrdenCompra oc : ordenesCompra) {
            if (oc.getNumero() == numero) {
                return oc;
            }
        }
        return null;
    }

    public boolean aprobarOrdenCompra(int numero, Usuario supervisor) {
        OrdenCompra oc = buscarOrdenCompra(numero);
        if (oc == null) {
            return false;
        }
        if (supervisor.esSupervisor()) {
            oc.aprobar();
            return true;
        }
        return false;
    }

    public List<OrdenCompraDTO> listarOrdenCompra() {
        List<OrdenCompraDTO> listaOrdenCompra = new ArrayList<>();
        for (OrdenCompra oc : ordenesCompra) {
            listaOrdenCompra.add(toDTO(oc));
        }
        return listaOrdenCompra;
    }

    public List<OrdenCompra> getOrdenesCompra() {
        return ordenesCompra;
    }

    private OrdenCompraDTO toDTO(OrdenCompra ordenCompra) {
        OrdenCompraDTO dto = new OrdenCompraDTO(ordenCompra.getNumero(), ordenCompra.getFecha(),
                ordenCompra.getRazonSocialProveedor(), ordenCompra.getTotal(), ordenCompra.getEstado());
        return dto;
    }

}
