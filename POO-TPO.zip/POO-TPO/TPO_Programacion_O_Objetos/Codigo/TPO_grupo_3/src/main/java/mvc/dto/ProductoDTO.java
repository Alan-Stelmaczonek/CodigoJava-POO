package mvc.dto;

public class ProductoDTO {
    private int id;
    private String descripcion;
    private String rubroDescripcion;
    private int cantidadProveedores;


    public ProductoDTO(int id, String descripcion, String rubroDescripcion, int cantidadProveedores) {
        this.descripcion = descripcion;
        this.rubroDescripcion = rubroDescripcion;
        this.cantidadProveedores = cantidadProveedores;
        this.id = id;

    }
    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }
    public String getRubroDescripcion() {
        return rubroDescripcion;
    }
    public int getCantidadProveedores() {
        return cantidadProveedores;
    }
    
}

