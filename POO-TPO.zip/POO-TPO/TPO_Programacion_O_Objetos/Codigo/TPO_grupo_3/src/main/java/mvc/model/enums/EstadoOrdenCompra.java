package mvc.model.enums;


public enum EstadoOrdenCompra {
    PENDIENTE_APROBACION,
    EMITIDA,
    APROBADA
}
