package mvc.model.clases;

import mvc.model.enums.TipoRetencion;
import java.util.Date;

public class CertificadoNoRetencion {

    private TipoRetencion tipoImpuesto;
    private Date fechaInicio;
    private Date fechaVencimiento;


    public CertificadoNoRetencion(TipoRetencion tipoImpuesto, Date fechaInicio, Date fechaVencimiento) {
        this.tipoImpuesto = tipoImpuesto;
        this.fechaInicio = fechaInicio;
        this.fechaVencimiento = fechaVencimiento;
    }

    public boolean estaVigente() {
        if (new Date().after(fechaVencimiento) || new Date().before(fechaInicio)) {
            return false;
        } else {
            return true;
        }
    }

    public TipoRetencion getTipoImpuesto() {
        return tipoImpuesto;
    }

    @Override
    public String toString() {
        return "CertificadoNoRetencion: " +
                "tipoImpuesto=" + tipoImpuesto +
                ", fechaInicio=" + fechaInicio +
                ", fechaVencimiento=" + fechaVencimiento +
                "";
    }
}
