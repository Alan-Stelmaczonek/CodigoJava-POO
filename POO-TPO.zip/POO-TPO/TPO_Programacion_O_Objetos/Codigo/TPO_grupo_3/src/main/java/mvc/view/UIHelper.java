package mvc.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UIHelper {

    public static void configurarEnterEscape(JDialog dialogo, JButton botonAceptar) {
        JRootPane rootPane = dialogo.getRootPane();
        rootPane.setDefaultButton(botonAceptar);

        rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "cerrar");
        rootPane.getActionMap().put("cerrar", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialogo.dispose();
            }
        });
    }

    public static void configurarEnterEscape(JFrame frame, JButton botonAceptar) {
        JRootPane rootPane = frame.getRootPane();
        rootPane.setDefaultButton(botonAceptar);

        rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "cerrar");
        rootPane.getActionMap().put("cerrar", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
    }

    public static JLabel crearLabelObligatorio(String texto) {
        JLabel label = new JLabel();
        label.setText("<html>" + texto + " <font color='red'>*</font></html>");
        return label;
    }

    public static JLabel crearLabelCamposObligatorios() {
        JLabel label = new JLabel("<html><font color='red'>*</font> Campos obligatorios</html>");
        label.setFont(label.getFont().deriveFont(Font.ITALIC, 10f));
        return label;
    }

    public static String validarCuit(String cuit) {
        if (cuit == null || cuit.trim().isEmpty()) {
            return "El CUIT es obligatorio.";
        }
        if (!cuit.matches("\\d{2}-\\d{8}-\\d{1}")) {
            return "El CUIT debe tener el formato XX-XXXXXXXX-X.";
        }
        return null;
    }

    public static String validarEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return "El email es obligatorio.";
        }
        if (!email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
            return "El email debe tener un formato válido (ej: mail@mail.com).";
        }
        return null;
    }

    public static String validarTelefono(String telefono) {
        if (telefono == null || telefono.trim().isEmpty()) {
            return "El teléfono es obligatorio.";
        }
        if (!telefono.matches("[\\d\\s\\-()]+")) {
            return "El teléfono solo puede contener números, guiones, espacios y paréntesis.";
        }
        return null;
    }

    public static String validarNoVacio(String valor, String nombreCampo) {
        if (valor == null || valor.trim().isEmpty()) {
            return nombreCampo + " es obligatorio.";
        }
        return null;
    }

    public static String validarNroIIBB(String nro) {
        if (nro == null || nro.trim().isEmpty()) {
            return "El Nro. de Ingresos Brutos es obligatorio.";
        }
        if (!nro.matches("\\d+")) {
            return "El Nro. de Ingresos Brutos solo puede contener números.";
        }
        return null;
    }

    public static String validarFecha(String fechaTexto) {
        if (fechaTexto == null || fechaTexto.trim().isEmpty()) {
            return "La fecha es obligatoria.";
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);
            sdf.parse(fechaTexto);
            return null;
        } catch (Exception e) {
            return "La fecha debe tener el formato dd/MM/yyyy y ser válida.";
        }
    }

    public static Date parsearFecha(String fechaTexto) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        return sdf.parse(fechaTexto);
    }

    public static String validarFloatPositivo(String valor, String nombreCampo) {
        if (valor == null || valor.trim().isEmpty()) {
            return nombreCampo + " es obligatorio.";
        }
        try {
            float f = Float.parseFloat(valor);
            if (f < 0) {
                return nombreCampo + " debe ser un número positivo.";
            }
            return null;
        } catch (NumberFormatException e) {
            return nombreCampo + " debe ser un número válido.";
        }
    }

    public static String validarEnteroPositivo(String valor, String nombreCampo) {
        if (valor == null || valor.trim().isEmpty()) {
            return nombreCampo + " es obligatorio.";
        }
        try {
            int i = Integer.parseInt(valor);
            if (i <= 0) {
                return nombreCampo + " debe ser un número entero positivo.";
            }
            return null;
        } catch (NumberFormatException e) {
            return nombreCampo + " debe ser un número entero válido.";
        }
    }

    public static String validarPorcentaje(String valor) {
        if (valor == null || valor.trim().isEmpty()) {
            return "El porcentaje es obligatorio.";
        }
        try {
            float f = Float.parseFloat(valor);
            if (f < 0 || f > 100) {
                return "El porcentaje debe estar entre 0 y 100.";
            }
            return null;
        } catch (NumberFormatException e) {
            return "El porcentaje debe ser un número válido.";
        }
    }

    public static String validarNombreUsuario(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "El nombre de usuario es obligatorio.";
        }
        if (nombre.contains(" ")) {
            return "El nombre de usuario no puede contener espacios.";
        }
        return null;
    }

    public static String validarContrasenia(String contrasenia) {
        if (contrasenia == null || contrasenia.isEmpty()) {
            return "La contraseña es obligatoria.";
        }
        if (contrasenia.length() < 4) {
            return "La contraseña debe tener al menos 4 caracteres.";
        }
        return null;
    }

    public static String validarCBU(String cbu) {
        if (cbu == null || cbu.trim().isEmpty()) {
            return "El CBU es obligatorio.";
        }
        if (!cbu.matches("\\d{22}")) {
            return "El CBU debe tener exactamente 22 dígitos numéricos.";
        }
        return null;
    }

    public static String validarRangoFechas(String desdeTexto, String hastaTexto) {
        String errorDesde = validarFecha(desdeTexto);
        if (errorDesde != null) return "Fecha desde: " + errorDesde;

        String errorHasta = validarFecha(hastaTexto);
        if (errorHasta != null) return "Fecha hasta: " + errorHasta;

        try {
            Date desde = parsearFecha(desdeTexto);
            Date hasta = parsearFecha(hastaTexto);
            if (desde.after(hasta)) {
                return "La fecha 'desde' debe ser anterior a la fecha 'hasta'.";
            }
            return null;
        } catch (Exception e) {
            return "Error al procesar las fechas.";
        }
    }

    public static String validarMesAnio(String mesAnio) {
        if (mesAnio == null || mesAnio.trim().isEmpty()) {
            return "El mes y año son obligatorios.";
        }
        if (!mesAnio.matches("(0[1-9]|1[0-2])/\\d{4}")) {
            return "El mes y año deben tener el formato MM/yyyy.";
        }
        return null;
    }

    public static void mostrarError(Component padre, String mensaje) {
        JOptionPane.showMessageDialog(padre, mensaje, "Error de validación", JOptionPane.ERROR_MESSAGE);
    }
}
