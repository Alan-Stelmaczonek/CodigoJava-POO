package mvc.model.enums;

public enum TipoIVA {
    IVA_21(21.0f),
    IVA_5(5.0f),
    IVA_10_5(10.5f),
    IVA_2_5(2.5f),
    IVA_27(27.0f);

    private final float porcentaje;

    TipoIVA(float porcentaje) {
        this.porcentaje = porcentaje;
    }

    public float getPorcentaje() {
        return porcentaje;
    }
}


