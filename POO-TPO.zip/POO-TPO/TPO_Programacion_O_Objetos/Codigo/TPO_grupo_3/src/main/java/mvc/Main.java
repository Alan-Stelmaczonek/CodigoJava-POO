package mvc;

import mvc.controller.UsuarioController;
import mvc.model.clases.Rol;
import mvc.view.MainFrame;

import javax.swing.*;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        cargarDatosIniciales();
        SwingUtilities.invokeLater(() -> new MainFrame());
    }

    private static void cargarDatosIniciales() {
        UsuarioController usuarioController = UsuarioController.getInstance();
        Rol admin = new Rol("Administrador", Arrays.asList("proveedores", "productos", "ordenesCompra", "comprobantes", "ordenesPago", "usuarios", "parametros", "consultas"));
        Rol supervisor = new Rol("Supervisor", Arrays.asList("proveedores", "productos", "ordenesCompra", "comprobantes", "ordenesPago", "parametros", "consultas"));
        Rol operador = new Rol("Operador", Arrays.asList("proveedores", "productos", "ordenesCompra", "comprobantes", "consultas"));
        usuarioController.altaUsuario("admin", "admin", admin);
        usuarioController.altaUsuario("supervisor", "supervisor", supervisor);
        usuarioController.altaUsuario("operador", "1234", operador);
    }
}
