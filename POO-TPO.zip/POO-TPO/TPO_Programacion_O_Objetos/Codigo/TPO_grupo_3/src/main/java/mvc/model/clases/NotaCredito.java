package mvc.model.clases;

import mvc.model.enums.EstadoComprobante;
import java.util.Date;
import java.util.List;

public class NotaCredito extends Comprobante {
    private Factura facturaAsociada;

    public NotaCredito(int numero, Date fecha, EstadoComprobante estado, List<LineaComprobante> lineas, Proveedor proveedor, Factura facturaAsociada) {
        super(numero, fecha, estado, lineas, proveedor);
        this.facturaAsociada = facturaAsociada;
    }

    public Factura getFacturaAsociada() {
        return facturaAsociada;
    }

    @Override
    public String getTipo() {
        return "NotaCredito";
    }

    @Override
    public float calcularTotal() {
        float total = 0;
        for (int i = 0; lineas.size() > i; i++) {
            total = total + lineas.get(i).getSubtotal() + lineas.get(i).getMontoIVA();
        }
        return total;
    }

    // Reduce lo que le debe al proveedor
    @Override
    public float getMontoParaCuentaCorriente() {
        return -calcularTotal();
    }
}
