package mvc.controller;

import mvc.model.clases.ParametroRetencion;
import mvc.model.enums.TipoRetencion;

import java.util.ArrayList;
import java.util.List;

public class ParametroRetencionController {

    private static ParametroRetencionController INSTANCE = null;

    private List<ParametroRetencion> parametros;

    private ParametroRetencionController() {
        this.parametros = new ArrayList<>();
    }

    public static synchronized ParametroRetencionController getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ParametroRetencionController();
        }
        return INSTANCE;
    }

    public ParametroRetencion altaParametro(TipoRetencion tipoImpuesto, float porcentaje, float minimoNoImponible) {
        if (buscarParametro(tipoImpuesto) != null) {
            System.out.println("Ya existe un parámetro para el tipo de retención: " + tipoImpuesto);
            return null;
        }
        ParametroRetencion parametro = new ParametroRetencion(tipoImpuesto, porcentaje, minimoNoImponible);
        parametros.add(parametro);
        return parametro;
    }

    public boolean modificarParametro(TipoRetencion tipoImpuesto, float porcentaje, float minimoNoImponible) {
        ParametroRetencion parametro = buscarParametro(tipoImpuesto);
        if (parametro == null) {
            return false;
        }
        parametro.setPorcentaje(porcentaje);
        parametro.setMinimoNoImponible(minimoNoImponible);
        return true;
    }

    public ParametroRetencion buscarParametro(TipoRetencion tipoImpuesto) {
        for (ParametroRetencion parametro : parametros) {
            if (parametro.getTipoImpuesto() == tipoImpuesto) {
                return parametro;
            }
        }
        return null;
    }

    public List<ParametroRetencion> listarParametros() {
        return parametros;
    }
}
