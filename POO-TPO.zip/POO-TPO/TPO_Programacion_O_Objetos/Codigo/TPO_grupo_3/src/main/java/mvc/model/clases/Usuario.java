package mvc.model.clases;

public class Usuario {
    private String nombreusuario;
    private String contrasenia;
    private Rol rol;

    public Usuario(String nombreusuario, String contrasenia, Rol rol) {
        this.nombreusuario = nombreusuario;
        this.contrasenia = contrasenia;
        this.rol = rol;
    }
    public String getNombreusuario() {
        return nombreusuario;
    }
    public boolean validarCredenciales(String contrasenia) {
        return contrasenia.equals(this.contrasenia);
    }
    public boolean tienePermiso(String permiso) {
        return this.rol.tienePermiso(permiso);
    }
    public boolean esSupervisor (){
        return rol.getNombre().equals("Supervisor") || rol.getNombre().equals("Administrador");
    }

    public Rol getRol() {
        return rol;
    }

    public void setNombreusuario(String nombreusuario) {
        this.nombreusuario = nombreusuario;
    }
    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
    public void setRol(Rol rol) {
        this.rol = rol;
    }
}
