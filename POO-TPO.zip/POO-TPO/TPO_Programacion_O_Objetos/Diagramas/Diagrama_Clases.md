``` mermaid
classDiagram
    direction TB

    class UsuarioController {
        -usuarios: List~Usuario~
        +login(nombreUsuario: String, contrasenia: String) Usuario
        +altaUsuario(nombre: String, pass: String, rol: Rol) Usuario
        +modificarUsuario(nombreUsuario: String, datosActualizados: Map) boolean
        +eliminarUsuario(nombreUsuario: String) boolean
        +buscarUsuario(nombreUsuario: String) Usuario
        +getUsuarios() List~Usuario~
        +listarUsuarios() List~UsuarioDTO~
    }

    class ProveedorController {
        -proveedores: List~Proveedor~
        +altaProveedor(cuit: String, razonSocial: String, respIVA: mvc_TPO.enums.model.ResponsabilidadIVA, nombreFantasia: String, direccion: String, telefono: String, email: String, nroIIBB: String, fechaInicio: Date, rubros: List~Rubro~, limiteDeuda: float) Proveedor
        +modificarProveedor(cuit: String, datosActualizados: Map) boolean
        +buscarProveedor(cuit: String) Proveedor
        +cargarCertificadoNoRetencion(proveedor: Proveedor, tipoImpuesto: TipoRetencion, fechaInicio: Date, fechaVencimiento: Date) CertificadoNoRetencion
        +listarProveedores() List~ProveedorDTO~
        +getProveedores() List~Proveedor~
    }

    class ProductoController {
        -productos: List~Producto~
        -rubros: List~Rubro~
        +altaProducto(id: int, descripcion: String, tipoIVA: TipoIVA, unidadMedida: String, rubro: Rubro) Producto
        +altaRubro(descripcion: String) Rubro
        +modificarRubro(id: int, descripcion: String) boolean
        +asociarProductoProveedor(producto: Producto, proveedor: Proveedor, precioUnitario: float) ProductoProveedor
        +listarProductos() List~ProductoDTO~
        +getProductos() List~Producto~
        +getRubros() List~Rubro~
    }

    class OrdenCompraController {
        -ordenesCompra: List~OrdenCompra~
        -contadorOC: int
        +generarOrdenCompra(proveedor: Proveedor, lineas: List~LineaOrdenCompra~, usuario: Usuario) OrdenCompra
        +buscarOrdenCompra(numero: int) OrdenCompra
        +aprobarOrdenCompra(numero: int, supervisor: Usuario) boolean
        +listarOrdenCompra() List~OrdenCompraDTO~
        +getOrdenesCompra() List~OrdenCompra~
    }

    class ComprobanteController {
        -comprobante: List~Comprobante~
        -contadorComprobante: int
        +registrarFactura(proveedor: Proveedor, oc: OrdenCompra, lineas: List~LineaComprobante~, fecha: Date, usuario: Usuario) Factura
        +registrarNotaCredito(proveedor: Proveedor, lineas: List~LineaComprobante~, fecha: Date, facturaAsociada: Factura) NotaCredito
        +registrarNotaDebito(proveedor: Proveedor, lineas: List~LineaComprobante~, fecha: Date, descripcionMotivo: String) NotaDebito
        +aprobarFactura(numero: int, supervisor: Usuario) boolean
        +buscarFacturaPorNumero(numero: int) Factura
        +listarComprobante() List~ComprobanteDTO~
    }

    class OrdenPagoController {
        -ordenesPago: List~OrdenPago~
        -contadorOP: int
        +emitirOrdenPago(proveedor: Proveedor, comprobantes: List~Comprobante~, mediosPago: List~MedioPago~) OrdenPago
        +obtenerOrdenesPagoEmitidas(desde: Date, hasta: Date) List~OrdenPago~
        +getOrdenesPago() List~OrdenPago~
    }

    class ConsultaController {
        +obtenerCuentaCorriente(proveedor: Proveedor) CuentaCorrienteDTO
        +compararPrecios(producto: Producto) List~ComparacionPreciosDTO~
        +obtenerLibroIVACompras(mesAnio: String) List~LineaLibroIVA~
        +obtenerRankingAcreedores() List~RankingAcreedorDTO~
        +obtenerTotalRetencionesEmitidas() Map~TipoRetencion_float~
        +obtenerFacturasRecibidas(desde: Date, hasta: Date, proveedor: Proveedor) List~Factura~
    }

    class Usuario {
        -nombreUsuario: String
        -contrasenia: String
        +getNombreUsuario() String
        +validarCredenciales(contrasenia: String) boolean
        +tienePermiso(permiso: String) boolean
        +esSupervisor() boolean
    }

    class Rol {
        -nombre: String
        -permisos: List~String~
        +agregarPermiso(permiso: String) void
        +tienePermiso(permiso: String) boolean
        +getNombre() String
    }

    class Proveedor {
        -cuit: String
        -responsabilidadIVA: mvc_TPO.enums.model.ResponsabilidadIVA
        -razonSocial: String
        -nombreFantasia: String
        -direccion: String
        -telefono: String
        -email: String
        -nroIngresosBrutos: String
        -fechaInicioActividades: Date
        -limiteDeuda: float
        +getCuit() String
        +getDeudaTotal() float
        +superaLimiteDeuda() boolean
        +superaLimiteDeuda(montoAdicional: float) boolean
        +agregarComprobante(comprobante: Comprobante) void
        +agregarOrdenPago(ordenPago: OrdenPago) void
        +getComprobantesImpagos() List~Comprobante~
        +tieneCertificadoVigente(tipoImpuesto: TipoRetencion) boolean
        +agregarRubro(rubro: Rubro) void
        +agregarCertificado(certificado: CertificadoNoRetencion) void
    }

    class Rubro {
        -id: int
        -descripcion: String
        +getId() int
        +getDescripcion() String
    }

    class mvc_TPO.enums.model.ResponsabilidadIVA {
        <<enumeration>>
        RESPONSABLE_INSCRIPTO
        MONOTRIBUTO
        EXENTO
        CONSUMIDOR_FINAL
    }

    class TipoRetencion {
        <<enumeration>>
        IVA
        IIBB
        GANANCIAS
    }

    class TipoIVA {
        <<enumeration>>
        2.5
        5
        10.5
        21
        27
    }

    class CertificadoNoRetencion {
        -tipoImpuesto: TipoRetencion
        -fechaInicio: Date
        -fechaVencimiento: Date
        +estaVigente() boolean
        +getTipoImpuesto() TipoRetencion
    }

    class Producto {
        -id: int
        -descripcion: String
        -unidadMedida: String
        -tipoIVA: TipoIVA
        +getId() int
        +getDescripcion() String
        +getUnidadMedida() String
        +getTipoIVA() TipoIVA
        +getRubro() Rubro
        +getProveedores() List~ProductoProveedor~
    }

    class ProductoProveedor {
        <<asociativa>>
        -precioUnitario: float
        +actualizarPrecio(nuevoPrecio: float) void
        +getPrecioUnitario() float
        +getProducto() Producto
        +getProveedor() Proveedor
    }

    class OrdenCompra {
        -numero: int
        -fecha: Date
        -estado: EstadoOrdenCompra
        +getNumero() int
        +calcularTotal() float
        +getTotal() float
        +agregarLinea(linea: LineaOrdenCompra) void
        +aprobar() void
        +marcarPendienteAprobacion() void
        +requiereAprobacion() boolean
        +getLineas() List~LineaOrdenCompra~
        +getEstado() EstadoOrdenCompra
        +getRazonSocialProveedor() String
    }

    class EstadoOrdenCompra {
        <<enumeration>>
        PENDIENTE_APROBACION
        EMITIDA
        APROBADA
    }

    class LineaOrdenCompra {
        -cantidad: int
        +getSubtotal() float
        +getProductoProveedor() ProductoProveedor
    }

    class Comprobante {
        <<abstract>>
        -numero: int
        -fecha: Date
        -estado: EstadoComprobante
        +getNumero() int
        +calcularTotal() float*
        +calcularTotalIVA() float
        +marcarPagado() void
        +estaPago() boolean
        +marcarPendienteAprobacion() void
        +aprobar() void
        +requiereAprobacion() boolean
        +getMontoParaCuentaCorriente() float*
        +getTipo() String*
        +agregarLinea(linea: LineaComprobante) void
        +getLineas() List~LineaComprobante~
        +getFecha() Date
        +getEstado() EstadoComprobante
    }

    class EstadoComprobante {
        <<enumeration>>
        PENDIENTE_APROBACION
        IMPAGO
        PAGADO
    }

    class Factura {
        +calcularTotal() float
        +validarPreciosContraOC(ordenCompra: OrdenCompra) boolean
        +getMontoParaCuentaCorriente() float
        +getTipo() String
        +getOrdenCompra() OrdenCompra
    }

    class NotaCredito {
        +calcularTotal() float
        +getMontoParaCuentaCorriente() float
        +getTipo() String
    }

    class NotaDebito {
        -descripcionMotivo: String
        +calcularTotal() float
        +getMontoParaCuentaCorriente() float
        +getTipo() String
    }

    class LineaComprobante {
        -cantidad: int
        -precioUnitario: float
        -tipoIVA: TipoIVA
        +getSubtotal() float
        +getMontoIVA() float
        +getTipoIVA() TipoIVA
    }

    class OrdenPago {
        -numero: int
        -fecha: Date
        -totalACancelar: float
        -totalRetenciones: float
        +agregarComprobante(comprobante: Comprobante) void
        +agregarMedioPago(medioPago: MedioPago) void
        +agregarRetencion(retencion: Retencion) void
        +getNumero() int
        +getTotalACancelar() float
        +calcularTotalRetenciones() float
        +calcularMontoAPagar() float
        +getRetenciones() List~Retencion~
        +getMediosPago() List~MedioPago~
        +getFecha() Date
    }

    class Retencion {
        -tipoImpuesto: TipoRetencion
        -porcentaje: float
        -monto: float
        -minimoNoImponible: float
        +calcularMonto(baseImponible: float) float
        +correspondeRetener(baseImponible: float) boolean
        +getTipoImpuesto() TipoRetencion
        +getPorcentaje() float
        +getMinimoNoImponible() float
        +getMonto() float
    }

    class ParametroRetencion {
        -tipoImpuesto: TipoRetencion
        -porcentaje: float
        -minimoNoImponible: float
        +getTipoImpuesto() TipoRetencion
        +getPorcentaje() float
        +getMinimoNoImponible() float
    }

    class ParametroRetencionController {
        -parametros: List~ParametroRetencion~
        +altaParametro(tipoImpuesto: TipoRetencion, porcentaje: float, minimoNoImponible: float) ParametroRetencion
        +modificarParametro(tipoImpuesto: TipoRetencion, porcentaje: float, minimoNoImponible: float) boolean
        +buscarParametro(tipoImpuesto: TipoRetencion) ParametroRetencion
        +listarParametros() List~ParametroRetencion~
    }

    class MedioPago {
        <<abstract>>
        -monto: float
        +getMonto() float
        +getDescripcion() String*
        +getDetalle() String*
    }

    class Efectivo {
        +getDescripcion() String
        +getDetalle() String
    }

    class Transferencia {
        -cbuDestino: String
        -fechaTransferencia: Date
        +getDescripcion() String
        +getDetalle() String
    }

    class Cheque {
        <<abstract>>
        -fechaEmision: Date
        -fechaVencimiento: Date
        -firmante: String
        +isVencido() boolean
        +getFechaEmision() Date
        +getFechaVencimiento() Date
        +getFirmante() String
    }

    class ChequePropio {
        +getDescripcion() String
        +getDetalle() String
    }

    class ChequeDeTerceros {
        -emisorOriginal: String
        +getDescripcion() String
        +getDetalle() String
        +getEmisorOriginal() String
    }

    class ProveedorDTO {
        <<DTO>>
        -cuit: String
        -razonSocial: String
        -nombreFantasia: String
        -responsabilidadIVA: String
        -rubros: String
        -limiteDeuda: float
        -deudaTotal: float
        +getCuit() String
        +getRazonSocial() String
        +getNombreFantasia() String
        +getResponsabilidadIVA() String
        +getRubros() String
        +getLimiteDeuda() float
        +getDeudaTotal() float
    }

    class ProductoDTO {
        <<DTO>>
        -id: int
        -descripcion: String
        -rubroDescripcion: String
        -cantidadProveedores: int
        +getId() int
        +getDescripcion() String
        +getRubroDescripcion() String
        +getCantidadProveedores() int
    }

    class OrdenCompraDTO {
        <<DTO>>
        -numero: int
        -fecha: Date
        -razonSocialProveedor: String
        -total: float
        -estado: String
        +getNumero() int
        +getFecha() Date
        +getRazonSocialProveedor() String
        +getTotal() float
        +getEstado() String
    }

    class ComprobanteDTO {
        <<DTO>>
        -numero: int
        -tipo: String
        -fecha: Date
        -razonSocialProveedor: String
        -total: float
        -estado: String
        +getNumero() int
        +getTipo() String
        +getFecha() Date
        +getRazonSocialProveedor() String
        +getTotal() float
        +getEstado() String
        +isPagado() boolean
    }

    class UsuarioDTO {
        <<DTO>>
        -nombreUsuario: String
        -nombreRol: String
        -permisos: String
        +getNombreUsuario() String
        +getNombreRol() String
        +getPermisos() String
    }

    class CuentaCorrienteDTO {
        <<DTO>>
        -deudaTotal: float
        -comprobantes: List~Comprobante~
        -comprobantesImpagos: List~Comprobante~
        -ordenesPago: List~OrdenPago~
        +getDeudaTotal() float
        +getComprobantes() List~Comprobante~
        +getComprobantesImpagos() List~Comprobante~
        +getOrdenesPago() List~OrdenPago~
    }

    class LineaLibroIVA {
        <<DTO>>
        -cuitProveedor: String
        -razonSocial: String
        -fechaDocumento: Date
        -tipoDocumento: String
        -montoIVA2_5: float
        -montoIVA5: float
        -montoIVA10_5: float
        -montoIVA21: float
        -montoIVA27: float
        -totalDocumento: float
        +getCuitProveedor() String
        +getRazonSocial() String
        +getFechaDocumento() Date
        +getTipoDocumento() String
        +getMontoIVA2_5() float
        +getMontoIVA5() float
        +getMontoIVA10_5() float
        +getMontoIVA21() float
        +getMontoIVA27() float
        +getTotalDocumento() float
    }

    class OrdenPagoDTO {
        <<DTO>>
        -numero: int
        -fecha: Date
        -razonSocialProveedor: String
        -totalACancelar: float
        -totalRetenciones: float
        -montoAPagar: float
        +getNumero() int
        +getFecha() Date
        +getRazonSocialProveedor() String
        +getTotalACancelar() float
        +getTotalRetenciones() float
        +getMontoAPagar() float
    }

    class ComparacionPreciosDTO {
        <<DTO>>
        -razonSocialProveedor: String
        -cuitProveedor: String
        -precioUnitario: float
        -unidadMedida: String
        +getRazonSocialProveedor() String
        +getCuitProveedor() String
        +getPrecioUnitario() float
        +getUnidadMedida() String
    }

    class RankingAcreedorDTO {
        <<DTO>>
        -posicion: int
        -razonSocial: String
        -cuit: String
        -deudaTotal: float
        +getPosicion() int
        +getRazonSocial() String
        +getCuit() String
        +getDeudaTotal() float
    }

    %% ── Controllers → Entidades (ownership de listas) ──
    UsuarioController "1" *-- "*" Usuario
    ProveedorController "1" *-- "*" Proveedor
    ProductoController "1" *-- "*" Producto
    ProductoController "1" *-- "*" Rubro
    OrdenCompraController "1" *-- "*" OrdenCompra
    OrdenPagoController "1" *-- "*" OrdenPago
    ComprobanteController "1" *-- "*" Comprobante
    ParametroRetencionController "1" *-- "*" ParametroRetencion

    %% ── OrdenPagoController usa la parametrización vigente de retenciones ──
    OrdenPagoController ..> ParametroRetencionController : usa

    %% ── ConsultaController usa otros controllers (dependencia) ──
    ConsultaController ..> ProveedorController : usa
    ConsultaController ..> ProductoController : usa

    %% ── Controllers producen DTOs ──
    UsuarioController ..> UsuarioDTO : produce
    ProveedorController ..> ProveedorDTO : produce
    ProductoController ..> ProductoDTO : produce
    OrdenCompraController ..> OrdenCompraDTO : produce
    ComprobanteController ..> ComprobanteDTO : produce
    ConsultaController ..> CuentaCorrienteDTO : produce
    ConsultaController ..> ComprobanteDTO : produce
    ConsultaController ..> OrdenPagoDTO : produce
    ConsultaController ..> LineaLibroIVA : produce
    ConsultaController ..> ComparacionPreciosDTO : produce
    ConsultaController ..> RankingAcreedorDTO : produce

    %% ── Composiciones internas de entidades ──
    OrdenCompra "1" *-- "1..*" LineaOrdenCompra
    Comprobante "1" *-- "1..*" LineaComprobante
    OrdenPago "1" *-- "*" Retencion
    OrdenPago "1" *-- "1..*" MedioPago
    Proveedor "1" *-- "*" CertificadoNoRetencion
    Proveedor "1" *-- "*" Comprobante
    Producto "1" *-- "*" ProductoProveedor

    %% ── Asociaciones simples ──
    Proveedor "*" o-- "1..*" Rubro : rubros
    Proveedor "1" --> "*" OrdenPago : ordenesPagoRecibidas
    Producto "*" o-- "1" Rubro : rubro
    OrdenPago "*" --> "1..*" Comprobante : comprobantesCancelados
    Usuario "*" --> "1" Rol : rol
    OrdenCompra "*" --> "1" Proveedor : proveedor
    Factura "*" --> "0..1" OrdenCompra : ordenCompraOrigen
    NotaCredito "*" --> "0..1" Factura : facturaAsociada
    LineaOrdenCompra "*" --> "1" ProductoProveedor : itemCotizado
    LineaComprobante "*" --> "1" Producto : producto
    ProductoProveedor "*" --> "1" Proveedor : proveedor

    %% ── Herencias ──
    Comprobante <|-- Factura
    Comprobante <|-- NotaCredito
    Comprobante <|-- NotaDebito
    MedioPago <|-- Efectivo
    MedioPago <|-- Transferencia
    MedioPago <|-- Cheque
    Cheque <|-- ChequePropio
    Cheque <|-- ChequeDeTerceros

    %% ── Enumeraciones de estado ──
    Comprobante "*" --> "1" EstadoComprobante
    OrdenCompra "*" --> "1" EstadoOrdenCompra
    Proveedor "*" --> "1" mvc_TPO.enums.model.ResponsabilidadIVA
    Retencion "*" --> "1" TipoRetencion
    CertificadoNoRetencion "*" --> "1" TipoRetencion
    ParametroRetencion "*" --> "1" TipoRetencion
    Producto "*" --> "1" TipoIVA
    LineaComprobante "*" --> "1" TipoIVA
```
