```mermaid
sequenceDiagram
    actor Operador
    participant SGP as :SistemaGestionProveedores
    participant LC as :LineaComprobante
    participant F as :Factura
    participant U as :Usuario
    participant P as :Proveedor

    Operador->>+SGP: registrarFactura(proveedor: Proveedor, oc: OrdenCompra, lineas: List~LineaComprobante~, fecha: Date, usuario: Usuario)

    loop [por cada linea ingresada]
        SGP->>+LC: <<create>> new LineaComprobante(cantidad, precioUnitario, tipoIVA)
        LC-->>-SGP: return lineaComprobante
    end

    SGP->>+F: <<create>> new Factura(numero, fecha, PENDIENTE_APROBACION, lineas, proveedor, oc)
    F-->>-SGP: return factura

    alt [tiene Orden de Compra]
        SGP->>+F: validarPreciosContraOC(oc)
        F-->>-SGP: return preciosCoinciden: boolean
    else [sin Orden de Compra]
        SGP->>SGP: preciosCoinciden = false
    end

    alt [preciosCoinciden]
        SGP->>F: aprobar()
    else [no coinciden o sin OC]
        SGP->>+U: esSupervisor()
        U-->>-SGP: return boolean
        alt [usuario es supervisor]
            SGP->>F: aprobar()
        else [no es supervisor]
            note over F: queda PENDIENTE_APROBACION
        end
    end

    SGP->>+P: agregarComprobante(factura)
    P-->>-SGP: return void

    SGP-->>-Operador: return factura
```

> Nota: una factura con OC asociada y precios coincidentes se aprueba automáticamente (`Factura.aprobar()`, estado `IMPAGO`). Una factura sin OC, o con precios que no coinciden, solo se aprueba en el momento de la carga si quien la registra es supervisor (`usuario.esSupervisor()`); en caso contrario queda `PENDIENTE_APROBACION` y debe ser validada y aceptada después por un supervisor mediante `ComprobanteController.aprobarFactura(numero, supervisor)`.
