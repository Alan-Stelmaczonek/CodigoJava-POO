```mermaid
sequenceDiagram
    actor Operador
    participant SGP as :SistemaGestionProveedores
    participant C as :Comprobante
    participant P as :Proveedor
    participant PRC as :ParametroRetencionController
    participant R as :Retencion
    participant OP as :OrdenPago

    Operador->>+SGP: emitirOrdenPago(proveedor: Proveedor, comprobantes: List~Comprobante~, mediosPago: List~MedioPago~)

    loop [por cada comprobante en comprobantes]
        SGP->>+C: getMontoParaCuentaCorriente()
        C-->>-SGP: return monto
    end
    SGP->>SGP: totalACancelar = suma de montos

    loop [por cada tipoImpuesto en TipoRetencion.values()]
        SGP->>+P: tieneCertificadoVigente(tipoImpuesto)
        P-->>-SGP: return false

        SGP->>+PRC: buscarParametro(tipoImpuesto)
        PRC-->>-SGP: return parametro

        SGP->>+R: <<create>> new Retencion(tipoImpuesto, porcentaje, 0, minimoNoImponible)
        SGP->>+R: correspondeRetener(totalACancelar)
        R-->>-SGP: return true
        SGP->>+R: calcularMonto(totalACancelar)
        R-->>-SGP: return monto
        R-->>-SGP: return retencion
    end
    SGP->>SGP: totalRetenciones = suma de montos de retenciones

    SGP->>+OP: <<create>> new OrdenPago(numero, fecha, totalACancelar, totalRetenciones)
    OP-->>-SGP: return ordenPago

    loop [por cada comprobante en comprobantes]
        SGP->>OP: agregarComprobante(comprobante)
        SGP->>+C: marcarPagado()
        C-->>-SGP: return void
    end

    loop [por cada medioPago en mediosPago]
        SGP->>OP: agregarMedioPago(medioPago)
    end

    loop [por cada retencion calculada]
        SGP->>OP: agregarRetencion(retencion)
    end

    SGP->>+P: agregarOrdenPago(ordenPago)
    P-->>-SGP: return void

    SGP-->>-Operador: return ordenPago
```

> Nota: si el proveedor tiene certificado de no retención vigente (`tieneCertificadoVigente`) para un tipo de impuesto, ese tipo se omite por completo. Si no hay `ParametroRetencion` configurado para un tipo, también se omite. La retención solo se agrega si `correspondeRetener(totalACancelar)` es verdadero (el monto a cancelar supera el mínimo no imponible).
