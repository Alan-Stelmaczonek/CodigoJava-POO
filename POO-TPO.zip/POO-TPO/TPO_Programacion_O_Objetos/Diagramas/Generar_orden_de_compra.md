```mermaid
sequenceDiagram
    actor Operador
    participant SGP as :SistemaGestionProveedores
    participant OC as :OrdenCompra
    participant P as :Proveedor
    participant U as :Usuario

    Operador->>+SGP: generarOrdenCompra(proveedor: Proveedor, lineas: List~LineaOrdenCompra~, usuario: Usuario)

    SGP->>+OC: <<create>> new OrdenCompra(numero, fecha, proveedor, PENDIENTE_APROBACION)
    OC-->>-SGP: return ordenCompra

    loop [por cada linea en lineas]
        SGP->>OC: agregarLinea(linea)
    end

    SGP->>+OC: calcularTotal()
    OC-->>-SGP: return totalOC

    SGP->>+P: superaLimiteDeuda(totalOC)
    P->>P: getDeudaTotal() + totalOC > limiteDeuda
    P-->>-SGP: return requiereAprobacionGerencial: boolean

    alt [no supera el límite de deuda]
        SGP->>OC: aprobar()
    else [supera el límite de deuda]
        SGP->>+U: esSupervisor()
        U-->>-SGP: return boolean
        alt [usuario es supervisor]
            SGP->>OC: aprobar()
        else [no es supervisor]
            note over OC: queda PENDIENTE_APROBACION
        end
    end

    SGP-->>-Operador: return ordenCompra
```

> Nota: la selección del proveedor, la carga de líneas (`new LineaOrdenCompra(cantidad, productoProveedor)`) y la búsqueda del usuario las hace la vista antes de invocar a `OrdenCompraController.generarOrdenCompra`, que ya recibe los objetos resueltos. El control de límite de deuda usa `Proveedor.superaLimiteDeuda(montoAdicional)`, que suma el total de la nueva OC a la deuda impaga actual (`getDeudaTotal()`) y compara contra `limiteDeuda`. Si no se supera el límite, la OC se aprueba directamente; si se supera, solo se aprueba si quien la genera es supervisor (`esSupervisor()`) — de lo contrario queda `PENDIENTE_APROBACION` para una aprobación gerencial posterior vía `aprobarOrdenCompra(numero, supervisor)`.
