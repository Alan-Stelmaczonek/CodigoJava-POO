```mermaid
sequenceDiagram
    actor Operador
    participant SGP as :SistemaGestionProveedores
    participant P as :Proveedor
    participant C as :Comprobante

    Operador->>+SGP: obtenerCuentaCorriente(proveedor: Proveedor)

    SGP->>+P: getDeudaTotal()
    loop [por cada comprobante en comprobantes]
        P->>+C: estaPago()
        C-->>-P: return boolean
        alt [no está pago]
            P->>+C: getMontoParaCuentaCorriente()
            C-->>-P: return monto
            P->>P: totalAPagar += monto
        end
    end
    P-->>-SGP: return deudaTotal: float

    SGP->>+P: getComprobantes()
    P-->>-SGP: return List~Comprobante~
    SGP->>SGP: mapear cada Comprobante a ComprobanteDTO

    SGP->>+P: getComprobantesImpagos()
    P-->>-SGP: return List~Comprobante~
    SGP->>SGP: mapear cada Comprobante a ComprobanteDTO

    SGP->>+P: getOrdenesDePago()
    P-->>-SGP: return List~OrdenPago~
    SGP->>SGP: mapear cada OrdenPago a OrdenPagoDTO

    SGP-->>-Operador: return cuentaCorrienteDTO: CuentaCorrienteDTO
```

> Nota: implementado en `ConsultaController.obtenerCuentaCorriente(Proveedor)`. La deuda total surge de `Proveedor.getDeudaTotal()` (suma de `getMontoParaCuentaCorriente()` de los comprobantes no pagos — las Notas de Crédito restan). El resto del DTO se construye mapeando las listas que ya expone `Proveedor` (`getComprobantes()`, `getComprobantesImpagos()`, `getOrdenesDePago()`) a sus DTOs correspondientes, sin necesidad de volver a recorrer ni recalcular nada en `ConsultaController`.
