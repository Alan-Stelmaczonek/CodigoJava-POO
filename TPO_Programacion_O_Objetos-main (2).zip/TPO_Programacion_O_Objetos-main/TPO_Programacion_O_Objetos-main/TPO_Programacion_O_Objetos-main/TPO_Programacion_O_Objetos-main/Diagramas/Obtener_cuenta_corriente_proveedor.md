```mermaid
sequenceDiagram
    actor Operador
    participant SGP as :SistemaGestionProveedores
    participant P as :Proveedor
    participant C as :Comprobante

    Operador->>+SGP: obtenerCuentaCorriente(cuit: String)

    loop [por cada proveedor en proveedores]
        SGP->>SGP: buscarProveedor(cuit)
    end

    SGP->>+P: getComprobantesImpagos()

    loop [por cada comprobante]
        P->>+C: estaPagado()
        C-->>-P: return false (impago)
    end

    P-->>-SGP: return List~Comprobante~

    loop [por cada comprobante en List~Comprobante~]
        SGP->>+C: getImpactoEnCuentaCorriente()
        C-->>-SGP: return monto (+F, -NC, +ND)
    end

    SGP->>+P: getDeudaTotal()
    P->>P: sumar impactos
    P-->>-SGP: return deudaTotal: float

    SGP-->>-Operador: return cuentaCorrienteDTO
```
