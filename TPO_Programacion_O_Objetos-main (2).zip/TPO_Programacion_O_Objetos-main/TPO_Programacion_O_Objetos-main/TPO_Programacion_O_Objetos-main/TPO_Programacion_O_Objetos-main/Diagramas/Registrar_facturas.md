```mermaid
sequenceDiagram
    actor Operador
    participant SGP as :SistemaGestionProveedores
    participant F as :Factura
    participant OC as :OrdenCompra
    participant LC as :LineaComprobante
    participant LOC as :LineaOrdenCompra
    participant U as :Usuario

    Operador->>+SGP: registrarFactura(cuit: String, numeroOC: int, fecha: Date, nombreUsuario: String)

    loop [por cada proveedor en proveedores]
        SGP->>SGP: buscarProveedor(cuit)
    end

    loop [por cada ordenCompra en ordenesCompra]
        SGP->>SGP: buscarOrdenCompra(numeroOC)
    end

    loop [por cada usuario en usuarios]
        SGP->>SGP: buscarUsuario(nombreUsuario)
    end

    SGP->>+F: <<create>> new Factura(numero, fecha)

    loop [por cada linea ingresada]
        SGP->>+LC: <<create>> new LineaComprobante(cantidad, precioUnitario, ivaIVA)
        LC-->>-SGP: return lineaComprobante
        SGP->>F: agregarLinea(lineaComprobante)
    end

    alt [tiene Orden de Compra]
        SGP->>+F: validarPreciosContraOC()

        F->>+OC: getLineas()
        OC-->>-F: return List~LineaOrdenCompra~

        loop [por cada linea de la factura]
            F->>+LC: getSubtotal()
            LC-->>-F: return subtotalFactura
            F->>+LOC: getSubtotal()
            LOC-->>-F: return subtotalOC
        end

        F-->>-SGP: return boolean

        alt [precios no coinciden]
            SGP->>+U: esSupervisor()
            U-->>-SGP: return true
            SGP->>F: requiereAprobacion = true
        else [precios coinciden]
            SGP->>F: requiereAprobacion = false
        end

    else [sin Orden de Compra]
        SGP->>+U: esSupervisor()
        U-->>-SGP: return true
        SGP->>F: requiereAprobacion = true
    end

    F-->>-SGP: return factura
    SGP-->>-Operador: return factura
```
