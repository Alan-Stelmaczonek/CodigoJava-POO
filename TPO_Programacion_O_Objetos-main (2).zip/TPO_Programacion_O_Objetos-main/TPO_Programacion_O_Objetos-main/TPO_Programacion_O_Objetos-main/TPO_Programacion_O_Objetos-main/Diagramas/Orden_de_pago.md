```mermaid
sequenceDiagram
    actor Operador
    participant SGP as :SistemaGestionProveedores
    participant OP as :OrdenPago
    participant C as :Comprobante
    participant P as :Proveedor
    participant CR as :CertificadoRetencion
    participant R as :Retencion

    Operador->>+SGP: emitirOrdenPago(cuit: String, numerosComprobante: List~int~)

    loop [por cada proveedor en proveedores]
        SGP->>SGP: buscarProveedor(cuit)
    end

    loop [por cada numero en numerosComprobante]
        SGP->>SGP: buscarComprobante(numero)
    end

    SGP->>+OP: <<create>> new OrdenPago(numero, fecha)

    loop [por cada comprobante encontrado]
        SGP->>+C: calcularTotal()
        C-->>-SGP: return totalComprobante
        SGP->>OP: agregarComprobante(comprobante)
    end

    loop [por cada tipoImpuesto en [IVA, IIBB, Ganancias]]
        SGP->>+P: tieneCertificadoVigente(tipoImpuesto)
        P->>+CR: estaVigente()
        CR-->>-P: return false
        P-->>-SGP: return false

        SGP->>+R: <<create>> new Retencion(tipoImpuesto, porcentaje, minimoNoImponible)
        SGP->>+R: correspondeRetener(baseImponible)
        R-->>-SGP: return true
        SGP->>+R: calcularMonto(baseImponible)
        R-->>-SGP: return montoRetencion
        SGP->>OP: agregarRetencion(retencion)
    end

    loop [por cada medioPago ingresado]
        SGP->>OP: agregarMedioPago(medioPago)
    end

    OP->>OP: calcularTotalRetenciones()
    OP->>OP: calcularMontoPagar()
    OP-->>SGP: return montoAPagar

    loop [por cada comprobante en OrdenPago]
        SGP->>+C: marcarPagado()
        C-->>-SGP: return void
    end

    OP-->>-SGP: return ordenPago
    SGP-->>-Operador: return ordenPago
```
