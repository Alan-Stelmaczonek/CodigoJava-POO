```mermaid
sequenceDiagram
    actor Operador
    participant SGP as :SistemaGestionProveedores
    participant OC as :OrdenCompra
    participant LOC as :LineaOrdenCompra
    participant P as :Proveedor
    participant U as :Usuario

    Operador->>+SGP: generarOrdenCompra(cuit: String, nombreUsuario: String)

    loop [por cada proveedor en proveedores]
        SGP->>SGP: buscarProveedor(cuit)
    end

    loop [por cada usuario en usuarios]
        SGP->>SGP: buscarUsuario(nombreUsuario)
    end

    SGP->>+OC: <<create>> new OrdenCompra(numero, fecha)

    loop [por cada linea ingresada]
        SGP->>+LOC: <<create>> new LineaOrdenCompra(cantidad, precioUnitario)
        LOC-->>-SGP: return lineaOrdenCompra
        SGP->>OC: agregarLinea(lineaOrdenCompra)
    end

    OC->>OC: calcularTotal()

    loop [por cada linea en lineas]
        OC->>+LOC: getSubtotal()
        LOC-->>-OC: return subtotal
    end

    OC-->>SGP: return totalOC

    SGP->>+P: getDeudaTotal()
    P-->>-SGP: return deudaActual

    SGP->>+P: superaLimiteDeuda(totalOC)
    P-->>-SGP: return boolean

    alt [supera limite de deuda]
        SGP->>+U: esSupervisor()
        U-->>-SGP: return true
        SGP->>+OC: aprobar(supervisor)
        OC-->>-SGP: return ok
    else [no supera limite]
        SGP->>OC: aprobar(supervisor)
        OC-->>SGP: return ok
    end

    OC-->>-SGP: return ordenCompra
    SGP-->>-Operador: return ordenCompra
```
