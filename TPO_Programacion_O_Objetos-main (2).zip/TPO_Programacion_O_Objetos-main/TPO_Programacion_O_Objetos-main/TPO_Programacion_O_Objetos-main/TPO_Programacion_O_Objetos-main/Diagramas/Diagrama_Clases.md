```mermaid
classDiagram
    direction TB

    class SistemaGestionProveedores {
        -instancia: SistemaGestionProveedores$
        -usuarios: List~Usuario~
        -roles: List~Rol~
        -proveedores: List~Proveedor~
        -productos: List~Producto~
        -rubros: List~Rubro~
        -ordenesCompra: List~OrdenCompra~
        -ordenesPago: List~OrdenPago~
        -comprobantes: List~Comprobante~
        +getInstance()$ SistemaGestionProveedores
        +login(nombreUsuario: String, contrasenia: String) Usuario
        +altaRol(nombre: String, permisos: List~String~) Rol
        +buscarRol(nombre: String) Rol
        +altaUsuario(nombre: String, pass: String, rol: Rol) Usuario
        +altaRubro(descripcion: String) Rubro
        +buscarRubro(id: int) Rubro
        +altaProveedor(cuit: String, razonSocial: String, respIVA: String, nombreFantasia: String, direccion: String, telefono: String, email: String, nroIIBB: String, fechaInicio: Date, limiteDeuda: float) Proveedor
        +modificarProveedor(cuit: String) boolean
        +buscarProveedor(cuit: String) Proveedor
        +agregarRubroAProveedor(cuit: String, idRubro: int) void
        +altaProducto(descripcion: String, tipoIVA: float, idRubro: int) Producto
        +asociarProductoProveedor(idProducto: int, cuit: String, precioUnitario: float, unidadMedida: String) ProductoProveedor
        +buscarOrdenCompra(numero: int) OrdenCompra
        +buscarUsuario(nombreUsuario: String) Usuario
        +buscarComprobante(numero: int) Comprobante
        +generarOrdenCompra(cuit: String, nombreUsuario: String) OrdenCompra
        +agregarLineaAOrdenCompra(numeroOC: int, idProductoProveedor: int, cantidad: int) LineaOrdenCompra
        +registrarFactura(cuit: String, numeroOC: int, fecha: Date, nombreUsuario: String) Factura
        +registrarNotaCredito(cuit: String, fecha: Date) NotaCredito
        +registrarNotaDebito(cuit: String, fecha: Date) NotaDebito
        +emitirOrdenPago(cuit: String, numerosComprobante: List~int~) OrdenPago
        +cargarCertificadoNoRetencion(cuit: String, tipoImpuesto: String, fechaInicio: Date, fechaVencimiento: Date) CertificadoNoRetencion
        +obtenerCuentaCorriente(cuit: String) CuentaCorrienteDTO
        +compulsaPrecios(idProducto: int) List~ProductoProveedor~
        +obtenerLibroIVACompras(mesAnio: String) List~LineaLibroIVA~
        +obtenerRankingAcreedores() List~RankingAcreedorDTO~
        +obtenerTotalRetencionesEmitidas() Map~String_float~
        +obtenerFacturasRecibidas(fechaDesde: Date, fechaHasta: Date, cuit: String) List~Factura~
        +obtenerOrdenesPagoEmitidas(fechaDesde: Date, fechaHasta: Date) List~OrdenPago~
    }

    class Usuario {
        -nombreUsuario: String
        -contrasenia: String
        +getNombreUsuario() String
        +getRol() Rol
        +validarCredenciales(contrasenia: String) boolean
        +tienePermiso(permiso: String) boolean
        +esSupervisor() boolean
    }

    class Rol {
        -nombre: String
        -permisos: List~String~
        +getNombre() String
        +tienePermiso(permiso: String) boolean
    }

    class Proveedor {
        -cuit: String
        -responsabilidadIVA: String
        -razonSocial: String
        -nombreFantasia: String
        -direccion: String
        -telefono: String
        -email: String
        -nroIngresosBrutos: String
        -fechaInicioActividades: Date
        -limiteDeuda: float
        +getCuit() String
        +getRazonSocial() String
        +getDeudaTotal() float
        +getRubros() List~Rubro~
        +getComprobantes() List~Comprobante~
        +getOrdenesPago() List~OrdenPago~
        +superaLimiteDeuda(montoNuevo: float) boolean
        +agregarComprobante(comprobante: Comprobante) void
        +agregarOrdenPago(ordenPago: OrdenPago) void
        +getComprobantesImpagos() List~Comprobante~
        +getCuentaCorriente() CuentaCorrienteDTO
        +tieneCertificadoVigente(tipoImpuesto: String) boolean
        +agregarRubro(rubro: Rubro) void
        +agregarCertificado(certificado: CertificadoNoRetencion) void
    }

    class Rubro {
        -id: int
        -descripcion: String
        +getId() int
        +getDescripcion() String
    }

    class CertificadoNoRetencion {
        -tipoImpuesto: String
        -fechaInicio: Date
        -fechaVencimiento: Date
        +getTipoImpuesto() String
        +getFechaInicio() Date
        +getFechaVencimiento() Date
        +estaVigente() boolean
    }

    class Producto {
        -id: int
        -descripcion: String
        -tipoIVA: float
        +getId() int
        +getDescripcion() String
        +getTipoIVA() float
        +getRubro() Rubro
        +getProveedores() List~ProductoProveedor~
    }

    class ProductoProveedor {
        <<asociativa>>
        -precioUnitario: float
        -unidadMedida: String
        +getPrecioUnitario() float
        +getUnidadMedida() String
        +actualizarPrecio(nuevoPrecio: float) void
        +getProveedor() Proveedor
    }

    class OrdenCompra {
        -numero: int
        -fecha: Date
        -estado: EstadoOC
        -requiereAprobacion: boolean
        +getNumero() int
        +getFecha() Date
        +getProveedor() Proveedor
        +isRequiereAprobacion() boolean
        +calcularTotal() float
        +agregarLinea(linea: LineaOrdenCompra) void
        +aprobar(supervisor: Usuario) void
        +marcarPendienteAprobacion() void
        +getLineas() List~LineaOrdenCompra~
        +getEstado() EstadoOC
    }

    class LineaOrdenCompra {
        -cantidad: int
        -precioUnitario: float
        +getCantidad() int
        +getPrecioUnitario() float
        +getSubtotal() float
        +getProductoProveedor() ProductoProveedor
    }

    class Comprobante {
        <<abstract>>
        -numero: int
        -fecha: Date
        -estado: EstadoComprobante
        +getNumero() int
        +getFecha() Date
        +calcularTotal() float
        +calcularTotalIVA() float
        +marcarPagado() void
        +estaPago() boolean
        +getMontoParaCuentaCorriente() float
        +getTipo() String
        +getLineas() List~LineaComprobante~
    }

    class Factura {
        -requiereAprobacion: boolean
        +getOrdenCompra() OrdenCompra
        +calcularTotal() float
        +validarPreciosContraOC(ordenCompra: OrdenCompra) boolean
        +marcarRequiereAprobacion() void
        +getMontoParaCuentaCorriente() float
        +getTipo() String
    }

    class NotaCredito {
        +getFacturaRelacionada() Factura
        +calcularTotal() float
        +getMontoParaCuentaCorriente() float
        +getTipo() String
    }

    class NotaDebito {
        -descripcionMotivo: String
        +calcularTotal() float
        +getMontoParaCuentaCorriente() float
        +getTipo() String
    }

    class LineaComprobante {
        -cantidad: int
        -precioUnitario: float
        -tipoIVA: float
        +getCantidad() int
        +getPrecioUnitario() float
        +getTipoIVA() float
        +getSubtotal() float
        +getMontoIVA() float
        +getProducto() Producto
    }

    class OrdenPago {
        -numero: int
        -fecha: Date
        -totalACancelar: float
        -totalRetenciones: float
        +getNumero() int
        +getFecha() Date
        +getTotalACancelar() float
        +agregarComprobante(comprobante: Comprobante) void
        +agregarMedioPago(medioPago: MedioPago) void
        +agregarRetencion(retencion: Retencion) void
        +getComprobantes() List~Comprobante~
        +getMediosPago() List~MedioPago~
        +getRetenciones() List~Retencion~
        +calcularTotalRetenciones() float
        +calcularMontoAPagar() float
    }

    class Retencion {
        -tipoImpuesto: String
        -porcentaje: float
        -monto: float
        -minimoNoImponible: float
        +getTipoImpuesto() String
        +getMonto() float
        +calcularMonto(baseImponible: float) float
        +correspondeRetener(baseImponible: float) boolean
    }

    class MedioPago {
        <<abstract>>
        -monto: float
        +getMonto() float
        +getDescripcion() String
        +getDetalle() String
    }

    class Efectivo {
        +getDescripcion() String
        +getDetalle() String
    }

    class Transferencia {
        -cbuDestino: String
        -fechaTransferencia: Date
        +getCbuDestino() String
        +getFechaTransferencia() Date
        +getDescripcion() String
        +getDetalle() String
    }

    class Cheque {
        -tipo: TipoCheque
        -fechaEmision: Date
        -fechaVencimiento: Date
        -firmante: String
        +getFechaEmision() Date
        +getFechaVencimiento() Date
        +getFirmante() String
        +getDescripcion() String
        +getDetalle() String
        +isVencido() boolean
    }

    class CuentaCorrienteDTO {
        -deudaTotal: float
        -comprobantes: List~Comprobante~
        -comprobantesImpagos: List~Comprobante~
        -ordenesPago: List~OrdenPago~
        +getDeudaTotal() float
        +getComprobantes() List~Comprobante~
        +getComprobantesImpagos() List~Comprobante~
        +getOrdenesPago() List~OrdenPago~
    }

    class RankingAcreedorDTO {
        -razonSocial: String
        -deudaTotal: float
        +getRazonSocial() String
        +getDeudaTotal() float
    }

    class LineaLibroIVA {
        -cuit: String
        -razonSocial: String
        -fecha: Date
        -tipoDocumento: String
        -iva25: float
        -iva5: float
        -iva105: float
        -iva21: float
        -iva27: float
        -total: float
        +getCuit() String
        +getRazonSocial() String
        +getFecha() Date
        +getTipoDocumento() String
        +getTotal() float
    }

    class EstadoComprobante {
        <<enumeration>>
        PENDIENTE
        PAGADO
        ANULADO
    }

    class EstadoOC {
        <<enumeration>>
        PENDIENTE_APROBACION
        APROBADA
        RECIBIDA
        CANCELADA
    }

    class TipoCheque {
        <<enumeration>>
        PROPIO
        TERCEROS
    }

    %% ── Composiciones ──
    SistemaGestionProveedores "1" *-- "*" Usuario : usuarios
    SistemaGestionProveedores "1" *-- "*" Rol : roles
    SistemaGestionProveedores "1" *-- "*" Proveedor : proveedores
    SistemaGestionProveedores "1" *-- "*" Producto : productos
    SistemaGestionProveedores "1" *-- "*" Rubro : rubros
    SistemaGestionProveedores "1" *-- "*" OrdenCompra : ordenesCompra
    SistemaGestionProveedores "1" *-- "*" OrdenPago : ordenesPago
    SistemaGestionProveedores "1" *-- "*" Comprobante : comprobantes
    OrdenCompra "1" *-- "1..*" LineaOrdenCompra : lineas
    Comprobante "1" *-- "1..*" LineaComprobante : lineas
    OrdenPago "1" *-- "*" Retencion : retenciones
    OrdenPago "1" *-- "1..*" MedioPago : mediosPago
    Proveedor "1" *-- "*" CertificadoNoRetencion : certificados
    Producto "1" *-- "*" ProductoProveedor : productosProveedor

    %% ── Asociaciones ──
    ProductoProveedor "*" --> "1" Proveedor : proveedor
    Proveedor "*" --> "1..*" Rubro : rubros
    Proveedor "1" --> "*" Comprobante : comprobantes
    Proveedor "1" --> "*" OrdenPago : ordenesPago
    Producto "*" --> "1" Rubro : rubro
    OrdenPago "*" --> "1..*" Comprobante : comprobantes
    Usuario "*" --> "1" Rol : rol
    OrdenCompra "*" --> "1" Proveedor : proveedor
    Factura "*" --> "0..1" OrdenCompra : ordenCompra
    NotaCredito "*" --> "0..1" Factura : facturaRelacionada
    LineaOrdenCompra "*" --> "1" ProductoProveedor : productoProveedor
    LineaComprobante "*" --> "1" Producto : producto
    CuentaCorrienteDTO "1" --> "*" Comprobante : comprobantes
    CuentaCorrienteDTO "1" --> "*" OrdenPago : ordenesPago

    %% ── Herencias ──
    Comprobante <|-- Factura
    Comprobante <|-- NotaCredito
    Comprobante <|-- NotaDebito
    MedioPago <|-- Efectivo
    MedioPago <|-- Transferencia
    MedioPago <|-- Cheque

    %% ── Enums ──
    OrdenCompra "*" --> "1" EstadoOC : estado
    Comprobante "*" --> "1" EstadoComprobante : estado
    Cheque "*" --> "1" TipoCheque : tipo

    %% ── Dependencias ──
    SistemaGestionProveedores ..> LineaLibroIVA : retorna
    SistemaGestionProveedores ..> RankingAcreedorDTO : retorna
    Proveedor ..> CuentaCorrienteDTO : genera
```

¿Seguimos con los diagramas de secuencia?
