package cdcsoft.model;

public class Usuario {
    private String NombreUsuario;
    private String Contrasenia;
    private Rol rol;

    // Constructor
    public Usuario(String NombreUsuario, String Contrasenia, Rol rol) {
        this.NombreUsuario = NombreUsuario;
        this.Contrasenia = Contrasenia;
        this.rol = rol;
    }

    public String getNombreUsuario() {
        return this.NombreUsuario;
    }

    public Rol getRol() {
        return rol;
    }

    public String getContrasenia() {
        return Contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        Contrasenia = contrasenia;
    }

    public boolean validarCredenciales(String contrasenia) {
        return this.Contrasenia.equals(contrasenia);
    }


    public boolean tienePermiso(String permiso) {
        return rol.tienePermiso(permiso);
    }

    public boolean esSupervisor() {
        return rol.getNombre().equals("Supervisor");
    }
}

