package cdcsoft.model;

import cdcsoft.model.enums.EstadoComprobante;
import cdcsoft.model.LineaComprobante;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;


public abstract class Comprobante {

    protected int numero;
    protected Date fecha;
    protected EstadoComprobante estado;
    protected List<LineaComprobante> lineas;

    public Comprobante(int numero, Date fecha, EstadoComprobante estado) {
        this.numero = numero;
        this.fecha = fecha;
        this.estado = estado;
        this.lineas = new ArrayList<>();
    }

    public int getNumero() {
        return numero;
    }

    public Date getFecha() {
        return fecha;
    }


    public float calcularTotalIVA() {
        float total = 0;
        for (int i = 0; i < lineas.size(); i++) {
            total = total + lineas.get(i).getMontoIVA();
        }
        return total;
    }

    public void marcarPagado(EstadoComprobante estado) {
        this.estado = EstadoComprobante.PAGADO;
    }

    public boolean estaPago() {
        if (estado != EstadoComprobante.PAGADO) {
            return false;
        } else {
            return true;
        }
    }

    public List<LineaComprobante> getLineas() {
        return lineas;
    }


    public abstract float calcularTotal();

    public abstract float getMontoParaCuentaCorriente();

    public abstract String getTipo();

}
