package cdcsoft.model;

public class ProductoProveedor {
}
