package cdcsoft.model;

public class Rubro {
    private int Id;
    private String Descripcion;

    public Rubro(int Id ,  String Descripcion) {
        this.Id = Id;
        this.Descripcion = Descripcion;
    }

    public int getId () {
        return Id;
    }
    public String getDescripcion () {
        return Descripcion;
    }
}
