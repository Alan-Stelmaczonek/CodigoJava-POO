package cdcsoft.model;

public class Efectivo extends MedioPago {

    public Efectivo(float monto) {
        super(monto);
    }

    @Override
    public String getDescripcion() {
        return "Pago en efectivo";
    }

    @Override
    public String getDetalle() {
        return "Efectivo - Monto: " + getMonto();
    }
}