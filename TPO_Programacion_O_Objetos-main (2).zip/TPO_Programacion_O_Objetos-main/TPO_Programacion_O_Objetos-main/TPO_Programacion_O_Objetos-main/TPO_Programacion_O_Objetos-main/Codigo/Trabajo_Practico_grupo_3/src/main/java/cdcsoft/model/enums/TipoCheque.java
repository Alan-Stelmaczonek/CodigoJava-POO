package cdcsoft.model.enums;

public enum TipoCheque {
    PROPIO,
    TERCEROS
}

