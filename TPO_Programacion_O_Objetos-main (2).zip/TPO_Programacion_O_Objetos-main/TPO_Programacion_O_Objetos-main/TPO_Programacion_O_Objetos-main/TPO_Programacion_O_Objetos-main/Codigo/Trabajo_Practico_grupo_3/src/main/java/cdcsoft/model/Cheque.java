package cdcsoft.model;

import cdcsoft.model.enums.TipoCheque;

import java.util.Date;

public class Cheque extends MedioPago {
    private TipoCheque tipo;
    private Date fechaEmision;
    private Date fechaVencimiento;
    private String firmante;


    public Cheque(float monto, TipoCheque tipo, Date fechaEmision, Date fechaVencimiento, String firmante) {
        super(monto);
        this.tipo = tipo;
        this.fechaEmision = fechaEmision;
        this.fechaVencimiento = fechaVencimiento;
        this.firmante = firmante;
    }

    public Date getFechaEmision() {
        return fechaEmision;
    }
    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }
    public String getFirmante() {
        return firmante;
    }

    @Override
    public String getDescripcion () {
        return "Tipo de cheque: " + tipo;
    }
    @Override
    public String getDetalle () {
        return "Fecha de emision: " + fechaEmision +
                " | Fecha de vencimiento: " + fechaVencimiento +
                " | " + getDescripcion();
    }

    public TipoCheque getTipo() {
        return tipo;
    }

    public boolean isVencido () {
        return fechaVencimiento.before(new Date());
    }

}
