package cdcsoft.model;

import java.util.Date;

public class Transferencia extends MedioPago {
    private String cbuDestino;
    private Date fechaTransferencia;


    public Transferencia(float monto, String cbuDestino, Date fechaTransferencia) {
        super(monto);
        this.cbuDestino = cbuDestino;
        this.fechaTransferencia = fechaTransferencia;
    }

    public String getCbuDestino() {
        return  cbuDestino;
    }
    @Override
    public String getDescripcion() {
        return "Transferencia a CBU: " + cbuDestino;
    }

    @Override
    public String getDetalle() {
        return "CBU destino: " + cbuDestino +
                " | Fecha: " + fechaTransferencia +
                " | Monto: " + monto;
    }

    public Date getFechaTransferencia() {
        return fechaTransferencia;
    }
}
