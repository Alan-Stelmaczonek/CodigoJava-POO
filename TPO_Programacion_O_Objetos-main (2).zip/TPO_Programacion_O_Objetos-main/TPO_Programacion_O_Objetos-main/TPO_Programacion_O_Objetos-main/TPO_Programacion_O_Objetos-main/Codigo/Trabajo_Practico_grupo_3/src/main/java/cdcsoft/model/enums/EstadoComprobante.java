package cdcsoft.model.enums;

public enum EstadoComprobante {
        PENDIENTE,
        PAGADO,
        ANULADO
}
