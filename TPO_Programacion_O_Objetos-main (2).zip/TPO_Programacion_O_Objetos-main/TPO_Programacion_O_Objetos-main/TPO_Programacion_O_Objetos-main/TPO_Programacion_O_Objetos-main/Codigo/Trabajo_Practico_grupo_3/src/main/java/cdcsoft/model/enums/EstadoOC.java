package cdcsoft.model.enums;

public enum EstadoOC {
    PENDIENTE_APROBACION,
    APROBADA,
    RECIBIDA,
    CANCELADA
}
