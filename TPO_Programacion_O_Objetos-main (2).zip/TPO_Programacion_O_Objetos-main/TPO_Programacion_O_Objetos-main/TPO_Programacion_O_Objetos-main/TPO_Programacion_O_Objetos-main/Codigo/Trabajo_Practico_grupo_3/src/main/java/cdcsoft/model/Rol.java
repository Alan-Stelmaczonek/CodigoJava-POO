package cdcsoft.model;

import java.util.List;

public class Rol {
    private String Nombre;
    private List<String> Permisos;

    // Constructor
    public Rol(String Nombre, List<String> Permisos) {
        this.Nombre = Nombre;
        this.Permisos = Permisos;
    }

    // Metodo get nombre
    public String getNombre() {
        return this.Nombre;
    }

    public boolean tienePermiso(String permiso) {
        return Permisos.contains(permiso);
    }

}
