package cdcsoft.model;

public abstract class MedioPago {
    protected float monto;

    public MedioPago(float monto) {
        this.monto = monto;
    }

    public float getMonto() {
        return monto;
    }

    public abstract String getDescripcion();


    public abstract String getDetalle ();

}
