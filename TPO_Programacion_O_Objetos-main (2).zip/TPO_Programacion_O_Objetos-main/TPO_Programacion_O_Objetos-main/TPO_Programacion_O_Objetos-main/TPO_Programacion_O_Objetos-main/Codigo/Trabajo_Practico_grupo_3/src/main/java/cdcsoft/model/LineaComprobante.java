package cdcsoft.model;

import cdcsoft.model.Producto;

public class LineaComprobante {
    private int cantidad;
    private float precioUnitario;
    private float tipoIVA;
    private Producto producto;

    public LineaComprobante(int cantidad, float precioUnitario, float tipoIVA) {
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.tipoIVA = tipoIVA;
    }

    public int getCantidad() {
        return cantidad;
    }

    public float getPrecioUnitario() {
        return precioUnitario;
    }

    public float getTipoIVA() {
        return tipoIVA;
    }

    public float getSubtotal() {
        return cantidad * precioUnitario;
    }

    public float getMontoIVA() {
        return getSubtotal() * tipoIVA / 100;
    }

    public Producto getProducto() {
        return producto;
    }

}
