package cdcsoft.model;


public class Producto {
    private int id;
    private String descripcion;
    private float tipoIVA;
    private Rubro rubro;

    public Producto(int id, String descripcion, float tipoIVA, Rubro rubro) {
        this.id = id;
        this.descripcion = descripcion;
        this.tipoIVA = tipoIVA;
        this.rubro = rubro;
    }

    public int getId() {
        return id;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public float getTipoIVA() {
        return tipoIVA;
    }

    public Rubro getRubro() {
        return rubro;
    }

    // Falta getProveedores - Porque primero necesitamos ProductoProveedor
}
